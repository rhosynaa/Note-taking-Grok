# 🌙 Kawaii Study Space

A pastel study workspace built with **Next.js (App Router) + PostgreSQL + Drizzle ORM** —
notes canvas, flashcards, pomodoro timer, tasks, subjects, analytics, music, mind maps and more,
all wrapped in a cozy kawaii interface.

## What's inside

| Folder / file        | Purpose                                                        |
| -------------------- | -------------------------------------------------------------- |
| `src/app`            | App Router pages + API routes                                  |
| `src/components`     | UI (dashboard, editor, shell, provider, views…)                |
| `src/db`             | Drizzle schema + database client                               |
| `public/art`         | Generated artwork (avatar, hero, banners)                      |
| `public/covers`      | Note cover images                                              |

## Setup

```bash
# 1. install dependencies
npm install

# 2. configure the database
cp .env.example .env
#   then edit .env and set DATABASE_URL to your PostgreSQL connection string

# 3. create the tables
npx drizzle-kit push

# 4. run it
npm run dev        # development
npm run build && npm start   # production
```

On first load the app calls `/api/bootstrap`, creates a demo user
(“Dreamy Student”) and seeds starter subjects/tasks/templates — no login needed.

## Responsive behavior

- **≥ 768px** — full multi-column layout, always on.
- **< 768px** — single-column stacking by default; a mobile-only
  **Desktop mode** toggle (profile menu → Settings) swaps to a snug
  2-column grid that always fits the screen (no zoom-out, no horizontal scrolling).

## Notes

- Never commit your real `.env` — `.gitignore` already excludes it.
- Images under `public/` are part of the repo; keep them if you fork
  or the covers/avatar will 404.

"use client";

import { useState } from "react";
import { api, useKawaii } from "./provider";

type Tab = "quote" | "motivation";

export function QuotesView() {
  const { data, reload, quote, motivation } = useKawaii();
  const [tab, setTab] = useState<Tab>("quote");
  const [text, setText] = useState("");
  const [author, setAuthor] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [editAuthor, setEditAuthor] = useState("");

  const quotes = data?.quotes ?? [];
  const motivations = data?.motivations ?? [];
  const items = tab === "quote" ? quotes : motivations;

  async function addItem() {
    if (!text.trim()) return;
    await api("/api/content", {
      method: "POST",
      body: JSON.stringify({ kind: tab, text: text.trim(), author: tab === "quote" ? author.trim() || null : null }),
    });
    setText("");
    setAuthor("");
    await reload();
  }

  async function saveEdit(id: string) {
    if (!editText.trim()) return;
    await api("/api/content", {
      method: "POST",
      body: JSON.stringify({ id, text: editText.trim(), author: tab === "quote" ? editAuthor.trim() || null : null }),
    });
    setEditingId(null);
    await reload();
  }

  async function deleteItem(id: string) {
    if (!window.confirm("Delete this entry?")) return;
    await api("/api/content", { method: "POST", body: JSON.stringify({ id, _delete: true }) });
    await reload();
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Quotes & motivation 💬</h1>
        <p className="text-sm text-pink-500">
          Your collection of quotes of the day and daily motivations — a new random one is picked every day.
        </p>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <section className="card">
          <h2 className="card-title">Today&apos;s quote</h2>
          <p className="mt-2 font-[var(--font-caveat)] text-2xl text-fuchsia-800">&ldquo;{quote}&rdquo;</p>
        </section>
        <section className="card flex items-center gap-3">
          <span className="text-3xl">🎀</span>
          <div>
            <h2 className="card-title">Today&apos;s motivation</h2>
            <p className="mt-1 text-sm">{motivation}</p>
          </div>
        </section>
      </div>

      <div className="flex gap-2">
        <button className={`ghost-btn ${tab === "quote" ? "active" : ""}`} onClick={() => setTab("quote")}>
          💬 Quotes of the day ({quotes.length})
        </button>
        <button className={`ghost-btn ${tab === "motivation" ? "active" : ""}`} onClick={() => setTab("motivation")}>
          🎀 Daily motivations ({motivations.length})
        </button>
      </div>

      <section className="card">
        <h2 className="card-title mb-2">Add a new {tab === "quote" ? "quote" : "motivation"}</h2>
        <div className="flex flex-col gap-2">
          <textarea
            className="min-h-20 rounded-2xl border-2 border-pink-200 p-3 text-sm"
            placeholder={tab === "quote" ? "Write an inspiring quote…" : "Write a motivational nudge…"}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          {tab === "quote" && (
            <input
              className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
              placeholder="Author (optional)"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
            />
          )}
          <div>
            <button className="pink-btn" onClick={addItem}>
              Add {tab === "quote" ? "quote" : "motivation"}
            </button>
          </div>
        </div>
      </section>

      <section className="card">
        <h2 className="card-title mb-2">
          Your {tab === "quote" ? "quotes" : "motivations"} ({items.length})
        </h2>
        {items.length === 0 && (
          <p className="empty-state">Nothing here yet — add your first one above ✨</p>
        )}
        <div className="flex flex-col gap-2">
          {items.map((item) => (
            <article key={item.id} className="rounded-2xl bg-pink-50 px-3 py-2">
              {editingId === item.id ? (
                <div className="flex flex-col gap-2">
                  <textarea
                    className="rounded-xl border-2 border-pink-200 p-2 text-sm"
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                  />
                  {tab === "quote" && (
                    <input
                      className="rounded-xl border-2 border-pink-200 px-2 py-1 text-sm"
                      placeholder="Author (optional)"
                      value={editAuthor}
                      onChange={(e) => setEditAuthor(e.target.value)}
                    />
                  )}
                  <div className="flex gap-2">
                    <button className="pink-btn !shadow-none" onClick={() => saveEdit(item.id)}>
                      Save
                    </button>
                    <button className="ghost-btn" onClick={() => setEditingId(null)}>
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-fuchsia-900">“{item.text}”</p>
                    {tab === "quote" && "author" in item && (item as { author: string | null }).author ? (
                      <p className="text-xs italic text-pink-500">— {(item as { author: string | null }).author}</p>
                    ) : null}
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <button
                      className="ghost-btn"
                      onClick={() => {
                        setEditingId(item.id);
                        setEditText(item.text);
                        setEditAuthor(tab === "quote" && "author" in item ? ((item as { author: string | null }).author ?? "") : "");
                      }}
                    >
                      Edit
                    </button>
                    <button className="ghost-btn" onClick={() => deleteItem(item.id)}>
                      Delete
                    </button>
                  </div>
                </div>
              )}
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { durationForType, formatTime, todayKey, type SessionType } from "@/lib/timer";
import { MOTIVATIONS, QUOTES } from "@/lib/types";

export interface Subject {
  id: string;
  name: string;
  color: string;
  icon: string;
  targetMinutes: number;
}
export interface Project {
  id: string;
  name: string;
  description: string | null;
  subjectId: string | null;
  targetMinutes: number;
}
export interface Note {
  id: string;
  title: string;
  subjectId: string | null;
  projectId: string | null;
  templateId: string | null;
  kind: string;
  content: unknown[];
  coverImage: string | null;
  pinned: boolean;
  archived: boolean;
  canvasWidth: number;
  canvasHeight: number;
  background: string | null;
  difficulty: string;
  createdAt: string;
  updatedAt: string;
}
export interface Task {
  id: string;
  title: string;
  completed: boolean;
  dueDate: string | null;
  subjectId: string | null;
  noteId: string | null;
  priority: string;
}
export interface Tag {
  id: string;
  name: string;
  color: string;
}
export interface NoteTag {
  id: string;
  noteId: string;
  tagId: string;
}
export interface Widget {
  id: string;
  widgetKey: string;
  layoutOrder: number;
  visible: boolean;
  pinned: boolean;
}
export interface Track {
  id: string;
  playlistId: string | null;
  title: string;
  artist: string | null;
  source: string;
  url: string;
  durationSeconds: number;
  sortOrder: number;
}
export interface Playlist {
  id: string;
  name: string;
}
export interface TimeEntry {
  id: string;
  subjectId: string | null;
  projectId: string | null;
  noteId: string | null;
  date: string;
  durationSeconds: number;
  note: string | null;
}
export interface Asset {
  id: string;
  name: string;
  mimeType: string;
  kind: string;
  url?: string;
  createdAt: string;
}
export interface AnalyticsPayload {
  daily: { totalSeconds: number; sessions: number; date: string };
  weekly: { totalSeconds: number; days: { date: string; totalSeconds: number }[] };
  monthly: { totalSeconds: number; days: { date: string; totalSeconds: number }[] };
  subjects: (Subject & { minutes: number; seconds: number; pct: number })[];
  streak: number;
  totalMinutes: number;
}

export interface Workspace {
  user: { id: string; name: string; email: string | null; avatar: string | null; preferences: Record<string, unknown> | null };
  subjects: Subject[];
  projects: Project[];
  notes: Note[];
  tasks: Task[];
  tags: Tag[];
  noteTags: NoteTag[];
  widgets: Widget[];
  playlists: Playlist[];
  tracks: Track[];
  timeEntries: TimeEntry[];
  assets: Asset[];
  analytics: AnalyticsPayload;
  systemTemplates: { id: string; name: string; category: string; description: string; cover: string; paper: string }[];
  customTemplates: { id: string; name: string; category: string; thumbnail: string | null; data: Record<string, unknown> }[];
  quotes: { id: string; text: string; author: string | null }[];
  motivations: { id: string; text: string }[];
  flashcardReviews: { id: string; noteId: string; result: string; difficulty: string; createdAt: string }[];
  today: string;
}

interface Ctx {
  ready: boolean;
  data: Workspace | null;
  reload: () => Promise<void>;
  focusMode: boolean;
  setFocusMode: (v: boolean) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (v: boolean) => void;
  search: string;
  setSearch: (v: string) => void;
  searchResults: { notes: Note[]; tasks: Task[]; tags: Tag[] } | null;
  timer: {
    type: SessionType;
    remaining: number;
    running: boolean;
    sessionId: string | null;
    subjectId: string | null;
    label: string;
  };
  setTimerType: (t: SessionType) => void;
  setTimerSubject: (id: string | null) => void;
  startTimer: () => Promise<void>;
  pauseTimer: () => Promise<void>;
  resetTimer: () => Promise<void>;
  music: {
    index: number;
    playing: boolean;
    muted: boolean;
    volume: number;
    playlistId: string | null;
    tracks: Track[];
    shuffle: boolean;
  };
  setMusicIndex: (i: number) => void;
  setPlaylistId: (id: string | null) => void;
  togglePlay: () => void;
  nextTrack: (auto?: boolean) => void;
  prevTrack: () => void;
  toggleShuffle: () => void;
  setMuted: (v: boolean) => void;
  setVolume: (v: number) => void;
  darkMode: boolean;
  setDarkMode: (v: boolean) => void;
  desktopMode: boolean;
  setDesktopMode: (v: boolean) => void;
  /** true when the viewport is narrower than 768px (mobile) */
  isMobile: boolean;
  quote: string;
  motivation: string;
}

const KawaiiCtx = createContext<Ctx | null>(null);

export function useKawaii() {
  const ctx = useContext(KawaiiCtx);
  if (!ctx) throw new Error("useKawaii must be inside AppProviders");
  return ctx;
}

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  return res.json();
}

/* ------------------------------------------------------------------ */
/* Track helpers                                                       */
/* ------------------------------------------------------------------ */

export function youtubeId(url: string) {
  const m = url.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([A-Za-z0-9_-]{6,})/);
  return m?.[1] ?? null;
}

export type TrackKind = "youtube" | "spotify" | "audio" | "none";

export function trackKind(track?: Track | null): TrackKind {
  if (!track || !track.url) return "none";
  if (track.source === "youtube" || track.url.includes("youtu")) return "youtube";
  if (track.url.includes("spotify.com")) return "spotify";
  return "audio";
}

export function trackEmbed(track?: Track | null) {
  if (!track) return null;
  if (trackKind(track) === "youtube") {
    const id = youtubeId(track.url);
    return id ? `https://www.youtube.com/embed/${id}?autoplay=1` : null;
  }
  if (track.url.includes("spotify.com")) {
    return track.url.replace("open.spotify.com/", "open.spotify.com/embed/");
  }
  return null;
}

export function trackThumb(track?: Track | null) {
  if (!track) return null;
  if (trackKind(track) === "youtube") {
    const id = youtubeId(track.url);
    return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : null;
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* YouTube IFrame API loader                                           */
/* ------------------------------------------------------------------ */

declare global {
  interface Window {
    YT?: any;
    onYouTubeIframeAPIReady?: () => void;
  }
}

let ytApiPromise: Promise<any> | null = null;

function loadYouTubeApi(): Promise<any> {
  if (typeof window === "undefined") return Promise.reject(new Error("server"));
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (ytApiPromise) return ytApiPromise;
  ytApiPromise = new Promise((resolve) => {
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      prev?.();
      resolve(window.YT);
    };
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    tag.async = true;
    document.head.appendChild(tag);
  });
  return ytApiPromise;
}

/* ------------------------------------------------------------------ */
/* UI settings (dark mode / desktop mode)                              */
/* ------------------------------------------------------------------ */

interface UiSettings {
  dark: boolean;
  desktop: boolean;
}

const UI_KEY = "kawaii-ui";
const MUSIC_KEY = "kawaii-music";
/** Anything narrower than 768px counts as a mobile layout. */
export const MOBILE_MEDIA_QUERY = "(max-width: 767.98px)";

function readUiSettings(): UiSettings {
  try {
    const raw = localStorage.getItem(UI_KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<UiSettings>;
      return { dark: !!p.dark, desktop: !!p.desktop };
    }
  } catch {
    /* ignore */
  }
  return { dark: false, desktop: false };
}

/**
 * Applies UI prefs as <html> classes. The viewport meta tag is never
 * touched — "desktop mode" is a pure CSS-grid layout (2 columns that
 * always fit the real screen width), so phones never zoom out or
 * scroll horizontally.
 */
function applyUiSettings(s: UiSettings) {
  const root = document.documentElement;
  root.classList.toggle("dark", s.dark);
  // Desktop mode only does anything below 768px; above that the
  // multi-column layout is always on, so the class is skipped.
  const smallScreen = window.matchMedia(MOBILE_MEDIA_QUERY).matches;
  root.classList.toggle("desktop-mode", s.desktop && smallScreen);
}

/** Reactive screen-width detection — re-renders on resize/rotation. */
function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const update = () => setMatches(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, [query]);
  return matches;
}

/* ------------------------------------------------------------------ */
/* Provider                                                            */
/* ------------------------------------------------------------------ */

export function AppProviders({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Workspace | null>(null);
  const [ready, setReady] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<Ctx["searchResults"]>(null);
  const [timerType, setTimerType] = useState<SessionType>("pomodoro");
  const [remaining, setRemaining] = useState(durationForType("pomodoro"));
  const [running, setRunning] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [musicIndex, setMusicIndexState] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [playlistId, setPlaylistId] = useState<string | null>(null);
  const [shuffle, setShuffle] = useState(false);
  const [darkMode, setDarkModeState] = useState(false);
  const [desktopMode, setDesktopModeState] = useState(false);
  /** true below 768px — drives which layouts render */
  const isMobile = useMediaQuery(MOBILE_MEDIA_QUERY);
  const tickRef = useRef<number | null>(null);

  /* audio engine refs */
  const ytHostRef = useRef<HTMLDivElement | null>(null);
  const ytRef = useRef<any>(null);
  const ytCreatingRef = useRef<Promise<void> | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const loadedVideoRef = useRef<string | null>(null);
  const startedAtRef = useRef(0);
  const advanceRef = useRef<(() => void) | null>(null);
  const restartRef = useRef<(() => void) | null>(null);
  const playStateRef = useRef({
    playing: false,
    index: 0,
    tracks: [] as Track[],
    volume: 0.7,
    muted: false,
    shuffle: false,
  });

  const reload = useCallback(async () => {
    const ws = await api<Workspace>("/api/bootstrap");
    setData(ws);
    setReady(true);
  }, []);

  useEffect(() => {
    reload().catch(() => setReady(true));
  }, [reload]);

  /* hydrate persisted UI settings (boot script already applied classes) */
  useEffect(() => {
    const s = readUiSettings();
    setDarkModeState(s.dark);
    setDesktopModeState(s.desktop);
    applyUiSettings(s);
    try {
      const raw = localStorage.getItem(MUSIC_KEY);
      if (raw) {
        const p = JSON.parse(raw) as { shuffle?: boolean; volume?: number; muted?: boolean };
        setShuffle(!!p.shuffle);
        if (typeof p.volume === "number") setVolume(Math.min(1, Math.max(0, p.volume)));
        if (typeof p.muted === "boolean") setMuted(p.muted);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const setDarkMode = useCallback((v: boolean) => {
    setDarkModeState(v);
    const s = { ...readUiSettings(), dark: v };
    try {
      localStorage.setItem(UI_KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
    applyUiSettings(s);
  }, []);

  const setDesktopMode = useCallback((v: boolean) => {
    setDesktopModeState(v);
    const s = { ...readUiSettings(), desktop: v };
    try {
      localStorage.setItem(UI_KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
    applyUiSettings(s);
  }, []);

  /* keep the html class in sync when the 768px breakpoint is crossed
     (rotate / resize / dock) — desktop mode silently opts out >=768px */
  useEffect(() => {
    document.documentElement.classList.toggle("desktop-mode", desktopMode && isMobile);
  }, [desktopMode, isMobile]);

  useEffect(() => {
    try {
      localStorage.setItem(MUSIC_KEY, JSON.stringify({ shuffle, volume, muted }));
    } catch {
      /* ignore */
    }
  }, [shuffle, volume, muted]);

  useEffect(() => {
    if (!running) {
      if (tickRef.current) window.clearInterval(tickRef.current);
      return;
    }
    tickRef.current = window.setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          setRunning(false);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => {
      if (tickRef.current) window.clearInterval(tickRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (remaining === 0 && sessionId) {
      api("/api/timer", {
        method: "POST",
        body: JSON.stringify({ action: "complete", sessionId, remainingSeconds: 0 }),
      })
        .then(() => reload())
        .catch(() => undefined);
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        new Notification("Kawaii Study Space", { body: "Session complete! Time for a stretch ✨" });
      }
    }
  }, [remaining, sessionId, reload]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (!search.trim()) {
        setSearchResults(null);
        return;
      }
      api<Ctx["searchResults"]>(`/api/search?q=${encodeURIComponent(search)}`)
        .then(setSearchResults)
        .catch(() => undefined);
    }, 220);
    return () => clearTimeout(t);
  }, [search]);

  const syncPrefs = (data?.user?.preferences ?? {}) as Record<string, unknown>;
  const autoSyncOn = syncPrefs.autoSync !== false;
  const syncUserId = data?.user?.id;

  useEffect(() => {
    if (!syncUserId || !autoSyncOn) return;
    const t = window.setInterval(() => {
      reload().catch(() => undefined);
    }, 30000);
    return () => window.clearInterval(t);
  }, [reload, syncUserId, autoSyncOn]);

  const startTimer = useCallback(async () => {
    if (sessionId && !running && remaining > 0) {
      await api("/api/timer", { method: "POST", body: JSON.stringify({ action: "resume", sessionId }) });
      setRunning(true);
      return;
    }
    const dur = durationForType(timerType);
    const row = await api<{ id: string }>(" /api/timer".trim(), {
      method: "POST",
      body: JSON.stringify({
        action: "start",
        type: timerType,
        subjectId,
        durationSeconds: dur,
      }),
    });
    setSessionId(row.id);
    setRemaining(dur);
    setRunning(true);
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => undefined);
    }
  }, [sessionId, running, remaining, timerType, subjectId]);

  const pauseTimer = useCallback(async () => {
    setRunning(false);
    if (sessionId) {
      await api("/api/timer", {
        method: "POST",
        body: JSON.stringify({ action: "pause", sessionId, remainingSeconds: remaining }),
      });
    }
  }, [sessionId, remaining]);

  const resetTimer = useCallback(async () => {
    setRunning(false);
    const dur = durationForType(timerType);
    setRemaining(dur);
    if (sessionId) {
      await api("/api/timer", {
        method: "POST",
        body: JSON.stringify({ action: "reset", sessionId, type: timerType, durationSeconds: dur }),
      });
    }
    setSessionId(null);
  }, [sessionId, timerType]);

  const allTracks = data?.tracks ?? [];
  const activeTracks = useMemo(
    () => (playlistId ? allTracks.filter((t) => t.playlistId === playlistId) : allTracks),
    [allTracks, playlistId],
  );

  /* ---------------------------------------------------------------- */
  /* Music engine                                                      */
  /* ---------------------------------------------------------------- */

  /* keep a mirror of playback state for imperative callbacks */
  useEffect(() => {
    playStateRef.current = { playing, index: musicIndex, tracks: activeTracks, volume, muted, shuffle };
  }, [playing, musicIndex, activeTracks, volume, muted, shuffle]);

  const ensurePlayer = useCallback(async (): Promise<any> => {
    if (ytRef.current) return ytRef.current;
    if (ytCreatingRef.current) {
      await ytCreatingRef.current;
      return ytRef.current;
    }
    ytCreatingRef.current = (async () => {
      const YT = await loadYouTubeApi();
      if (ytRef.current || !ytHostRef.current) return;
      await new Promise<void>((resolve) => {
        ytRef.current = new YT.Player(ytHostRef.current, {
          width: "200",
          height: "120",
          playerVars: {
            autoplay: 0,
            controls: 0,
            disablekb: 1,
            fs: 0,
            iv_load_policy: 3,
            modestbranding: 1,
            playsinline: 1,
            rel: 0,
            origin: window.location.origin,
          },
          events: {
            onReady: () => resolve(),
            onStateChange: (e: any) => {
              if (e?.data === 0) advanceRef.current?.();
            },
            onError: () => {
              window.setTimeout(() => advanceRef.current?.(), 1800);
            },
          },
        });
      });
    })();
    try {
      await ytCreatingRef.current;
    } catch {
      ytCreatingRef.current = null;
      throw new Error("youtube api unavailable");
    }
    return ytRef.current;
  }, []);

  const pauseAll = useCallback(() => {
    try {
      ytRef.current?.pauseVideo?.();
    } catch {
      /* ignore */
    }
    audioRef.current?.pause();
  }, []);

  const syncPlayback = useCallback(async () => {
    const { playing: isPlaying, tracks, index, volume: vol, muted: isMuted } = playStateRef.current;
    const track = tracks[index];
    const kind = trackKind(track);
    const audio = audioRef.current;
    if (!track || !isPlaying || kind === "none" || kind === "spotify") {
      pauseAll();
      return;
    }
    if (kind === "youtube") {
      audio?.pause();
      const id = youtubeId(track.url);
      if (!id) return;
      try {
        const player = await ensurePlayer();
        if (!player) return;
        if (loadedVideoRef.current !== id) {
          loadedVideoRef.current = id;
          player.loadVideoById(id);
        }
        player.setVolume(isMuted ? 0 : Math.round(vol * 100));
        player.playVideo();
        startedAtRef.current = Date.now();
      } catch {
        /* offline or blocked — stay quiet */
      }
      return;
    }
    /* direct audio (mp3 / uploads / streams) */
    if (audio) {
      try {
        ytRef.current?.pauseVideo?.();
      } catch {
        /* ignore */
      }
      const absolute = new URL(track.url, window.location.href).href;
      if (audio.src !== absolute) audio.src = absolute;
      audio.volume = Math.min(1, Math.max(0, vol));
      audio.muted = isMuted;
      startedAtRef.current = Date.now();
      void audio.play().catch(() => undefined);
    }
  }, [ensurePlayer, pauseAll]);

  const restartCurrent = useCallback(() => {
    const { tracks, index } = playStateRef.current;
    const track = tracks[index];
    if (!track) return;
    const kind = trackKind(track);
    startedAtRef.current = Date.now();
    if (kind === "youtube" && ytRef.current) {
      try {
        ytRef.current.seekTo(0, true);
        ytRef.current.playVideo();
      } catch {
        /* ignore */
      }
    } else if (kind === "audio" && audioRef.current) {
      audioRef.current.currentTime = 0;
      void audioRef.current.play().catch(() => undefined);
    }
  }, []);

  const setMusicIndex = useCallback((i: number) => {
    setMusicIndexState(i);
    setPlaying(true);
  }, []);

  const nextTrack = useCallback(() => {
    const { index, tracks, shuffle: shuf } = playStateRef.current;
    if (!tracks.length) return;
    let target: number;
    if (shuf && tracks.length > 1) {
      do {
        target = Math.floor(Math.random() * tracks.length);
      } while (target === index);
    } else {
      target = (index + 1) % tracks.length;
    }
    if (target === index) {
      restartRef.current?.();
      setPlaying(true);
      return;
    }
    setMusicIndexState(target);
    setPlaying(true);
  }, []);

  const prevTrack = useCallback(() => {
    const { index, tracks } = playStateRef.current;
    if (!tracks.length) return;
    /* if we are deep into a track, rewind it instead of going back */
    const audio = audioRef.current;
    if (audio && !audio.paused && audio.currentTime > 4) {
      audio.currentTime = 0;
      return;
    }
    if (ytRef.current && trackKind(tracks[index]) === "youtube") {
      try {
        if (ytRef.current.getCurrentTime?.() > 4) {
          ytRef.current.seekTo(0, true);
          return;
        }
      } catch {
        /* ignore */
      }
    }
    setMusicIndexState((index - 1 + tracks.length) % tracks.length);
    setPlaying(true);
  }, []);

  const toggleShuffle = useCallback(() => setShuffle((s) => !s), []);
  const togglePlay = useCallback(() => setPlaying((p) => !p), []);

  /* wire imperative refs */
  useEffect(() => {
    advanceRef.current = () => {
      if (Date.now() - startedAtRef.current < 1200) return;
      nextTrack();
    };
    restartRef.current = restartCurrent;
  }, [nextTrack, restartCurrent]);

  /* drive playback when state changes */
  const currentTrackId = activeTracks[musicIndex]?.id ?? null;
  useEffect(() => {
    void syncPlayback();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [syncPlayback, playing, currentTrackId, muted, volume, playlistId]);

  /* clamp index if the active list shrinks */
  useEffect(() => {
    if (activeTracks.length > 0 && musicIndex >= activeTracks.length) {
      setMusicIndexState(0);
    }
  }, [activeTracks.length, musicIndex]);

  const day = data?.today ?? todayKey();
  const seededPick = <T,>(items: T[], salt: string): T | undefined => {
    if (!items.length) return undefined;
    const seed = `${day}:${salt}`;
    let h = 7;
    for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) | 0;
    return items[Math.abs(h) % items.length];
  };
  const dbQuotes = (data?.quotes ?? []).map((q) => q.text);
  const dbMotivations = (data?.motivations ?? []).map((m) => m.text);
  const quote = seededPick(dbQuotes, "quote") ?? QUOTES[Number(day.slice(-2)) % QUOTES.length];
  const motivation = seededPick(dbMotivations, "motivation") ?? MOTIVATIONS[Number(day.replaceAll("-", "")) % MOTIVATIONS.length];

  const value = useMemo<Ctx>(
    () => ({
      ready,
      data,
      reload,
      focusMode,
      setFocusMode,
      sidebarOpen,
      setSidebarOpen,
      search,
      setSearch,
      searchResults,
      timer: {
        type: timerType,
        remaining,
        running,
        sessionId,
        subjectId,
        label: formatTime(remaining),
      },
      setTimerType: (t) => {
        setTimerType(t);
        if (!running) setRemaining(durationForType(t));
      },
      setTimerSubject: setSubjectId,
      startTimer,
      pauseTimer,
      resetTimer,
      music: { index: musicIndex, playing, muted, volume, playlistId, tracks: activeTracks, shuffle },
      setMusicIndex,
      setPlaylistId: (id) => {
        setPlaylistId(id);
        setMusicIndexState(0);
        setPlaying(true);
      },
      togglePlay,
      nextTrack: () => nextTrack(),
      prevTrack,
      toggleShuffle,
      setMuted,
      setVolume,
      darkMode,
      setDarkMode,
      desktopMode,
      setDesktopMode,
      isMobile,
      quote,
      motivation,
    }),
    [
      ready,
      data,
      reload,
      focusMode,
      sidebarOpen,
      search,
      searchResults,
      timerType,
      remaining,
      running,
      sessionId,
      subjectId,
      startTimer,
      pauseTimer,
      resetTimer,
      musicIndex,
      playing,
      muted,
      volume,
      playlistId,
      activeTracks,
      shuffle,
      setMusicIndex,
      nextTrack,
      prevTrack,
      toggleShuffle,
      togglePlay,
      darkMode,
      setDarkMode,
      desktopMode,
      setDesktopMode,
      isMobile,
      quote,
      motivation,
    ],
  );

  return (
    <KawaiiCtx.Provider value={value}>
      {children}
      {/* persistent hidden players (survive route changes so music never stops) */}
      <div className="pointer-events-none fixed -left-[9999px] top-0 h-px w-px overflow-hidden" aria-hidden="true">
        <div ref={ytHostRef} />
      </div>
      <audio
        ref={audioRef}
        className="hidden"
        preload="auto"
        onEnded={() => advanceRef.current?.()}
        onError={() => {
          window.setTimeout(() => advanceRef.current?.(), 1200);
        }}
      />
    </KawaiiCtx.Provider>
  );
}

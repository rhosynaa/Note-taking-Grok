"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { DEFAULT_COVERS } from "@/lib/types";
import { api, useKawaii } from "./provider";

export function NotesBoard() {
  const { data, reload } = useKawaii();
  const params = useSearchParams();
  const tagFilter = params.get("tag");
  const [q, setQ] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [creating, setCreating] = useState(false);

  const notes = (data?.notes ?? []).filter((n) => !n.archived);
  const tags = data?.tags ?? [];
  const noteTags = data?.noteTags ?? [];
  const subjects = data?.subjects ?? [];
  const tasks = data?.tasks ?? [];

  const filtered = useMemo(() => {
    return notes.filter((n) => {
      if (subjectId && n.subjectId !== subjectId) return false;
      if (q && !n.title.toLowerCase().includes(q.toLowerCase())) return false;
      if (tagFilter) {
        const ids = noteTags.filter((l) => l.noteId === n.id).map((l) => l.tagId);
        if (!ids.includes(tagFilter)) return false;
      }
      return true;
    });
  }, [notes, subjectId, q, tagFilter, noteTags]);

  const done = tasks.filter((t) => t.completed).length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;

  async function createNote() {
    setCreating(true);
    try {
      const cover = DEFAULT_COVERS[Math.floor(Math.random() * DEFAULT_COVERS.length)];
      const row = await api<{ id: string }>("/api/notes", {
        method: "POST",
        body: JSON.stringify({ title: "Untitled note", coverImage: cover, templateId: "blank-page" }),
      });
      window.location.href = `/notes/${row.id}`;
    } finally {
      setCreating(false);
    }
  }

  async function togglePin(id: string, pinned: boolean) {
    await api(`/api/notes/${id}`, { method: "PATCH", body: JSON.stringify({ pinned: !pinned }) });
    await reload();
  }

  const dueToday = tasks.filter((t) => {
    if (!t.dueDate || t.completed) return false;
    return new Date(t.dueDate).toDateString() === new Date().toDateString();
  });

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div>
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="font-[var(--font-fredoka)] text-4xl text-fuchsia-700">Dashboard</h1>
            <p className="text-sm text-pink-500">Every note wears a cover — swap them anytime, like stickers on a binder.</p>
          </div>
          <button className="pink-btn" onClick={createNote} disabled={creating}>
            + New note
          </button>
        </div>
        <div className="mb-4 flex flex-wrap gap-2">
          <input
            className="rounded-full border-2 border-pink-200 px-3 py-2 text-sm"
            placeholder="Search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <select
            className="rounded-full border-2 border-pink-200 bg-white px-3 py-2 text-sm"
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
          >
            <option value="">All subjects</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered
            .slice()
            .sort((a, b) => Number(b.pinned) - Number(a.pinned))
            .map((n) => {
              const sub = subjects.find((s) => s.id === n.subjectId);
              const related = tasks.filter((t) => t.noteId === n.id || t.subjectId === n.subjectId);
              const doneN = related.filter((t) => t.completed).length;
              const p = related.length ? Math.round((doneN / related.length) * 100) : 0;
              const due = related.find((t) => t.dueDate && !t.completed)?.dueDate;
              return (
                <article key={n.id} className="cover-card">
                  <Link href={`/notes/${n.id}`} className="block">
                    <div className="relative">
                      <img src={n.coverImage || "/covers/starry-clouds.jpg"} alt="" />
                      <span className="absolute right-2 top-2 rounded-full bg-white/90 px-2 py-1 text-xs font-extrabold text-fuchsia-600">
                        {p}%
                      </span>
                    </div>
                    <div className="p-3">
                      <p className="font-bold leading-tight text-fuchsia-900">{n.title}</p>
                      <p className="mt-1 text-xs text-pink-400">
                        {sub?.name ?? "Unfiled"} {n.pinned ? "· pinned" : ""}
                      </p>
                      <p className="mt-2 text-xs font-bold text-pink-500">Due {due ? new Date(due).toLocaleDateString() : "None"}</p>
                    </div>
                  </Link>
                  <div className="flex justify-end gap-2 px-3 pb-3">
                    <button className="ghost-btn" onClick={() => togglePin(n.id, n.pinned)}>
                      {n.pinned ? "Unpin" : "Pin"}
                    </button>
                    <Link className="ghost-btn" href={`/notes/${n.id}?cover=1`}>
                      Cover
                    </Link>
                  </div>
                </article>
              );
            })}
        </div>
      </div>
      <aside className="flex flex-col gap-3">
        <section className="card">
          <div className="mb-2 flex justify-between text-sm font-bold">
            <span>To-Do</span>
            <span>{done}/{tasks.length}</span>
          </div>
          <div className="mx-auto h-28 w-28 rounded-full" style={{ background: `conic-gradient(#ec4899 0 ${pct}%, #fce7f3 ${pct}% 100%)` }} />
          <p className="mt-2 text-center text-sm font-bold text-fuchsia-600">{pct}%</p>
        </section>
        <section className="card">
          <h2 className="card-title mb-2">Due Today</h2>
          {dueToday.length === 0 && <p className="empty-state">Nothing due — stretch time.</p>}
          {dueToday.map((t) => (
            <p key={t.id} className="mb-2 rounded-xl bg-pink-50 px-2 py-2 text-sm">
              {t.title}
            </p>
          ))}
        </section>
      </aside>
    </div>
  );
}

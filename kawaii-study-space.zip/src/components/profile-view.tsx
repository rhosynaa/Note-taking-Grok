"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { DEFAULT_COVERS } from "@/lib/types";
import { api, useKawaii } from "./provider";

type Prefs = {
  autoSync?: boolean;
  pomodoroMinutes?: number;
  shortBreakMinutes?: number;
  longBreakMinutes?: number;
  heroImage?: string;
  dashboardArt?: string;
  musicArt?: string;
  google?: { connected?: boolean; email?: string; name?: string; connectedAt?: string };
};

async function uploadImage(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(file);
  });
  const asset = await api<{ id: string; url: string }>("/api/assets", {
    method: "POST",
    body: JSON.stringify({ name: file.name, mimeType: file.type, data: dataUrl, kind: "image" }),
  });
  return asset.url;
}

function ImageField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <div className="rounded-2xl bg-pink-50 p-3">
      <p className="text-xs font-extrabold uppercase tracking-wide text-pink-500">{label}</p>
      <div className="mt-2 flex items-center gap-3">
        <img src={value} alt="" className="h-16 w-16 rounded-2xl border-2 border-pink-200 object-cover" />
        <div className="grid grid-cols-2 gap-1">
          {DEFAULT_COVERS.map((c) => (
            <button
              key={c}
              onClick={() => onChange(c)}
              className={`overflow-hidden rounded-lg border-4 ${value === c ? "border-pink-400" : "border-transparent"}`}
              title={c}
            >
              <img src={c} alt="" className="h-8 w-12 object-cover" />
            </button>
          ))}
        </div>
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        <label className="ghost-btn cursor-pointer">
          {busy ? "Uploading…" : "Upload"}
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              setBusy(true);
              try {
                onChange(await uploadImage(f));
              } finally {
                setBusy(false);
                e.target.value = "";
              }
            }}
          />
        </label>
        <input
          className="min-w-0 flex-1 rounded-xl border-2 border-pink-200 px-2 py-1 text-xs"
          placeholder="…or paste an image URL"
          value={value.startsWith("/api/assets") || value.startsWith("data:") ? "" : value}
          onChange={(e) => e.target.value && onChange(e.target.value)}
        />
      </div>
    </div>
  );
}

export function ProfileView() {
  const { data, reload } = useKawaii();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [avatar, setAvatar] = useState("/art/avatar-student.jpg");
  const [avatarBusy, setAvatarBusy] = useState(false);
  const [prefs, setPrefs] = useState<Prefs>({});
  const [googleEmail, setGoogleEmail] = useState("");
  const [googleName, setGoogleName] = useState("");
  const [showGoogleForm, setShowGoogleForm] = useState(false);
  const [saved, setSaved] = useState("");

  useEffect(() => {
    if (!data) return;
    setName(data.user.name ?? "");
    setEmail(data.user.email ?? "");
    setAvatar(data.user.avatar || "/art/avatar-student.jpg");
    setPrefs((data.user.preferences ?? {}) as Prefs);
  }, [data?.user.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!data) return <div className="empty-state">Opening your profile… 🌸</div>;

  const google = prefs.google ?? {};
  const googleConnected = Boolean(google.connected);
  const setPref = <K extends keyof Prefs>(k: K, v: Prefs[K]) => setPrefs((p) => ({ ...p, [k]: v }));

  async function save(partial?: { name?: string; email?: string; avatar?: string | null; googleId?: string | null; preferences?: Record<string, unknown> }) {
    setSaved("Saving…");
    try {
      await api("/api/bootstrap", {
        method: "POST",
        body: JSON.stringify(
          partial ?? {
            name,
            email,
            avatar,
            preferences: {
              autoSync: prefs.autoSync ?? true,
              pomodoroMinutes: prefs.pomodoroMinutes ?? 25,
              shortBreakMinutes: prefs.shortBreakMinutes ?? 5,
              longBreakMinutes: prefs.longBreakMinutes ?? 15,
              heroImage: prefs.heroImage,
              dashboardArt: prefs.dashboardArt,
              musicArt: prefs.musicArt,
              google,
            },
          },
        ),
      });
      await reload();
      setSaved("Saved ✓");
    } catch {
      setSaved("Couldn't save — try again");
    }
    window.setTimeout(() => setSaved(""), 2500);
  }

  async function connectGoogle() {
    if (!googleEmail.trim()) return;
    const g = {
      connected: true,
      email: googleEmail.trim(),
      name: googleName.trim() || googleEmail.trim().split("@")[0],
      connectedAt: new Date().toISOString(),
    };
    setPrefs((p) => ({ ...p, google: g }));
    await save({ googleId: googleEmail.trim(), preferences: { google: g } });
    setShowGoogleForm(false);
  }

  async function disconnectGoogle() {
    const g = { connected: false };
    setPrefs((p) => ({ ...p, google: g }));
    await save({ googleId: null, preferences: { google: g } });
  }

  async function syncNow() {
    setSaved("Syncing…");
    await reload();
    setSaved("Synced ✓");
    window.setTimeout(() => setSaved(""), 2500);
  }

  const notesCount = (data.notes ?? []).filter((n) => !n.archived).length;
  const tasksDone = (data.tasks ?? []).filter((t) => t.completed).length;
  const tasksTotal = (data.tasks ?? []).length;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Profile settings 🌸</h1>
          <p className="text-sm text-pink-500">Your identity, Google login, sync, and dashboard style — all in one place.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-pink-500">{saved}</span>
          <button className="pink-btn" onClick={() => save()}>
            Save all changes
          </button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="card">
          <h2 className="card-title mb-3">Identity</h2>
          <div className="flex items-center gap-4">
            <img src={avatar} alt="Avatar preview" className="h-20 w-20 rounded-3xl border-2 border-pink-200 object-cover" />
            <div className="flex flex-col gap-2">
              <label className="ghost-btn cursor-pointer text-center">
                {avatarBusy ? "Uploading…" : "Upload avatar"}
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  className="hidden"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    setAvatarBusy(true);
                    try {
                      setAvatar(await uploadImage(f));
                    } finally {
                      setAvatarBusy(false);
                      e.target.value = "";
                    }
                  }}
                />
              </label>
              <button className="ghost-btn" onClick={() => setAvatar("/art/avatar-student.jpg")}>
                Reset to default
              </button>
            </div>
          </div>
          <input
            className="mt-3 w-full rounded-xl border-2 border-pink-200 px-2 py-1 text-xs"
            placeholder="…or paste an avatar image URL"
            value={avatar.startsWith("/api/assets") || avatar.startsWith("data:") ? "" : avatar}
            onChange={(e) => e.target.value && setAvatar(e.target.value)}
          />
          <label className="mt-3 block text-xs font-bold text-pink-500">
            Username
            <input className="mt-1 w-full rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm text-fuchsia-900" value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="mt-2 block text-xs font-bold text-pink-500">
            Email
            <input className="mt-1 w-full rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm text-fuchsia-900" value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <button className="pink-btn mt-3 !shadow-none" onClick={() => save({ name, email, avatar })}>
            Save identity
          </button>
        </section>

        <section className="card">
          <h2 className="card-title mb-3">Google integration</h2>
          {googleConnected ? (
            <div className="rounded-2xl bg-green-50 p-3">
              <p className="text-sm font-bold text-green-700">✓ Connected as {google.name || google.email}</p>
              <p className="text-xs text-green-600">{google.email}</p>
              {google.connectedAt && <p className="mt-1 text-[11px] text-green-500">Linked {new Date(google.connectedAt).toLocaleString()}</p>}
              <button className="ghost-btn mt-2" onClick={disconnectGoogle}>
                Disconnect Google account
              </button>
            </div>
          ) : (
            <div>
              <p className="text-sm text-pink-700">No Google account linked yet. Link one to personalize your workspace identity.</p>
              {!showGoogleForm ? (
                <button className="pink-btn mt-3" onClick={() => setShowGoogleForm(true)}>
                  <span className="mr-2 inline-grid h-5 w-5 place-items-center rounded-full bg-white text-xs">G</span>
                  Log in with Google
                </button>
              ) : (
                <div className="mt-3 flex flex-col gap-2 rounded-2xl bg-pink-50 p-3">
                  <input
                    className="rounded-xl border-2 border-pink-200 px-2 py-1 text-sm"
                    placeholder="Google email (you@gmail.com)"
                    value={googleEmail}
                    onChange={(e) => setGoogleEmail(e.target.value)}
                  />
                  <input
                    className="rounded-xl border-2 border-pink-200 px-2 py-1 text-sm"
                    placeholder="Display name (optional)"
                    value={googleName}
                    onChange={(e) => setGoogleName(e.target.value)}
                  />
                  <div className="flex gap-2">
                    <button className="pink-btn !shadow-none" onClick={connectGoogle}>
                      Connect Google account
                    </button>
                    <button className="ghost-btn" onClick={() => setShowGoogleForm(false)}>
                      Cancel
                    </button>
                  </div>
                  <p className="text-[11px] text-pink-500">Stored only in your own study database — see the <Link href="/help#google" className="underline">guide</Link>.</p>
                </div>
              )}
            </div>
          )}

          <h2 className="card-title mb-2 mt-6">Auto-sync</h2>
          <label className="flex cursor-pointer items-center justify-between rounded-2xl bg-pink-50 px-3 py-2">
            <span className="text-sm font-bold text-fuchsia-900">
              Auto-sync workspace
              <span className="block text-[11px] font-normal text-pink-500">Refresh from the database every 30 seconds</span>
            </span>
            <input
              type="checkbox"
              className="h-5 w-5 accent-pink-500"
              checked={prefs.autoSync ?? true}
              onChange={(e) => {
                setPref("autoSync", e.target.checked);
                save({ preferences: { autoSync: e.target.checked } });
              }}
            />
          </label>
          <button className="ghost-btn mt-2" onClick={syncNow}>
            Sync now
          </button>
        </section>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="card">
          <h2 className="card-title mb-3">Focus timers</h2>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["pomodoroMinutes", "Pomodoro", 25],
                ["shortBreakMinutes", "Short break", 5],
                ["longBreakMinutes", "Long break", 15],
              ] as const
            ).map(([key, label, fallback]) => (
              <label key={key} className="block text-xs font-bold text-pink-500">
                {label} (min)
                <input
                  type="number"
                  min={1}
                  className="mt-1 w-full rounded-xl border-2 border-pink-200 px-2 py-1 text-sm text-fuchsia-900"
                  value={prefs[key] ?? fallback}
                  onChange={(e) => setPref(key, Number(e.target.value) || fallback)}
                />
              </label>
            ))}
          </div>
          <button
            className="pink-btn mt-3 !shadow-none"
            onClick={() =>
              save({
                preferences: {
                  pomodoroMinutes: prefs.pomodoroMinutes ?? 25,
                  shortBreakMinutes: prefs.shortBreakMinutes ?? 5,
                  longBreakMinutes: prefs.longBreakMinutes ?? 15,
                },
              })
            }
          >
            Save timers
          </button>
          <h2 className="card-title mb-2 mt-6">Your stats</h2>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-2xl bg-pink-50 p-2">
              <p className="text-2xl font-extrabold text-fuchsia-700">{notesCount}</p>
              <p className="text-[11px] font-bold text-pink-500">Notes</p>
            </div>
            <div className="rounded-2xl bg-pink-50 p-2">
              <p className="text-2xl font-extrabold text-fuchsia-700">
                {tasksDone}/{tasksTotal}
              </p>
              <p className="text-[11px] font-bold text-pink-500">Tasks done</p>
            </div>
            <div className="rounded-2xl bg-pink-50 p-2">
              <p className="text-2xl font-extrabold text-fuchsia-700">{data.analytics.streak}</p>
              <p className="text-[11px] font-bold text-pink-500">Day streak</p>
            </div>
          </div>
        </section>

        <section className="card">
          <h2 className="card-title mb-1">Dashboard appearance</h2>
          <p className="mb-3 text-xs text-pink-500">Every picture on your dashboard can be swapped — pick, upload, or paste a link, then save.</p>
          <div className="flex flex-col gap-3">
            <ImageField label="Greeting hero image" value={prefs.heroImage || "/art/hero-study.jpg"} onChange={(v) => setPref("heroImage", v)} />
            <ImageField label="Dashboard side art" value={prefs.dashboardArt || "/covers/night-cat.jpg"} onChange={(v) => setPref("dashboardArt", v)} />
            <ImageField label="Music card art" value={prefs.musicArt || "/art/avatar-student.jpg"} onChange={(v) => setPref("musicArt", v)} />
          </div>
          <button
            className="pink-btn mt-3 !shadow-none"
            onClick={() =>
              save({ preferences: { heroImage: prefs.heroImage, dashboardArt: prefs.dashboardArt, musicArt: prefs.musicArt } })
            }
          >
            Save appearance
          </button>
        </section>
      </div>
    </div>
  );
}

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ELEMENT_LIBRARY, baseText, newId } from "@/lib/elements";
import { SHAPES, makeShape, shapeCenter, toggleConnection, type ShapeKind } from "@/lib/shapes";
import { STICKERS, STICKER_CATEGORIES, makeSticker } from "@/lib/stickers";
import { getTemplate } from "@/lib/templates";
import type { CanvasElement } from "@/lib/types";
import { DEFAULT_COVERS } from "@/lib/types";
import { api, useKawaii } from "./provider";

type NotePayload = {
  id: string;
  title: string;
  content: CanvasElement[];
  coverImage: string | null;
  background: string | null;
  canvasWidth: number;
  canvasHeight: number;
  subjectId: string | null;
  templateId: string | null;
  kind: string;
  tagIds?: string[];
};

export function NoteEditor({ noteId }: { noteId: string }) {
  const { data, reload } = useKawaii();
  const [note, setNote] = useState<NotePayload | null>(null);
  const [els, setEls] = useState<CanvasElement[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [title, setTitle] = useState("");
  const [coverOpen, setCoverOpen] = useState(false);
  const [panel, setPanel] = useState<"elements" | "stickers" | "shapes" | "covers">("elements");
  const [panelOpen, setPanelOpen] = useState(true);
  const [imgUrl, setImgUrl] = useState("");
  const [saving, setSaving] = useState("");
  const [connectMode, setConnectMode] = useState(false);
  const [pasteUrl, setPasteUrl] = useState("");
  const history = useRef<CanvasElement[][]>([]);
  const wrapRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ id: string; dx: number; dy: number } | null>(null);
  const saveTimer = useRef<number | null>(null);

  const load = useCallback(async () => {
    const n = await api<NotePayload>(`/api/notes/${noteId}`);
    setNote(n);
    setTitle(n.title);
    setEls(Array.isArray(n.content) ? (n.content as CanvasElement[]) : []);
  }, [noteId]);

  useEffect(() => {
    load().catch(() => undefined);
  }, [load]);

  useEffect(() => {
    if (typeof window !== "undefined" && window.location.search.includes("cover=1")) setCoverOpen(true);
  }, []);

  const pushHist = (next: CanvasElement[]) => {
    history.current = [...history.current.slice(-40), els];
    setEls(next);
  };

  const persist = useCallback(
    (patch: Record<string, unknown>) => {
      setSaving("Saving…");
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
      saveTimer.current = window.setTimeout(async () => {
        try {
          await api(`/api/notes/${noteId}`, { method: "PATCH", body: JSON.stringify(patch) });
          setSaving("Saved");
        } catch {
          setSaving("Couldn't save");
        }
      }, 400);
    },
    [noteId],
  );

  useEffect(() => {
    if (!note) return;
    persist({ content: els, title });
  }, [els, title, note, persist]);

  const tmpl = note?.templateId ? getTemplate(note.templateId) : undefined;
  const paper = tmpl?.paper ?? "plain";
  const sel = els.filter((e) => selected.includes(e.id));
  const primary = sel[0];

  function canvasPoint(ev: React.MouseEvent) {
    const box = wrapRef.current?.querySelector(".page")?.getBoundingClientRect();
    if (!box) return { x: 40, y: 40 };
    const scale = box.width / (note?.canvasWidth || 900);
    return { x: (ev.clientX - box.left) / scale, y: (ev.clientY - box.top) / scale };
  }

  function onPageClick(ev: React.MouseEvent) {
    if ((ev.target as HTMLElement).closest(".canvas-el")) return;
    const pt = canvasPoint(ev);
    const el = baseText({
      x: pt.x,
      y: pt.y,
      w: 280,
      h: 36,
      content: "",
      z: els.length + 1,
    });
    pushHist([...els, el]);
    setSelected([el.id]);
  }

  function onMove(ev: React.MouseEvent) {
    if (!drag.current) return;
    const pt = canvasPoint(ev);
    setEls((curr) =>
      curr.map((e) =>
        e.id === drag.current?.id ? { ...e, x: pt.x - drag.current.dx, y: pt.y - drag.current.dy } : e,
      ),
    );
  }

  function updatePrimary(patch: Partial<CanvasElement>) {
    if (!primary) return;
    pushHist(els.map((e) => (e.id === primary.id ? { ...e, ...patch, style: { ...e.style, ...(patch.style ?? {}) } } : e)));
  }

  async function uploadFile(file: File, asCover = false) {
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = reject;
      r.readAsDataURL(file);
    });
    const asset = await api<{ id: string; url: string }>("/api/assets", {
      method: "POST",
      body: JSON.stringify({
        name: file.name,
        mimeType: file.type,
        data: dataUrl,
        kind: file.type.startsWith("audio") ? "audio" : "image",
      }),
    });
    if (asCover) {
      await api(`/api/notes/${noteId}`, { method: "PATCH", body: JSON.stringify({ coverImage: asset.url }) });
      setNote((n) => (n ? { ...n, coverImage: asset.url } : n));
    }
    await reload();
    return asset;
  }

  async function setCover(url: string) {
    await api(`/api/notes/${noteId}`, { method: "PATCH", body: JSON.stringify({ coverImage: url }) });
    setNote((n) => (n ? { ...n, coverImage: url } : n));
  }

  async function copyCoverLink() {
    const url = note?.coverImage || "";
    const abs = url.startsWith("http") ? url : `${window.location.origin}${url}`;
    await navigator.clipboard.writeText(abs);
    setSaving("Cover link copied");
  }

  if (!note) return <div className="empty-state">Opening notebook…</div>;

  const w = note.canvasWidth || 900;
  const h = note.canvasHeight || 1200;

  return (
    <div className="flex min-h-0 flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <input
          className="min-w-[160px] flex-1 rounded-2xl border-2 border-pink-200 bg-white px-3 py-2 font-[var(--font-fredoka)] text-xl text-fuchsia-800"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <select
          className="rounded-2xl border-2 border-pink-200 bg-white px-2 py-2 text-sm"
          value={note.subjectId ?? ""}
          onChange={async (e) => {
            const subjectId = e.target.value || null;
            await api(`/api/notes/${noteId}`, { method: "PATCH", body: JSON.stringify({ subjectId }) });
            setNote({ ...note, subjectId });
          }}
        >
          <option value="">No subject</option>
          {(data?.subjects ?? []).map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <button className="ghost-btn" onClick={() => setCoverOpen(true)}>
          Cover
        </button>
        <button className="ghost-btn" onClick={() => setPanelOpen((v) => !v)} title="Collapse or expand the tools panel">
          {panelOpen ? "Hide tools ▾" : "Show tools ▸"}
        </button>
        <button
          className="ghost-btn"
          onClick={async () => {
            await api("/api/templates", {
              method: "POST",
              body: JSON.stringify({ name: `${title} template`, fromNoteId: noteId }),
            });
            setSaving("Saved as template");
            await reload();
          }}
        >
          Save template
        </button>
        <span className="text-xs text-pink-400">{saving}</span>
      </div>

      <div className="toolbar">
        {["Bold", "Italic", "Underline", "StrikeThrough"].map((cmd) => (
          <button key={cmd} className="ghost-btn" onMouseDown={(e) => { e.preventDefault(); document.execCommand(cmd); }}>
            {cmd.slice(0, 1)}
          </button>
        ))}
        <select
          className="ghost-btn"
          onChange={(e) => primary && updatePrimary({ style: { ...primary.style, fontFamily: e.target.value } })}
        >
          {["Nunito, sans-serif", "Fredoka, sans-serif", "Caveat, cursive", "Patrick Hand, cursive", "Pacifico, cursive", "Georgia, serif"].map((f) => (
            <option key={f}>{f}</option>
          ))}
        </select>
        <input
          type="color"
          title="Text color"
          onChange={(e) => primary && updatePrimary({ style: { ...primary.style, color: e.target.value } })}
        />
        <input
          type="color"
          title="Fill"
          onChange={(e) => primary && updatePrimary({ style: { ...primary.style, background: e.target.value, fill: e.target.value } })}
        />
        <button className="ghost-btn" onClick={() => history.current.length && setEls(history.current.pop() || els)}>
          Undo
        </button>
        <button className="ghost-btn" onClick={() => primary && updatePrimary({ locked: !primary.locked })}>
          {primary?.locked ? "Unlock" : "Lock"}
        </button>
        <button
          className="ghost-btn"
          onClick={() => {
            if (!primary) return;
            const copy = { ...primary, id: newId(primary.type), x: primary.x + 16, y: primary.y + 16 };
            pushHist([...els, copy]);
          }}
        >
          Duplicate
        </button>
        <button className="ghost-btn" onClick={() => pushHist(els.filter((e) => !selected.includes(e.id)))}>
          Delete
        </button>
        <button className={`ghost-btn ${connectMode ? "active" : ""}`} onClick={() => setConnectMode((v) => !v)}>
          Connect shapes
        </button>
      </div>

      {primary?.type === "image" && (
        <div className="card">
          <div className="flex flex-wrap items-center gap-2">
            <img src={primary.content} alt="" className="h-10 w-10 rounded-lg border-2 border-pink-200 object-cover" />
            <span className="text-[11px] font-extrabold uppercase tracking-wide text-pink-500">Selected image source</span>
            <input
              className="min-w-[160px] flex-1 rounded-xl border-2 border-pink-200 px-2 py-1 text-xs"
              placeholder="Paste a new image URL…"
              value={imgUrl}
              onChange={(e) => setImgUrl(e.target.value)}
            />
            <button
              className="pink-btn !shadow-none"
              onClick={() => {
                if (!imgUrl.trim()) return;
                updatePrimary({ content: imgUrl.trim() });
                setImgUrl("");
              }}
            >
              Use
            </button>
            <label className="ghost-btn cursor-pointer">
              Upload
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const asset = await uploadFile(f);
                  updatePrimary({ content: asset.url });
                  e.target.value = "";
                }}
              />
            </label>
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {DEFAULT_COVERS.map((c) => (
              <button key={c} onClick={() => updatePrimary({ content: c })} title={c}>
                <img src={c} alt="" className="h-10 w-14 rounded-lg border-2 border-pink-100 object-cover hover:border-pink-400" />
              </button>
            ))}
            {(data?.assets ?? [])
              .filter((a) => a.kind === "image")
              .slice(0, 12)
              .map((a) => (
                <button key={a.id} onClick={() => updatePrimary({ content: a.url || `/api/assets/${a.id}` })} title={a.name}>
                  <img src={a.url || `/api/assets/${a.id}`} alt={a.name} className="h-10 w-14 rounded-lg border-2 border-pink-100 object-cover hover:border-pink-400" />
                </button>
              ))}
          </div>
        </div>
      )}

      <div className={`grid gap-3 ${panelOpen ? "lg:grid-cols-[220px_1fr]" : "lg:grid-cols-[1fr]"}`}>
        {panelOpen && (
        <aside className="card h-fit">
          <div className="mb-2 flex flex-wrap gap-1">
            {(["elements", "stickers", "shapes", "covers"] as const).map((p) => (
              <button key={p} className={`ghost-btn ${panel === p ? "active" : ""}`} onClick={() => setPanel(p)}>
                {p}
              </button>
            ))}
          </div>
          {panel === "elements" &&
            ELEMENT_LIBRARY.map((item) => (
              <button
                key={item.id}
                className="mb-1 w-full rounded-xl bg-pink-50 px-2 py-2 text-left text-sm"
                onClick={() => {
                  const el = item.factory();
                  el.x = 60;
                  el.y = 80 + els.length * 8;
                  pushHist([...els, el]);
                }}
              >
                {item.name}
                <span className="block text-[11px] text-pink-400">{item.hint}</span>
              </button>
            ))}
          {panel === "stickers" && (
            <div>
              {STICKER_CATEGORIES.map((cat) => (
                <div key={cat} className="mb-2">
                  <p className="text-[11px] font-extrabold uppercase tracking-wide text-pink-400">{cat}</p>
                  <div className="flex flex-wrap gap-1">
                    {STICKERS.filter((s) => s.category === cat).map((s) => (
                      <button
                        key={s.id}
                        className="text-2xl"
                        onClick={() => pushHist([...els, makeSticker(s.id, { x: 80, y: 80, z: els.length + 1 })])}
                      >
                        {s.emoji}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
          {panel === "shapes" && (
            <div className="grid grid-cols-2 gap-2">
              {SHAPES.map((s) => (
                <button
                  key={s.id}
                  className="ghost-btn"
                  onClick={() => pushHist([...els, makeShape(s.id as ShapeKind, { x: 120, y: 140, z: els.length + 1 })])}
                >
                  {s.name}
                </button>
              ))}
            </div>
          )}
          {panel === "covers" && (
            <CoverPicker
              current={note.coverImage}
              assets={data?.assets ?? []}
              pasteUrl={pasteUrl}
              setPasteUrl={setPasteUrl}
              onSet={setCover}
              onUpload={(f) => uploadFile(f, true)}
              onCopy={copyCoverLink}
            />
          )}
        </aside>
        )}

        <div ref={wrapRef} className="overflow-auto rounded-3xl border-2 border-pink-200 bg-pink-50/50 p-3" onMouseMove={onMove} onMouseUp={() => (drag.current = null)}>
          <div
            className={`page paper-${paper} relative mx-auto shadow-xl`}
            style={{ width: w, height: h, backgroundColor: note.background || undefined, maxWidth: "100%" }}
            onClick={onPageClick}
          >
            <svg className="pointer-events-none absolute inset-0 h-full w-full">
              {els
                .filter((e) => e.type === "shape")
                .flatMap((e) =>
                  (e.connections ?? []).map((cid) => {
                    const o = els.find((x) => x.id === cid);
                    if (!o) return null;
                    const a = shapeCenter(e);
                    const b = shapeCenter(o);
                    return <line key={`${e.id}-${cid}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#f472b6" strokeWidth="2.5" />;
                  }),
                )}
            </svg>
            {els
              .slice()
              .sort((a, b) => a.z - b.z)
              .map((el) => (
                <ElView
                  key={el.id}
                  el={el}
                  selected={selected.includes(el.id)}
                  onMouseDown={(ev) => {
                    ev.stopPropagation();
                    if (el.locked) return;
                    if (connectMode && el.type === "shape") {
                      if (selected.length === 1 && selected[0] !== el.id) {
                        pushHist(toggleConnection(els, selected[0], el.id));
                        setSelected([]);
                        return;
                      }
                    }
                    setSelected([el.id]);
                    const pt = canvasPoint(ev);
                    drag.current = { id: el.id, dx: pt.x - el.x, dy: pt.y - el.y };
                  }}
                  onChange={(content) => setEls((curr) => curr.map((e) => (e.id === el.id ? { ...e, content } : e)))}
                  onMeta={(meta) => setEls((curr) => curr.map((e) => (e.id === el.id ? { ...e, meta: { ...e.meta, ...meta } } : e)))}
                />
              ))}
          </div>
        </div>
      </div>

      {coverOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-fuchsia-950/30 p-4" onClick={() => setCoverOpen(false)}>
          <div className="card max-h-[90vh] w-full max-w-lg overflow-auto" onClick={(e) => e.stopPropagation()}>
            <h2 className="font-[var(--font-fredoka)] text-2xl text-fuchsia-700">Note cover</h2>
            <CoverPicker
              current={note.coverImage}
              assets={data?.assets ?? []}
              pasteUrl={pasteUrl}
              setPasteUrl={setPasteUrl}
              onSet={async (url) => {
                await setCover(url);
                setCoverOpen(false);
              }}
              onUpload={(f) => uploadFile(f, true)}
              onCopy={copyCoverLink}
            />
            <button className="ghost-btn mt-3" onClick={() => setCoverOpen(false)}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function CoverPicker({
  current,
  assets,
  pasteUrl,
  setPasteUrl,
  onSet,
  onUpload,
  onCopy,
}: {
  current: string | null;
  assets: { id: string; name: string; url?: string; kind: string }[];
  pasteUrl: string;
  setPasteUrl: (v: string) => void;
  onSet: (url: string) => void;
  onUpload: (f: File) => void;
  onCopy: () => void;
}) {
  return (
    <div className="mt-2 flex flex-col gap-3">
      <p className="text-xs font-bold text-pink-500">Default kawaii covers</p>
      <div className="grid grid-cols-2 gap-2">
        {DEFAULT_COVERS.map((c) => (
          <button key={c} onClick={() => onSet(c)} className={`overflow-hidden rounded-xl border-4 ${current === c ? "border-pink-400" : "border-transparent"}`}>
            <img src={c} alt="" className="h-20 w-full object-cover" />
          </button>
        ))}
      </div>
      <p className="text-xs font-bold text-pink-500">Your uploads</p>
      <div className="grid grid-cols-3 gap-2">
        {assets
          .filter((a) => a.kind === "image")
          .map((a) => (
            <button key={a.id} onClick={() => onSet(a.url || `/api/assets/${a.id}`)}>
              <img src={a.url || `/api/assets/${a.id}`} alt={a.name} className="h-16 w-full rounded-lg object-cover" />
            </button>
          ))}
      </div>
      <label className="ghost-btn cursor-pointer text-center">
        Upload image
        <input
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])}
        />
      </label>
      <div className="flex gap-2">
        <input
          className="min-w-0 flex-1 rounded-xl border-2 border-pink-200 px-2 py-1 text-sm"
          placeholder="Paste image URL or /api/assets/…"
          value={pasteUrl}
          onChange={(e) => setPasteUrl(e.target.value)}
        />
        <button className="pink-btn !shadow-none" onClick={() => pasteUrl && onSet(pasteUrl)}>
          Use
        </button>
      </div>
      <button className="ghost-btn" onClick={onCopy}>
        Copy current cover link
      </button>
    </div>
  );
}

function ElView({
  el,
  selected,
  onMouseDown,
  onChange,
  onMeta,
}: {
  el: CanvasElement;
  selected: boolean;
  onMouseDown: (e: React.MouseEvent) => void;
  onChange: (c: string) => void;
  onMeta: (m: Record<string, unknown>) => void;
}) {
  const style: React.CSSProperties = {
    left: el.x,
    top: el.y,
    width: el.w,
    height: el.h,
    transform: `rotate(${el.rotation ?? 0}deg)`,
    opacity: el.opacity ?? 1,
    zIndex: el.z,
    ...el.style,
  };
  return (
    <div className={`canvas-el ${selected ? "selected" : ""}`} data-locked={el.locked ? "true" : "false"} style={style} onMouseDown={onMouseDown}>
      {el.type === "sticker" && <div className="grid h-full place-items-center">{el.content}</div>}
      {el.type === "image" && <img src={el.content} alt="" className="h-full w-full object-cover" draggable={false} />}
      {el.type === "shape" && <ShapeSvg el={el} />}
      {el.type === "progress" && (
        <div className="p-2">
          <p className="text-xs font-bold">{String(el.meta?.label ?? "Progress")}</p>
          <div className="progress-track mt-1">
            <div className="progress-fill" style={{ width: `${Number(el.content) || 0}%`, background: String(el.meta?.color || "#f9a8d4") }} />
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={Number(el.content) || 0}
            onChange={(e) => onChange(e.target.value)}
          />
        </div>
      )}
      {el.type === "todo" && <TodoBlock content={el.content} onChange={onChange} />}
      {el.type === "chart" && <ChartBlock el={el} />}
      {el.type === "table" && <TableBlock content={el.content} onChange={onChange} />}
      {el.type === "columns" && <ColumnsBlock content={el.content} onChange={onChange} />}
      {el.type === "divider" && <hr className="mt-2 border-pink-300" />}
      {["text", "heading", "callout", "list", "html", "widget"].includes(el.type) && (
        <DirectType el={el} onChange={onChange} />
      )}
      {el.type === "shape" && (
        <textarea
          className="absolute inset-0 resize-none bg-transparent p-3 text-center text-xs outline-none"
          value={String(el.meta?.text ?? "")}
          onChange={(e) => onMeta({ text: e.target.value })}
        />
      )}
    </div>
  );
}

function DirectType({ el, onChange }: { el: CanvasElement; onChange: (c: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    if (document.activeElement === ref.current) return;
    if (ref.current.innerText !== el.content) ref.current.innerText = el.content || "";
  }, [el.content]);
  return (
    <div
      ref={ref}
      contentEditable={!el.locked}
      suppressContentEditableWarning
      className="h-full w-full overflow-auto outline-none"
      style={{ whiteSpace: "pre-wrap" }}
      onBlur={(e) => onChange(e.currentTarget.innerText)}
    />
  );
}

function ShapeSvg({ el }: { el: CanvasElement }) {
  const kind = String(el.meta?.kind || el.content);
  const fill = el.style.fill || "#fce7f3";
  const stroke = el.style.stroke || "#f9a8d4";
  return (
    <svg viewBox="0 0 100 100" className="h-full w-full">
      {kind === "circle" && <circle cx="50" cy="50" r="44" fill={fill} stroke={stroke} strokeWidth="3" />}
      {kind === "rectangle" && <rect x="6" y="18" width="88" height="64" fill={fill} stroke={stroke} strokeWidth="3" />}
      {kind === "rounded" && <rect x="6" y="18" width="88" height="64" rx="16" fill={fill} stroke={stroke} strokeWidth="3" />}
      {kind === "diamond" && <polygon points="50,6 94,50 50,94 6,50" fill={fill} stroke={stroke} strokeWidth="3" />}
      {kind === "star" && (
        <polygon points="50,8 61,38 94,38 67,58 78,90 50,70 22,90 33,58 6,38 39,38" fill={fill} stroke={stroke} strokeWidth="3" />
      )}
      {kind === "hex" && <polygon points="50,6 90,28 90,72 50,94 10,72 10,28" fill={fill} stroke={stroke} strokeWidth="3" />}
      {kind === "arrow" && <polygon points="8,40 60,40 60,22 94,50 60,78 60,60 8,60" fill={fill} stroke={stroke} strokeWidth="3" />}
      {kind === "heart" && (
        <path d="M50 86 C20 62 8 42 8 28 A18 18 0 0 1 50 22 A18 18 0 0 1 92 28 C92 42 80 62 50 86Z" fill={fill} stroke={stroke} strokeWidth="3" />
      )}
      {kind === "cloud" && (
        <g fill={fill} stroke={stroke} strokeWidth="3">
          <circle cx="34" cy="52" r="22" />
          <circle cx="58" cy="40" r="24" />
          <circle cx="74" cy="54" r="18" />
        </g>
      )}
      {kind === "blob" && <ellipse cx="50" cy="52" rx="36" ry="30" fill={fill} stroke={stroke} strokeWidth="3" />}
    </svg>
  );
}

function TodoBlock({ content, onChange }: { content: string; onChange: (c: string) => void }) {
  let items: { text: string; done: boolean }[] = [];
  try {
    items = JSON.parse(content);
  } catch {
    items = [];
  }
  return (
    <div className="flex h-full flex-col gap-1 overflow-auto p-2 text-sm">
      {items.map((it, i) => (
        <label key={i} className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={it.done}
            onChange={() => {
              const next = items.map((x, idx) => (idx === i ? { ...x, done: !x.done } : x));
              onChange(JSON.stringify(next));
            }}
          />
          <input
            className="min-w-0 flex-1 bg-transparent outline-none"
            value={it.text}
            onChange={(e) => {
              const next = items.map((x, idx) => (idx === i ? { ...x, text: e.target.value } : x));
              onChange(JSON.stringify(next));
            }}
          />
        </label>
      ))}
      <button
        className="text-left text-xs text-pink-400"
        onClick={() => onChange(JSON.stringify([...items, { text: "New item", done: false }]))}
      >
        + item
      </button>
    </div>
  );
}

function ChartBlock({ el }: { el: CanvasElement }) {
  let cfg: { kind?: string; shade?: string; fn?: string; label?: string } = {};
  try {
    cfg = JSON.parse(el.content);
  } catch {
    cfg = {};
  }
  return (
    <svg viewBox="0 0 200 140" className="h-full w-full">
      <text x="100" y="16" textAnchor="middle" fontSize="10" fill="#7c3aed">
        {cfg.label || cfg.kind}
      </text>
      {cfg.kind === "bell" && (
        <>
          <path d="M10 110 Q 100 10 190 110" fill="none" stroke="#7c3aed" strokeWidth="2" />
          {cfg.shade === "two" && <path d="M10 110 Q 40 70 55 90 L 55 110 Z M145 90 Q 160 70 190 110 L 145 110 Z" fill="#f9a8d4" opacity="0.7" />}
          {cfg.shade === "left" && <path d="M10 110 Q 40 70 70 85 L 70 110 Z" fill="#86efac" opacity="0.7" />}
          <line x1="10" y1="110" x2="190" y2="110" stroke="#cbd5e1" />
        </>
      )}
      {cfg.kind === "fn" && (
        <>
          <line x1="20" y1="120" x2="180" y2="120" stroke="#94a3b8" />
          <line x1="100" y1="20" x2="100" y2="120" stroke="#94a3b8" />
          {cfg.fn === "x2" && <path d="M40 120 Q 100 20 160 120" fill="none" stroke="#2563eb" strokeWidth="2" />}
          {cfg.fn === "sqrt" && <path d="M40 100 Q 90 40 170 30" fill="none" stroke="#db2777" strokeWidth="2" />}
          {cfg.fn === "inv" && <path d="M40 40 L 160 110" fill="none" stroke="#7c3aed" strokeWidth="2" />}
        </>
      )}
    </svg>
  );
}

function TableBlock({ content, onChange }: { content: string; onChange: (c: string) => void }) {
  let data = { cells: [["", ""], ["", ""]] as string[][] };
  try {
    data = JSON.parse(content);
  } catch {
    /* keep */
  }
  return (
    <div className="grid h-full gap-px bg-pink-100 p-1" style={{ gridTemplateColumns: `repeat(${data.cells[0]?.length || 2}, 1fr)` }}>
      {data.cells.flatMap((row, r) =>
        row.map((cell, c) => (
          <input
            key={`${r}-${c}`}
            className="bg-white px-1 text-xs outline-none"
            value={cell}
            onChange={(e) => {
              const next = data.cells.map((rr, ri) => rr.map((cc, ci) => (ri === r && ci === c ? e.target.value : cc)));
              onChange(JSON.stringify({ ...data, cells: next }));
            }}
          />
        )),
      )}
    </div>
  );
}

function ColumnsBlock({ content, onChange }: { content: string; onChange: (c: string) => void }) {
  let data = { cols: 2, texts: ["", ""] };
  try {
    data = JSON.parse(content);
  } catch {
    /* keep */
  }
  return (
    <div className="grid h-full gap-2 p-2" style={{ gridTemplateColumns: `repeat(${data.cols || 2}, 1fr)` }}>
      {data.texts.map((t, i) => (
        <textarea
          key={i}
          className="h-full resize-none rounded-xl bg-white/80 p-2 text-xs outline-none"
          value={t}
          onChange={(e) => {
            const texts = data.texts.map((x, idx) => (idx === i ? e.target.value : x));
            onChange(JSON.stringify({ ...data, texts }));
          }}
        />
      ))}
    </div>
  );
}

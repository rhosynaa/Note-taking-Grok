"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Pause, Play, Shuffle, SkipBack, SkipForward, Volume2, VolumeX } from "lucide-react";
import { TEMPLATES } from "@/lib/templates";
import { formatHours, formatTime, hoursLabel } from "@/lib/timer";
import { api, trackEmbed, trackKind, trackThumb, useKawaii } from "./provider";
import { DEFAULT_COVERS } from "@/lib/types";

const TEMPLATE_FONTS = ["Nunito, sans-serif", "Fredoka, sans-serif", "Caveat, cursive", "Patrick Hand, cursive", "Pacifico, cursive", "Georgia, serif"];
const TEMPLATE_PAPERS = ["plain", "lined", "grid", "dots", "cream", "pink", "navy"] as const;

export function TemplatesView() {
  const { data, reload } = useKawaii();
  async function createFrom(id: string, kind = "note") {
    const row = await api<{ id: string }>("/api/notes", {
      method: "POST",
      body: JSON.stringify({ templateId: id, kind }),
    });
    window.location.href = `/notes/${row.id}`;
  }
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Individual Templates</h1>
      <p className="mb-4 text-sm text-pink-500">Each reference kept its own layout, type, and color story — nothing was mashed into one generic page.</p>
      <TemplateBuilder />
      <h2 className="mb-3 mt-6 font-[var(--font-fredoka)] text-xl text-fuchsia-700">Template gallery</h2>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {TEMPLATES.map((t) => (
          <article key={t.id} className="cover-card">
            <img src={t.cover} alt="" />
            <div className="p-3">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-pink-400">{t.category}</p>
              <h2 className="font-bold text-fuchsia-900">{t.name}</h2>
              <p className="mt-1 text-xs text-pink-500">{t.description}</p>
              <button className="pink-btn mt-3 !shadow-none" onClick={() => createFrom(t.id, t.category === "Mind Map" ? "mindmap" : "note")}>
                Use template
              </button>
            </div>
          </article>
        ))}
        {(data?.customTemplates ?? []).map((t) => (
          <CustomTemplateCard key={t.id} t={t} />
        ))}
      </div>
    </div>
  );
}

function CustomTemplateCard({ t }: { t: { id: string; name: string; category: string; thumbnail: string | null; data: Record<string, unknown> } }) {
  const { data, reload } = useKawaii();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(t.name);
  const [category, setCategory] = useState(t.category);
  const [thumbnail, setThumbnail] = useState(t.thumbnail || DEFAULT_COVERS[0]);
  const [fromNoteId, setFromNoteId] = useState("");
  const notes = (data?.notes ?? []).filter((n) => !n.archived);

  return (
    <article className="cover-card">
      <img src={t.thumbnail || DEFAULT_COVERS[0]} alt="" />
      <div className="p-3">
        <p className="text-[11px] font-extrabold uppercase tracking-wide text-pink-400">Yours · {t.category}</p>
        <h2 className="font-bold">{t.name}</h2>
        <button
          className="pink-btn mt-3 !shadow-none"
          onClick={async () => {
            const d = t.data as { elements?: unknown[]; background?: string; width?: number; height?: number };
            const row = await api<{ id: string }>("/api/notes", {
              method: "POST",
              body: JSON.stringify({
                title: t.name,
                content: d.elements ?? [],
                background: d.background,
                canvasWidth: d.width,
                canvasHeight: d.height,
                coverImage: t.thumbnail,
              }),
            });
            window.location.href = `/notes/${row.id}`;
          }}
        >
          Duplicate
        </button>
        <div className="mt-2 flex gap-2">
          <button className="ghost-btn flex-1" onClick={() => setEditing((v) => !v)}>
            {editing ? "Close" : "Edit"}
          </button>
          <button
            className="ghost-btn flex-1"
            onClick={async () => {
              if (!window.confirm(`Delete template "${t.name}"?`)) return;
              await api("/api/templates", { method: "POST", body: JSON.stringify({ id: t.id, _delete: true }) });
              await reload();
            }}
          >
            Delete
          </button>
        </div>
        {editing && (
          <div className="mt-2 flex flex-col gap-2 rounded-2xl bg-pink-50 p-2">
            <input className="rounded-xl border-2 border-pink-200 px-2 py-1 text-sm" value={name} onChange={(e) => setName(e.target.value)} placeholder="Template name" />
            <input className="rounded-xl border-2 border-pink-200 px-2 py-1 text-sm" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Category" />
            <div className="grid grid-cols-4 gap-1">
              {DEFAULT_COVERS.map((c) => (
                <button key={c} onClick={() => setThumbnail(c)} className={`overflow-hidden rounded-lg border-4 ${thumbnail === c ? "border-pink-400" : "border-transparent"}`}>
                  <img src={c} alt="" className="!h-10 w-full object-cover" />
                </button>
              ))}
            </div>
            <input className="rounded-xl border-2 border-pink-200 px-2 py-1 text-xs" value={thumbnail} onChange={(e) => setThumbnail(e.target.value)} placeholder="Thumbnail URL" />
            <button
              className="pink-btn !shadow-none"
              onClick={async () => {
                await api("/api/templates", { method: "POST", body: JSON.stringify({ id: t.id, name, category, thumbnail }) });
                setEditing(false);
                await reload();
              }}
            >
              Save changes
            </button>
            <div className="border-t-2 border-pink-100 pt-2">
              <p className="text-[11px] font-extrabold uppercase text-pink-400">Update design from note</p>
              <div className="mt-1 flex gap-1">
                <select className="min-w-0 flex-1 rounded-xl border-2 border-pink-200 px-2 py-1 text-xs" value={fromNoteId} onChange={(e) => setFromNoteId(e.target.value)}>
                  <option value="">Pick a note…</option>
                  {notes.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.title}
                    </option>
                  ))}
                </select>
                <button
                  className="ghost-btn"
                  onClick={async () => {
                    if (!fromNoteId) return;
                    await api("/api/templates", { method: "POST", body: JSON.stringify({ id: t.id, fromNoteId }) });
                    await reload();
                  }}
                >
                  Update
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </article>
  );
}

function TemplateBuilder() {
  const { reload } = useKawaii();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("note");
  const [paper, setPaper] = useState<string>("lined");
  const [background, setBackground] = useState("#fffdf8");
  const [font, setFont] = useState(TEMPLATE_FONTS[0]);
  const [cover, setCover] = useState<string>(DEFAULT_COVERS[0]);
  const [busy, setBusy] = useState(false);

  async function create() {
    if (!name.trim() || busy) return;
    setBusy(true);
    try {
      const stamp = Date.now();
      const elements = [
        { id: `tpl-h-${stamp}`, type: "heading", x: 60, y: 50, w: 780, h: 64, z: 1, content: name.trim(), style: { fontFamily: font, color: "#9d174d", fontSize: "34px" } },
        { id: `tpl-t-${stamp}`, type: "text", x: 60, y: 140, w: 780, h: 200, z: 2, content: "Start writing your beautiful notes here…", style: { fontFamily: font, color: "#4a3558", fontSize: "16px" } },
        { id: `tpl-c-${stamp}`, type: "callout", x: 60, y: 360, w: 780, h: 90, z: 3, content: "Tip: decorate me with stickers, shapes, and images, then press Save template to keep the new look.", style: { fontFamily: font, background: "#fdf2f8", color: "#9d174d" } },
        { id: `tpl-todo-${stamp}`, type: "todo", x: 60, y: 470, w: 780, h: 120, z: 4, content: "☐ First task\n☐ Second task", style: { fontFamily: font, color: "#4a3558" } },
      ];
      await api("/api/templates", {
        method: "POST",
        body: JSON.stringify({
          name: name.trim(),
          category: category.trim() || "custom",
          thumbnail: cover,
          data: { elements, background, paper, width: 900, height: 1200, font },
        }),
      });
      setName("");
      setOpen(false);
      await reload();
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <section className="card flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-pink-50 to-violet-50">
        <div>
          <h2 className="font-[var(--font-fredoka)] text-lg text-fuchsia-700">✨ Create your own template</h2>
          <p className="text-xs text-pink-500">Saw a layout you love? Build it here with your own paper, colors, fonts, and cover — or recreate it in a note and press “Save template”.</p>
        </div>
        <button className="pink-btn" onClick={() => setOpen(true)}>
          + New template
        </button>
      </section>
    );
  }

  return (
    <section className="card bg-gradient-to-b from-pink-50 to-white">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-[var(--font-fredoka)] text-lg text-fuchsia-700">✨ Create your own template</h2>
        <button className="text-xs font-bold text-pink-400" onClick={() => setOpen(false)}>
          ✕
        </button>
      </div>
      <div className="grid gap-2 md:grid-cols-2">
        <input className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm" placeholder="Template name (e.g. Coral lecture notes)" value={name} onChange={(e) => setName(e.target.value)} />
        <select className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm" value={category} onChange={(e) => setCategory(e.target.value)}>
          {["note", "mindmap", "planner", "journal", "study", "flashcard", "custom"].map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <label className="flex items-center gap-2 rounded-2xl border-2 border-pink-200 bg-white px-3 py-2 text-sm">
          Paper
          <select className="ml-auto rounded-xl border border-pink-200 px-2 py-1" value={paper} onChange={(e) => setPaper(e.target.value)}>
            {TEMPLATE_PAPERS.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </label>
        <label className="flex items-center gap-2 rounded-2xl border-2 border-pink-200 bg-white px-3 py-2 text-sm">
          Background
          <input type="color" className="ml-auto h-8 w-12 cursor-pointer" value={background} onChange={(e) => setBackground(e.target.value)} />
        </label>
      </div>
      <label className="mt-2 block text-xs font-bold text-pink-500">
        Starter font
        <select className="mt-1 w-full rounded-2xl border-2 border-pink-200 bg-white px-3 py-2 text-sm" value={font} onChange={(e) => setFont(e.target.value)}>
          {TEMPLATE_FONTS.map((f) => (
            <option key={f} value={f} style={{ fontFamily: f }}>
              {f.split(",")[0]}
            </option>
          ))}
        </select>
      </label>
      <p className="mb-1 mt-2 text-xs font-bold text-pink-500">Cover</p>
      <div className="grid grid-cols-4 gap-2">
        {DEFAULT_COVERS.map((c) => (
          <button key={c} onClick={() => setCover(c)} className={`overflow-hidden rounded-xl border-4 ${cover === c ? "border-pink-400" : "border-transparent"}`}>
            <img src={c} alt="" className="!h-16 w-full object-cover" />
          </button>
        ))}
      </div>
      <input
        className="mt-2 w-full rounded-xl border-2 border-pink-200 px-2 py-1 text-xs"
        placeholder="…or paste a cover image URL"
        value={cover.startsWith("/api/assets") ? "" : cover}
        onChange={(e) => e.target.value && setCover(e.target.value)}
      />
      <div className="mt-3 flex gap-2">
        <button className="pink-btn" onClick={create} disabled={busy}>
          {busy ? "Creating…" : "Create template"}
        </button>
        <button className="ghost-btn" onClick={() => setOpen(false)}>
          Cancel
        </button>
      </div>
    </section>
  );
}

export function SubjectsView() {
  const { data, reload } = useKawaii();
  const [name, setName] = useState("");
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Subjects</h1>
      <div className="mt-4 flex gap-2">
        <input className="rounded-2xl border-2 border-pink-200 px-3 py-2" placeholder="New subject" value={name} onChange={(e) => setName(e.target.value)} />
        <button
          className="pink-btn"
          onClick={async () => {
            if (!name.trim()) return;
            await api("/api/subjects", { method: "POST", body: JSON.stringify({ name }) });
            setName("");
            await reload();
          }}
        >
          Add
        </button>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {(data?.analytics.subjects ?? []).map((s) => (
          <article key={s.id} className="card">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold">
                {s.icon} {s.name}
              </h2>
              <button
                className="ghost-btn"
                onClick={async () => {
                  await api("/api/subjects", { method: "POST", body: JSON.stringify({ id: s.id, _delete: true }) });
                  await reload();
                }}
              >
                Remove
              </button>
            </div>
            <p className="text-sm text-pink-500">{hoursLabel(s.minutes, s.targetMinutes)}</p>
            <div className="progress-track mt-2">
              <div className="progress-fill" style={{ width: `${s.pct}%`, background: s.color }} />
            </div>
            <label className="mt-2 block text-xs">
              Target minutes
              <input
                type="number"
                className="ml-2 w-24 rounded-lg border border-pink-200 px-2"
                defaultValue={s.targetMinutes}
                onBlur={async (e) => {
                  await api("/api/subjects", {
                    method: "POST",
                    body: JSON.stringify({ id: s.id, targetMinutes: Number(e.target.value) }),
                  });
                  await reload();
                }}
              />
            </label>
            <ProjectsFor subjectId={s.id} />
          </article>
        ))}
      </div>
    </div>
  );
}

function ProjectsFor({ subjectId }: { subjectId: string }) {
  const { data, reload } = useKawaii();
  const list = (data?.projects ?? []).filter((p) => p.subjectId === subjectId);
  const [name, setName] = useState("");
  return (
    <div className="mt-3 rounded-2xl bg-pink-50 p-2">
      <p className="text-xs font-extrabold uppercase text-pink-400">Projects</p>
      {list.map((p) => (
        <p key={p.id} className="text-sm">
          {p.name} · target {p.targetMinutes}m
        </p>
      ))}
      <div className="mt-1 flex gap-1">
        <input className="min-w-0 flex-1 rounded-lg border border-pink-200 px-2 text-sm" value={name} onChange={(e) => setName(e.target.value)} placeholder="Project name" />
        <button
          className="ghost-btn"
          onClick={async () => {
            if (!name.trim()) return;
            await api("/api/projects", { method: "POST", body: JSON.stringify({ name, subjectId }) });
            setName("");
            await reload();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}

export function CalendarView() {
  const { data, reload } = useKawaii();
  const [cursor, setCursor] = useState(() => new Date());
  const [selectedDay, setSelectedDay] = useState<number | null>(new Date().getDate());
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("medium");
  const [subjectId, setSubjectId] = useState("");
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const tasks = data?.tasks ?? [];
  const subjects = data?.subjects ?? [];
  const subName = (id: string | null) => subjects.find((s) => s.id === id)?.name ?? "No subject";

  function tasksFor(d: number) {
    return tasks.filter(
      (t) =>
        t.dueDate &&
        new Date(t.dueDate).getFullYear() === year &&
        new Date(t.dueDate).getMonth() === month &&
        new Date(t.dueDate).getDate() === d,
    );
  }

  async function toggleTask(id: string, completed: boolean) {
    await api("/api/tasks", { method: "POST", body: JSON.stringify({ id, completed }) });
    await reload();
  }

  async function deleteTask(id: string) {
    await api("/api/tasks", { method: "POST", body: JSON.stringify({ id, _delete: true }) });
    await reload();
  }

  async function addDeadline() {
    if (!title.trim() || !selectedDay) return;
    await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({
        title: title.trim(),
        dueDate: new Date(year, month, selectedDay, 12, 0, 0).toISOString(),
        priority,
        subjectId: subjectId || null,
      }),
    });
    setTitle("");
    await reload();
  }

  const selectedDateLabel = selectedDay
    ? new Date(year, month, selectedDay).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })
    : null;
  const selectedTasks = selectedDay ? tasksFor(selectedDay) : [];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <button className="ghost-btn" onClick={() => setCursor(new Date(year, month - 1, 1))}>
          ‹
        </button>
        <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">
          {cursor.toLocaleString("en-US", { month: "long", year: "numeric" })}
        </h1>
        <button className="ghost-btn" onClick={() => setCursor(new Date(year, month + 1, 1))}>
          ›
        </button>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-pink-500">Click any day to add a deadline straight onto that date.</p>
        <Link href="/tasks" className="pink-btn !shadow-none">
          Open all tasks →
        </Link>
      </div>
      <div className="grid grid-cols-7 gap-2">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
          <div key={d} className="text-center text-xs font-extrabold text-pink-400">
            {d}
          </div>
        ))}
        {cells.map((d, i) => {
          const dayTasks = d ? tasksFor(d) : [];
          const isSelected = d !== null && d === selectedDay;
          return (
            <div
              key={i}
              onClick={() => d && setSelectedDay(d)}
              className={`min-h-24 cursor-pointer rounded-2xl border-2 bg-white p-2 transition ${
                isSelected ? "border-pink-400 shadow-md" : "border-pink-100 hover:border-pink-300"
              }`}
            >
              <p className="text-xs font-bold text-fuchsia-500">{d ?? ""}</p>
              {dayTasks.map((t) => (
                <div
                  key={t.id}
                  className={`group mt-1 flex items-center gap-1 rounded-lg px-1 text-[11px] ${t.completed ? "bg-green-100" : "bg-pink-100"}`}
                >
                  <button
                    className={`min-w-0 flex-1 truncate text-left ${t.completed ? "line-through" : ""}`}
                    title="Toggle complete"
                    onClick={async (e) => {
                      e.stopPropagation();
                      await toggleTask(t.id, !t.completed);
                    }}
                  >
                    {t.title}
                  </button>
                  <button
                    className="shrink-0 rounded px-1 font-extrabold text-rose-400 opacity-0 hover:bg-rose-100 group-hover:opacity-100"
                    title="Delete deadline"
                    onClick={async (e) => {
                      e.stopPropagation();
                      await deleteTask(t.id);
                    }}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {selectedDay && (
        <section className="card">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="card-title">Deadlines · {selectedDateLabel}</h2>
            <button className="text-xs font-bold text-pink-400" onClick={() => setSelectedDay(null)}>
              ✕
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            <input
              className="min-w-[180px] flex-1 rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
              placeholder="Deadline title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addDeadline()}
            />
            <select className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm" value={priority} onChange={(e) => setPriority(e.target.value)} title="Priority">
              <option value="low">Low priority</option>
              <option value="medium">Medium priority</option>
              <option value="high">High priority</option>
            </select>
            <select className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm" value={subjectId} onChange={(e) => setSubjectId(e.target.value)} title="Subject">
              <option value="">No subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.icon} {s.name}
                </option>
              ))}
            </select>
            <button className="pink-btn" onClick={addDeadline}>
              Add deadline
            </button>
          </div>
          <div className="mt-3 flex flex-col gap-2">
            {selectedTasks.length === 0 && <p className="empty-state">No deadlines on this day yet.</p>}
            {selectedTasks.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-2xl bg-pink-50 px-3 py-2">
                <input type="checkbox" checked={t.completed} onChange={() => toggleTask(t.id, !t.completed)} />
                <span className={`flex-1 text-sm font-bold ${t.completed ? "text-pink-300 line-through" : "text-fuchsia-900"}`}>
                  {t.title}
                </span>
                <PriorityBadge priority={t.priority} />
                <span className="text-xs text-pink-400">{subName(t.subjectId)}</span>
                <button className="ghost-btn" onClick={() => deleteTask(t.id)}>
                  Delete
                </button>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  const p = (priority || "normal").toLowerCase();
  const cls =
    p === "high"
      ? "bg-rose-100 text-rose-600"
      : p === "medium"
        ? "bg-amber-100 text-amber-700"
        : p === "low"
          ? "bg-green-100 text-green-700"
          : "bg-pink-100 text-pink-600";
  return <span className={`rounded-full px-2 py-0.5 text-[11px] font-extrabold ${cls}`}>{p}</span>;
}

export function TasksView() {
  const { data, reload } = useKawaii();
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("medium");
  const [due, setDue] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "completed">("all");
  const [subjectFilter, setSubjectFilter] = useState("");
  const subjects = data?.subjects ?? [];
  const subOf = (id: string | null) => subjects.find((s) => s.id === id);

  const filtered = (data?.tasks ?? []).filter((t) => {
    if (statusFilter === "pending" && t.completed) return false;
    if (statusFilter === "completed" && !t.completed) return false;
    if (subjectFilter === "__none__" && t.subjectId) return false;
    if (subjectFilter && subjectFilter !== "__none__" && t.subjectId !== subjectFilter) return false;
    return true;
  });

  const counts = {
    all: (data?.tasks ?? []).length,
    pending: (data?.tasks ?? []).filter((t) => !t.completed).length,
    completed: (data?.tasks ?? []).filter((t) => t.completed).length,
  };

  async function addTask() {
    if (!title.trim()) return;
    await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({
        title: title.trim(),
        priority,
        dueDate: due ? new Date(`${due}T12:00:00`).toISOString() : null,
        subjectId: subjectId || null,
      }),
    });
    setTitle("");
    setDue("");
    await reload();
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Tasks</h1>
        <Link href="/calendar" className="ghost-btn">
          ← Back to calendar
        </Link>
      </div>
      <section className="card mt-3">
        <h2 className="card-title mb-2">Add a task</h2>
        <div className="flex flex-wrap items-center gap-2">
          <input
            className="min-w-[200px] flex-1 rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
            placeholder="Task name / objective"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addTask()}
          />
          <select
            className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            title="Priority"
          >
            <option value="low">Low priority</option>
            <option value="medium">Medium priority</option>
            <option value="high">High priority</option>
          </select>
          <input
            type="date"
            className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
            value={due}
            onChange={(e) => setDue(e.target.value)}
            title="Due date"
          />
          <select
            className="rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
            title="Subject"
          >
            <option value="">No subject</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.icon} {s.name}
              </option>
            ))}
          </select>
          <button className="pink-btn" onClick={addTask}>
            Add task
          </button>
        </div>
      </section>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {(
          [
            ["all", `All (${counts.all})`],
            ["pending", `Pending (${counts.pending})`],
            ["completed", `Completed (${counts.completed})`],
          ] as const
        ).map(([v, label]) => (
          <button key={v} className={`ghost-btn ${statusFilter === v ? "active" : ""}`} onClick={() => setStatusFilter(v)}>
            {label}
          </button>
        ))}
        <select
          className="rounded-2xl border-2 border-pink-200 bg-white px-3 py-2 text-sm"
          value={subjectFilter}
          onChange={(e) => setSubjectFilter(e.target.value)}
          title="Filter by subject"
        >
          <option value="">All subjects</option>
          <option value="__none__">No subject</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.icon} {s.name}
            </option>
          ))}
        </select>
      </div>
      <div className="mt-3 flex flex-col gap-2">
        {filtered.length === 0 && <p className="empty-state">No tasks match these filters.</p>}
        {filtered.map((t) => {
          const sub = subOf(t.subjectId);
          return (
            <div key={t.id} className="card flex items-center gap-3">
              <input
                type="checkbox"
                checked={t.completed}
                onChange={async () => {
                  await api("/api/tasks", { method: "POST", body: JSON.stringify({ id: t.id, completed: !t.completed }) });
                  await reload();
                }}
              />
              <span className={`min-w-0 flex-1 truncate font-bold ${t.completed ? "text-pink-300 line-through" : "text-fuchsia-900"}`}>
                {t.title}
              </span>
              <PriorityBadge priority={t.priority} />
              {sub && (
                <span className="hidden text-xs text-pink-500 sm:inline">
                  {sub.icon} {sub.name}
                </span>
              )}
              <span className="text-xs text-pink-400">{t.dueDate ? new Date(t.dueDate).toLocaleDateString() : "No date"}</span>
              <button
                className="ghost-btn"
                onClick={async () => {
                  await api("/api/tasks", { method: "POST", body: JSON.stringify({ id: t.id, _delete: true }) });
                  await reload();
                }}
              >
                Delete
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

type FlashSide = { content?: string };

function cardQA(c: { title: string; content: unknown[] }) {
  const els = (Array.isArray(c.content) ? c.content : []) as FlashSide[];
  return { front: els[0]?.content ?? c.title, back: els[1]?.content ?? "" };
}

export function FlashcardsView() {
  const { data, reload } = useKawaii();
  const subjects = data?.subjects ?? [];
  const cards = (data?.notes ?? []).filter((n) => n.kind === "flashcard" && !n.archived);
  const [deckId, setDeckId] = useState<string | null>(null);
  const [firstSubject, setFirstSubject] = useState("");

  const unsorted = cards.filter((c) => !c.subjectId);
  const hardCards = cards.filter((c) => (c.difficulty || "good") === "hard");
  const countFor = (sid: string) => cards.filter((c) => c.subjectId === sid).length;

  if (deckId) {
    let deckCards = cards;
    let deckTitle = "Flashcards";
    let deckColor: string | undefined;
    if (deckId === "__unsorted__") {
      deckCards = unsorted;
      deckTitle = "🗂️ Unsorted";
    } else if (deckId === "__general__") {
      deckCards = cards;
      deckTitle = "🎲 General (mixed)";
    } else if (deckId === "__review__") {
      deckCards = hardCards;
      deckTitle = "🔁 Needs review";
    } else {
      deckCards = cards.filter((c) => c.subjectId === deckId);
      const deckSubject = subjects.find((s) => s.id === deckId);
      deckTitle = deckSubject ? `${deckSubject.icon} ${deckSubject.name}` : "Deck";
      deckColor = deckSubject?.color;
    }
    return (
      <DeckStudy
        deckId={deckId}
        title={deckTitle}
        color={deckColor}
        cards={deckCards.map((c) => ({ id: c.id, title: c.title, subjectId: c.subjectId, difficulty: c.difficulty || "good", ...cardQA(c) }))}
        onBack={() => setDeckId(null)}
      />
    );
  }

  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Flashcards</h1>
      <p className="mb-3 text-sm text-pink-500">Every subject is a deck — pick one to start studying.</p>
      {cards.length === 0 && (
        <section className="card mx-auto mt-6 max-w-md text-center">
          <p className="text-5xl">🃏</p>
          <h2 className="mt-2 font-[var(--font-fredoka)] text-xl text-fuchsia-700">Create your first flashcard deck</h2>
          <p className="mt-1 text-sm text-pink-500">Pick a subject and add your first card to begin.</p>
          {subjects.length > 0 ? (
            <div className="mt-3 flex gap-2">
              <select
                className="min-w-0 flex-1 rounded-2xl border-2 border-pink-200 px-3 py-2 text-sm"
                value={firstSubject || subjects[0].id}
                onChange={(e) => setFirstSubject(e.target.value)}
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.icon} {s.name}
                  </option>
                ))}
              </select>
              <button
                className="pink-btn"
                onClick={async () => {
                  const sid = firstSubject || subjects[0].id;
                  await api("/api/notes", {
                    method: "POST",
                    body: JSON.stringify({
                      title: "My first question",
                      kind: "flashcard",
                      subjectId: sid,
                      coverImage: DEFAULT_COVERS[1],
                      content: [
                        { id: "q", type: "text", x: 40, y: 40, w: 700, h: 80, z: 1, content: "My first question", style: {} },
                        { id: "a", type: "text", x: 40, y: 140, w: 700, h: 120, z: 1, content: "My first answer — press Manage to edit me!", style: {} },
                      ],
                    }),
                  });
                  await reload();
                  setDeckId(sid);
                }}
              >
                Create deck
              </button>
            </div>
          ) : (
            <Link href="/subjects" className="pink-btn mt-3 inline-block">
              Create a subject first
            </Link>
          )}
        </section>
      )}
      {cards.length > 0 && subjects.length === 0 && (
        <section className="card mx-auto mt-6 max-w-md text-center">
          <p className="text-5xl">🃏</p>
          <h2 className="mt-2 font-[var(--font-fredoka)] text-xl text-fuchsia-700">Create your first flashcard deck</h2>
          <p className="mt-1 text-sm text-pink-500">Decks are built from subjects — create one to organize your cards.</p>
          <Link href="/subjects" className="pink-btn mt-3 inline-block">
            Go to subjects
          </Link>
        </section>
      )}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.length > 0 && (
          <button className="cover-card p-4 text-left transition hover:-translate-y-0.5" onClick={() => setDeckId("__general__")}>
            <div className="flex items-center gap-3">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-pink-100 to-violet-100 text-3xl">🎲</span>
              <div className="min-w-0">
                <p className="truncate font-[var(--font-fredoka)] text-lg text-fuchsia-800">General (mixed)</p>
                <p className="text-xs font-bold text-pink-500">Random cards from every subject · {cards.length} cards</p>
              </div>
            </div>
            <span className="pink-btn mt-3 inline-block !shadow-none">Study mixed deck →</span>
          </button>
        )}
        {hardCards.length > 0 && (
          <button className="cover-card p-4 text-left transition hover:-translate-y-0.5" onClick={() => setDeckId("__review__")}>
            <div className="flex items-center gap-3">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-rose-100 text-3xl">🔁</span>
              <div className="min-w-0">
                <p className="truncate font-[var(--font-fredoka)] text-lg text-rose-700">Needs review</p>
                <p className="text-xs font-bold text-rose-400">Cards you marked hard · {hardCards.length} cards</p>
              </div>
            </div>
            <span className="pink-btn mt-3 inline-block !shadow-none">Review hard cards →</span>
          </button>
        )}
        {subjects.map((s) => {
          const count = countFor(s.id);
          return (
            <button key={s.id} className="cover-card p-4 text-left transition hover:-translate-y-0.5" onClick={() => setDeckId(s.id)}>
              <div className="flex items-center gap-3">
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-3xl" style={{ background: `${s.color}55` }}>
                  {s.icon}
                </span>
                <div className="min-w-0">
                  <p className="truncate font-[var(--font-fredoka)] text-lg text-fuchsia-800">{s.name}</p>
                  <p className="text-xs font-bold text-pink-500">
                    {count} card{count === 1 ? "" : "s"}
                  </p>
                </div>
              </div>
              <span className="pink-btn mt-3 inline-block !shadow-none">{count > 0 ? "Study deck →" : "Add cards →"}</span>
            </button>
          );
        })}
        {unsorted.length > 0 && (
          <button key="__unsorted__" className="cover-card p-4 text-left transition hover:-translate-y-0.5" onClick={() => setDeckId("__unsorted__")}>
            <div className="flex items-center gap-3">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-pink-100 text-3xl">🗂️</span>
              <div className="min-w-0">
                <p className="truncate font-[var(--font-fredoka)] text-lg text-fuchsia-800">Unsorted</p>
                <p className="text-xs font-bold text-pink-500">
                  {unsorted.length} card{unsorted.length === 1 ? "" : "s"}
                </p>
              </div>
            </div>
            <span className="pink-btn mt-3 inline-block !shadow-none">Study deck →</span>
          </button>
        )}
      </div>
    </div>
  );
}

function DeckStudy({
  deckId,
  title,
  color,
  cards,
  onBack,
}: {
  deckId: string;
  title: string;
  color?: string;
  cards: { id: string; title: string; subjectId: string | null; difficulty: string; front: string; back: string }[];
  onBack: () => void;
}) {
  const { data, reload } = useKawaii();
  const [mode, setMode] = useState<"study" | "manage">("study");
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [q, setQ] = useState("");
  const [a, setA] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editQ, setEditQ] = useState("");
  const [editA, setEditA] = useState("");

  const shuffled = useMemo(() => {
    if (deckId === "__general__" || deckId === "__review__") {
      return [...cards].sort(() => Math.random() - 0.5);
    }
    return cards;
  }, [deckId, cards]);

  const safeIndex = shuffled.length ? Math.min(index, shuffled.length - 1) : 0;
  const current = shuffled[safeIndex];

  const subName = (id: string | null) => (data?.subjects ?? []).find((s) => s.id === id)?.name;

  function go(i: number) {
    if (!shuffled.length) return;
    setIndex((i + shuffled.length) % shuffled.length);
    setFlipped(false);
  }

  async function recordReview(noteId: string, result: "pass" | "fail", difficulty: string) {
    await api("/api/flashcards/review", {
      method: "POST",
      body: JSON.stringify({ noteId, result, difficulty }),
    });
    await reload();
  }

  async function rateDifficulty(noteId: string, difficulty: "easy" | "good" | "hard") {
    await recordReview(noteId, "pass", difficulty);
  }

  async function rateResult(noteId: string, result: "pass" | "fail") {
    await recordReview(noteId, result, current?.difficulty || "good");
    setFlipped(false);
    go(safeIndex + 1);
  }

  async function addCard() {
    if (!q.trim()) return;
    await api("/api/notes", {
      method: "POST",
      body: JSON.stringify({
        title: q.trim().slice(0, 80),
        kind: "flashcard",
        subjectId: deckId === "__unsorted__" ? null : deckId,
        coverImage: DEFAULT_COVERS[1],
        content: [
          { id: "q", type: "text", x: 40, y: 40, w: 700, h: 80, z: 1, content: q.trim(), style: {} },
          { id: "a", type: "text", x: 40, y: 140, w: 700, h: 120, z: 1, content: a.trim(), style: {} },
        ],
      }),
    });
    setQ("");
    setA("");
    await reload();
  }

  async function saveCard(id: string) {
    if (!editQ.trim()) return;
    await api(`/api/notes/${id}`, {
      method: "PATCH",
      body: JSON.stringify({
        title: editQ.trim().slice(0, 80),
        content: [
          { id: "q", type: "text", x: 40, y: 40, w: 700, h: 80, z: 1, content: editQ.trim(), style: {} },
          { id: "a", type: "text", x: 40, y: 140, w: 700, h: 120, z: 1, content: editA.trim(), style: {} },
        ],
      }),
    });
    setEditingId(null);
    await reload();
  }

  async function deleteCard(id: string) {
    if (!window.confirm("Delete this card? (It moves to Trash)")) return;
    await api(`/api/notes/${id}`, { method: "DELETE" });
    setFlipped(false);
    await reload();
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button className="ghost-btn" onClick={onBack}>
            ← All decks
          </button>
          <h1 className="font-[var(--font-fredoka)] text-2xl text-fuchsia-700">{title}</h1>
        </div>
        <div className="flex gap-2">
          <button className={`ghost-btn ${mode === "study" ? "active" : ""}`} onClick={() => setMode("study")}>
            📖 Study
          </button>
          <button className={`ghost-btn ${mode === "manage" ? "active" : ""}`} onClick={() => setMode("manage")}>
            🛠️ Manage
          </button>
        </div>
      </div>

      {cards.length === 0 ? (
        <section className="card mx-auto mt-4 max-w-md text-center">
          <p className="text-5xl">🌱</p>
          <h2 className="mt-2 font-[var(--font-fredoka)] text-xl text-fuchsia-700">No cards yet — Create your first card</h2>
          <p className="mt-1 text-sm text-pink-500">This deck is empty. Add a question and answer to begin.</p>
          <button className="pink-btn mt-3" onClick={() => setMode("manage")}>
            Create your first card
          </button>
        </section>
      ) : mode === "study" && current ? (
        <div className="mx-auto flex w-full max-w-xl flex-col gap-3">
          <div className="flex items-center justify-between text-xs font-extrabold text-pink-500">
            <span>
              Card {safeIndex + 1} of {shuffled.length}
            </span>
            <span
              className={`rounded-full px-2 py-0.5 text-[11px] font-extrabold ${
                current.difficulty === "hard"
                  ? "bg-rose-100 text-rose-600"
                  : current.difficulty === "easy"
                    ? "bg-green-100 text-green-700"
                    : "bg-amber-100 text-amber-700"
              }`}
            >
              {current.difficulty === "hard" ? "hard" : current.difficulty === "easy" ? "easy" : "good"}
            </span>
          </div>
          <div className="flex gap-1 justify-center">
            {shuffled.map((c, i) => (
              <button
                key={c.id}
                onClick={() => go(i)}
                className={`h-2 w-2 rounded-full ${i === safeIndex ? "bg-pink-500" : "bg-pink-200"}`}
                title={`Card ${i + 1}`}
              />
            ))}
          </div>
          <div className="flip-scene h-72" onClick={() => setFlipped((f) => !f)}>
            <div className={`flip-inner ${flipped ? "flipped" : ""}`}>
              <div
                className="flip-face card grid place-items-center border-pink-300 text-center"
                style={color ? { background: `linear-gradient(180deg, #fff, ${color}33)` } : undefined}
              >
                <div className="px-6">
                  <p className="card-title">Question</p>
                  <p className="mt-3 font-[var(--font-fredoka)] text-2xl text-fuchsia-800">{current.front}</p>
                  {subName(current.subjectId) && (
                    <p className="mt-2 text-xs font-bold text-pink-400">📚 {subName(current.subjectId)}</p>
                  )}
                </div>
              </div>
              <div className="flip-face flip-back card grid place-items-center border-violet-300 bg-gradient-to-b from-white to-violet-50 text-center">
                <div className="px-6">
                  <p className="card-title">Answer</p>
                  <p className="mt-3 text-xl font-bold text-violet-800">{current.back || "—"}</p>
                </div>
              </div>
            </div>
          </div>
          <button className="pink-btn mx-auto" onClick={() => setFlipped((f) => !f)}>
            {flipped ? "Hide Answer" : "Show Answer"}
          </button>

          <div className="card border-2 border-pink-100 !p-3">
            <p className="card-title mb-2">Rate this card</p>
            <div className="flex items-center justify-center gap-2">
              <button
                className={`ghost-btn ${current.difficulty === "easy" ? "active" : ""}`}
                onClick={() => rateDifficulty(current.id, "easy")}
                title="Easy"
              >
                🙂 Easy
              </button>
              <button
                className={`ghost-btn ${current.difficulty === "good" ? "active" : ""}`}
                onClick={() => rateDifficulty(current.id, "good")}
                title="Good"
              >
                😊 Good
              </button>
              <button
                className={`ghost-btn ${current.difficulty === "hard" ? "active" : ""}`}
                onClick={() => rateDifficulty(current.id, "hard")}
                title="Hard"
              >
                😣 Hard
              </button>
            </div>
            <div className="mt-2 flex items-center justify-center gap-2">
              <button className="pink-btn !shadow-none" onClick={() => rateResult(current.id, "fail")}>
                ✗ Missed it
              </button>
              <button className="ghost-btn bg-green-50" onClick={() => rateResult(current.id, "pass")}>
                ✓ Got it
              </button>
            </div>
          </div>

          <div className="flex justify-between">
            <button className="ghost-btn" onClick={() => go(safeIndex - 1)}>
              ← Previous
            </button>
            <button className="ghost-btn" onClick={() => go(safeIndex + 1)}>
              Next →
            </button>
          </div>
        </div>
      ) : null}

      {mode === "manage" && (
        <section className="card">
          <h2 className="card-title mb-2">Add a card to this deck</h2>
          <div className="grid gap-2 md:grid-cols-2">
            <textarea className="min-h-20 rounded-2xl border-2 border-pink-200 p-3 text-sm" placeholder="Question" value={q} onChange={(e) => setQ(e.target.value)} />
            <textarea className="min-h-20 rounded-2xl border-2 border-pink-200 p-3 text-sm" placeholder="Answer" value={a} onChange={(e) => setA(e.target.value)} />
          </div>
          <button className="pink-btn mt-2" onClick={addCard}>
            Add card
          </button>
          <h2 className="card-title mb-2 mt-6">
            Cards in this deck ({cards.length})
          </h2>
          <div className="flex flex-col gap-2">
            {cards.map((c) => (
              <article key={c.id} className="rounded-2xl bg-pink-50 px-3 py-2">
                {editingId === c.id ? (
                  <div className="flex flex-col gap-2">
                    <textarea className="rounded-xl border-2 border-pink-200 p-2 text-sm" value={editQ} onChange={(e) => setEditQ(e.target.value)} placeholder="Question" />
                    <textarea className="rounded-xl border-2 border-pink-200 p-2 text-sm" value={editA} onChange={(e) => setEditA(e.target.value)} placeholder="Answer" />
                    <div className="flex gap-2">
                      <button className="pink-btn !shadow-none" onClick={() => saveCard(c.id)}>
                        Save
                      </button>
                      <button className="ghost-btn" onClick={() => setEditingId(null)}>
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-bold text-fuchsia-900">Q: {c.front}</p>
                      <p className="truncate text-xs text-pink-600">A: {c.back}</p>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <button
                        className="ghost-btn"
                        onClick={() => {
                          setEditingId(c.id);
                          setEditQ(c.front);
                          setEditA(c.back);
                        }}
                      >
                        Edit
                      </button>
                      <button className="ghost-btn" onClick={() => deleteCard(c.id)}>
                        Delete
                      </button>
                    </div>
                  </div>
                )}
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

export function MindMapsView() {
  const { data } = useKawaii();
  const maps = (data?.notes ?? []).filter((n) => (n.kind === "mindmap" || n.templateId === "patriotism-mindmap") && !n.archived);
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Mind Maps</h1>
      <p className="mb-3 text-sm text-pink-500">Shapes auto-connect when nearby. Use Connect mode in the editor to wire them by hand.</p>
      <div className="flex gap-2">
        <Link href="/templates" className="pink-btn">
          Start from a map template
        </Link>
        <CreateMindMap />
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {maps.map((n) => (
          <Link key={n.id} href={`/notes/${n.id}`} className="cover-card">
            <img src={n.coverImage || DEFAULT_COVERS[2]} alt="" />
            <p className="p-3 font-bold">{n.title}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

function CreateMindMap() {
  return (
    <button
      className="ghost-btn"
      onClick={async () => {
        const row = await api<{ id: string }>("/api/notes", {
          method: "POST",
          body: JSON.stringify({ templateId: "patriotism-mindmap", kind: "mindmap", title: "New mind map" }),
        });
        window.location.href = `/notes/${row.id}`;
      }}
    >
      Blank radial map
    </button>
  );
}

export function TimerView() {
  const { data, timer, startTimer, pauseTimer, resetTimer, setTimerType, setTimerSubject, reload } = useKawaii();
  const [manual, setManual] = useState({ minutes: 25, note: "", subjectId: "" });
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="card text-center">
        <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Pomodoro</h1>
        <div className="mt-3 flex justify-center gap-2">
          {(["pomodoro", "short_break", "long_break"] as const).map((t) => (
            <button key={t} className={`ghost-btn ${timer.type === t ? "active" : ""}`} onClick={() => setTimerType(t)}>
              {t.replace("_", " ")}
            </button>
          ))}
        </div>
        <p className="mt-6 font-[var(--font-fredoka)] text-7xl text-fuchsia-600">{timer.label}</p>
        <select className="mt-4 rounded-2xl border-2 border-pink-200 px-3 py-2" value={timer.subjectId ?? ""} onChange={(e) => setTimerSubject(e.target.value || null)}>
          <option value="">Link a subject</option>
          {(data?.subjects ?? []).map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <div className="mt-4 flex justify-center gap-2">
          <button className="pink-btn" onClick={() => (timer.running ? pauseTimer() : startTimer())}>
            {timer.running ? "Pause" : "Start"}
          </button>
          <button className="ghost-btn" onClick={resetTimer}>
            Reset
          </button>
        </div>
        <p className="mt-3 text-sm text-pink-500">Completed pomodoros auto-log into time entries and analytics.</p>
      </section>
      <section className="card">
        <h2 className="card-title">Manual time entry</h2>
        <div className="mt-3 flex flex-col gap-2">
          <input type="number" className="rounded-xl border-2 border-pink-200 px-2 py-1" value={manual.minutes} onChange={(e) => setManual({ ...manual, minutes: Number(e.target.value) })} />
          <select className="rounded-xl border-2 border-pink-200 px-2 py-1" value={manual.subjectId} onChange={(e) => setManual({ ...manual, subjectId: e.target.value })}>
            <option value="">Subject</option>
            {(data?.subjects ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <input className="rounded-xl border-2 border-pink-200 px-2 py-1" placeholder="Note" value={manual.note} onChange={(e) => setManual({ ...manual, note: e.target.value })} />
          <button
            className="pink-btn"
            onClick={async () => {
              await api("/api/time-entries", {
                method: "POST",
                body: JSON.stringify({
                  durationSeconds: Math.round(manual.minutes * 60),
                  subjectId: manual.subjectId || null,
                  note: manual.note,
                }),
              });
              await reload();
            }}
          >
            Log minutes
          </button>
        </div>
        <h3 className="card-title mt-6">Sessions</h3>
        <div className="mt-2 flex max-h-72 flex-col gap-2 overflow-auto">
          {(data?.timeEntries ?? []).map((e) => (
            <div key={e.id} className="flex items-center justify-between rounded-xl bg-pink-50 px-2 py-2 text-sm">
              <span>
                {e.date} · {formatTime(e.durationSeconds)} · {e.note}
              </span>
              <button
                className="ghost-btn"
                onClick={async () => {
                  await api("/api/time-entries", { method: "POST", body: JSON.stringify({ id: e.id, _delete: true }) });
                  await reload();
                }}
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export function AnalyticsView() {
  const { data } = useKawaii();
  const a = data?.analytics;
  if (!a) return <div className="empty-state">Loading analytics…</div>;
  const maxW = Math.max(1, ...a.weekly.days.map((d) => d.totalSeconds));
  const maxM = Math.max(1, ...a.monthly.days.map((d) => d.totalSeconds));
  const reviews = data?.flashcardReviews ?? [];
  const totalReviews = reviews.length;
  const passed = reviews.filter((r) => r.result === "pass").length;
  const failed = reviews.filter((r) => r.result === "fail").length;
  const easy = reviews.filter((r) => r.difficulty === "easy").length;
  const pct = (n: number) => (totalReviews ? Math.round((n / totalReviews) * 100) : 0);
  return (
    <div className="flex flex-col gap-4">
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Analytics</h1>
      <p className="text-sm text-pink-500">Every number below is computed from real time entries — empty until you study.</p>
      <div className="grid gap-3 md:grid-cols-3">
        <div className="card">
          <p className="card-title">Today</p>
          <p className="text-3xl font-bold text-fuchsia-700">{formatHours(Math.round(a.daily.totalSeconds / 60))}</p>
          <p className="text-sm">{a.daily.sessions} sessions</p>
        </div>
        <div className="card">
          <p className="card-title">This week</p>
          <p className="text-3xl font-bold text-fuchsia-700">{formatHours(Math.round(a.weekly.totalSeconds / 60))}</p>
        </div>
        <div className="card">
          <p className="card-title">30 days</p>
          <p className="text-3xl font-bold text-fuchsia-700">{formatHours(Math.round(a.monthly.totalSeconds / 60))}</p>
        </div>
      </div>
      <section className="card">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="card-title">Flashcard performance</h2>
          <span className="text-xs font-bold text-pink-400">{totalReviews} review{totalReviews === 1 ? "" : "s"}</span>
        </div>
        {totalReviews === 0 ? (
          <p className="empty-state">Rate cards while studying and your pass / fail / easy rates appear here.</p>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-2xl bg-green-50 p-3 text-center">
              <p className="text-2xl font-extrabold text-green-600">{pct(passed)}%</p>
              <p className="text-[11px] font-bold text-green-500">Passed</p>
              <div className="progress-track mt-2"><div className="progress-fill" style={{ width: `${pct(passed)}%`, background: "#4ade80" }} /></div>
            </div>
            <div className="rounded-2xl bg-rose-50 p-3 text-center">
              <p className="text-2xl font-extrabold text-rose-600">{pct(failed)}%</p>
              <p className="text-[11px] font-bold text-rose-500">Failed</p>
              <div className="progress-track mt-2"><div className="progress-fill" style={{ width: `${pct(failed)}%`, background: "#fb7185" }} /></div>
            </div>
            <div className="rounded-2xl bg-amber-50 p-3 text-center">
              <p className="text-2xl font-extrabold text-amber-600">{pct(easy)}%</p>
              <p className="text-[11px] font-bold text-amber-500">Found easy</p>
              <div className="progress-track mt-2"><div className="progress-fill" style={{ width: `${pct(easy)}%`, background: "#fbbf24" }} /></div>
            </div>
          </div>
        )}
      </section>
      <section className="card">
        <h2 className="card-title mb-3">Weekly breakdown</h2>
        <div className="flex h-40 items-end gap-2">
          {a.weekly.days.map((d) => (
            <div key={d.date} className="flex flex-1 flex-col items-center justify-end">
              <div className="w-full rounded-t-lg bg-pink-300" style={{ height: `${Math.round((d.totalSeconds / maxW) * 100)}%` }} />
              <span className="mt-1 text-[10px] text-pink-400">{d.date.slice(5)}</span>
            </div>
          ))}
        </div>
      </section>
      <section className="card">
        <h2 className="card-title mb-3">Monthly sparkline</h2>
        <div className="flex h-24 items-end gap-px">
          {a.monthly.days.map((d) => (
            <div key={d.date} className="flex-1 rounded-t bg-violet-300" style={{ height: `${Math.round((d.totalSeconds / maxM) * 100)}%` }} />
          ))}
        </div>
      </section>
      <section className="card">
        <h2 className="card-title mb-3">Subjects</h2>
        {(a.subjects ?? []).map((s) => (
          <div key={s.id} className="mb-2">
            <div className="flex justify-between text-sm">
              <span>
                {s.icon} {s.name}
              </span>
              <span>
                {s.pct}% · {hoursLabel(s.minutes, s.targetMinutes)}
              </span>
            </div>
            <div className="progress-track">
              <div className="progress-fill" style={{ width: `${s.pct}%`, background: s.color }} />
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

function EqBars({ active }: { active: boolean }) {
  return (
    <span className={`eq-bars ${active ? "on" : ""}`} aria-hidden="true">
      <i />
      <i />
      <i />
      <i />
    </span>
  );
}

export function MusicView() {
  const {
    data,
    music,
    setMusicIndex,
    setPlaylistId,
    togglePlay,
    nextTrack,
    prevTrack,
    toggleShuffle,
    reload,
    setMuted,
    setVolume,
  } = useKawaii();
  const playlists = data?.playlists ?? [];
  const allTracks = data?.tracks ?? [];
  const tracks = music.tracks ?? allTracks;
  const current = tracks[music.index];
  const kind = trackKind(current);
  const thumb = trackThumb(current);
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [newPlaylist, setNewPlaylist] = useState("");
  const [newTrackPlaylist, setNewTrackPlaylist] = useState("");

  async function createPlaylist() {
    if (!newPlaylist.trim()) return;
    await api("/api/music", { method: "POST", body: JSON.stringify({ entity: "playlist", name: newPlaylist.trim() }) });
    setNewPlaylist("");
    await reload();
  }

  async function deletePlaylist(id: string) {
    if (!window.confirm("Delete this playlist? Songs stay in your library.")) return;
    await api("/api/music", { method: "POST", body: JSON.stringify({ entity: "playlist", id, _delete: true }) });
    await reload();
  }

  async function moveTrack(trackId: string, playlistId: string | null) {
    await api("/api/music", { method: "POST", body: JSON.stringify({ entity: "track", id: trackId, playlistId }) });
    await reload();
  }

  const playlistName = (id: string | null) => (id ? playlists.find((p) => p.id === id)?.name ?? "Playlist" : "No playlist");

  return (
    <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
      <section className="card music-dock">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h1 className="font-[var(--font-fredoka)] text-3xl text-violet-700">Music</h1>
          <select
            className="max-w-[180px] rounded-xl border-2 border-violet-200 bg-white px-2 py-1 text-sm font-bold text-violet-700"
            value={music.playlistId ?? ""}
            onChange={(e) => setPlaylistId(e.target.value || null)}
            title="Play this playlist only"
          >
            <option value="">🎧 All songs</option>
            {playlists.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
        <p className="mt-1 font-bold">{current?.title ?? "Nothing queued"}</p>
        <p className="text-sm text-violet-400">
          {current?.artist}
          {current ? ` · ${playlistName(current.playlistId ?? null)}` : ""}
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-2 sm:gap-3">
          <button className="icon-btn" title="Previous track" aria-label="Previous track" onClick={() => prevTrack()}>
            <SkipBack size={16} />
          </button>
          <button className="pink-btn !rounded-full !px-6" onClick={togglePlay} aria-label={music.playing ? "Pause" : "Play"}>
            {music.playing ? (
              <span className="inline-flex items-center gap-2">
                <Pause size={16} /> Pause
              </span>
            ) : (
              <span className="inline-flex items-center gap-2">
                <Play size={16} /> Play
              </span>
            )}
          </button>
          <button className="icon-btn" title="Next track" aria-label="Next track" onClick={() => nextTrack()}>
            <SkipForward size={16} />
          </button>
          <button
            className={`ghost-btn inline-flex items-center gap-1.5 ${music.shuffle ? "active" : ""}`}
            title={music.shuffle ? "Shuffle on — playing in random order" : "Shuffle off"}
            aria-pressed={music.shuffle}
            onClick={toggleShuffle}
          >
            <Shuffle size={14} />
            <span className="text-xs">Shuffle {music.shuffle ? "on" : "off"}</span>
          </button>
          <span className="mx-1 hidden items-center gap-2 sm:inline-flex">
            <button className="icon-btn" title={music.muted ? "Unmute" : "Mute"} aria-label={music.muted ? "Unmute" : "Mute"} onClick={() => setMuted(!music.muted)}>
              {music.muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
            <input type="range" min={0} max={1} step={0.05} value={music.volume} onChange={(e) => setVolume(Number(e.target.value))} aria-label="Volume" />
          </span>
          <EqBars active={music.playing && kind !== "none"} />
        </div>
        {music.shuffle && <p className="mt-2 text-xs font-bold text-violet-500">Shuffle is on — tracks play in a surprise order.</p>}

        {kind === "youtube" && current && (
          <div className="now-playing-art mt-4">
            {thumb && <img src={thumb} alt="" />}
            <div className="now-playing-overlay">
              <p className="text-sm font-extrabold text-white drop-shadow">{music.playing ? "Now streaming from YouTube" : "Paused"}</p>
              <EqBars active={music.playing} />
            </div>
          </div>
        )}
        {kind === "spotify" && current && (
          <>
            <iframe
              className="mt-4 h-52 w-full rounded-2xl"
              src={trackEmbed(current) ?? undefined}
              title="Spotify player"
              allow="autoplay; encrypted-media"
            />
            <p className="mt-2 text-xs font-bold text-violet-500">Spotify plays in its own player above — press play inside the box.</p>
          </>
        )}
        {kind === "audio" && current && (
          <div className="now-playing-art now-playing-audio mt-4">
            <div className="now-playing-overlay !bg-none">
              <p className="text-sm font-extrabold text-violet-700">
                {music.playing ? "Playing in the background · keeps going while you study" : "Paused"}
              </p>
              <EqBars active={music.playing} />
            </div>
          </div>
        )}
        {(!current || kind === "none") && (
          <p className="empty-state">Queue up a song below — YouTube, Spotify, a direct audio link, or your own upload.</p>
        )}
      </section>

      <section className="card">
        <h2 className="card-title">Playlists</h2>
        <div className="mt-2 flex gap-2">
          <input
            className="min-w-0 flex-1 rounded-xl border-2 border-violet-200 px-2 py-1 text-sm"
            placeholder="New playlist name…"
            value={newPlaylist}
            onChange={(e) => setNewPlaylist(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && createPlaylist()}
          />
          <button className="pink-btn !shadow-none" onClick={createPlaylist}>
            + Create
          </button>
        </div>
        <div className="mt-3 flex flex-col gap-2">
          <button
            className={`flex items-center justify-between rounded-xl px-2 py-2 text-left text-sm font-bold ${music.playlistId === null ? "bg-violet-200" : "bg-violet-50"}`}
            onClick={() => setPlaylistId(null)}
          >
            <span>🎧 All songs ({allTracks.length})</span>
            <span className="text-xs text-violet-500">play</span>
          </button>
          {playlists.map((p) => {
            const count = allTracks.filter((t) => t.playlistId === p.id).length;
            return (
              <div key={p.id} className="flex items-center gap-1">
                <button
                  className={`flex min-w-0 flex-1 items-center justify-between rounded-xl px-2 py-2 text-left text-sm font-bold ${music.playlistId === p.id ? "bg-violet-200" : "bg-violet-50"}`}
                  onClick={() => setPlaylistId(p.id)}
                >
                  <span className="truncate">
                    🎵 {p.name} <span className="text-xs font-normal text-violet-400">({count})</span>
                  </span>
                  <span className="text-xs text-violet-500">play only this</span>
                </button>
                <button className="ghost-btn !px-2" title="Delete playlist" onClick={() => deletePlaylist(p.id)}>
                  ×
                </button>
              </div>
            );
          })}
        </div>
      </section>

      <section className="card lg:col-span-2">
        <h2 className="card-title">Songs {music.playlistId ? `· ${playlistName(music.playlistId)}` : "· all"}</h2>
        <div className="mt-2 flex flex-col gap-1">
          {tracks.map((t, i) => (
            <div key={t.id} className={`flex items-center gap-2 rounded-xl px-2 py-1.5 text-left ${i === music.index ? "bg-violet-100" : "bg-violet-50"}`}>
              <button className="min-w-0 flex-1 text-left" onClick={() => setMusicIndex(i)}>
                <span className="font-bold">
                  {i + 1}. {t.title}
                </span>
                <span className="ml-2 text-xs text-violet-400">{t.artist}</span>
              </button>
              <select
                className="max-w-[140px] rounded-lg border-2 border-violet-200 bg-white px-1 py-0.5 text-[11px] text-violet-700"
                value={t.playlistId ?? ""}
                title="Move to playlist"
                onChange={async (e) => moveTrack(t.id, e.target.value || null)}
              >
                <option value="">No playlist</option>
                {playlists.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              <button
                className="ghost-btn !px-2"
                title="Delete track"
                onClick={async () => {
                  await api("/api/music", { method: "POST", body: JSON.stringify({ entity: "track", id: t.id, _delete: true }) });
                  await reload();
                }}
              >
                ×
              </button>
            </div>
          ))}
          {tracks.length === 0 && <p className="empty-state">No songs here — add some below or pick “All songs”.</p>}
        </div>

        <h3 className="card-title mt-5">Add YouTube / Spotify / URL</h3>
        <div className="mt-2 flex flex-wrap gap-2">
          <input className="min-w-[160px] flex-1 rounded-xl border-2 border-violet-200 px-2 py-1" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="min-w-[160px] flex-1 rounded-xl border-2 border-violet-200 px-2 py-1" placeholder="https://…" value={url} onChange={(e) => setUrl(e.target.value)} />
          <select className="rounded-xl border-2 border-violet-200 bg-white px-2 py-1" value={newTrackPlaylist} onChange={(e) => setNewTrackPlaylist(e.target.value)}>
            <option value="">No playlist</option>
            {playlists.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button
            className="pink-btn !shadow-none"
            onClick={async () => {
              if (!url.trim()) return;
              const source = url.includes("youtu") ? "youtube" : url.includes("spotify") ? "spotify" : "url";
              await api("/api/music", {
                method: "POST",
                body: JSON.stringify({
                  entity: "track",
                  title: title || "Track",
                  url,
                  source,
                  playlistId: newTrackPlaylist || null,
                }),
              });
              setUrl("");
              setTitle("");
              setNewTrackPlaylist("");
              await reload();
            }}
          >
            Add track
          </button>
        </div>
        <label className="ghost-btn mt-3 block cursor-pointer text-center">
          Upload MP3 / WAV / M4A
          <input
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const dataUrl = await new Promise<string>((resolve) => {
                const r = new FileReader();
                r.onload = () => resolve(String(r.result));
                r.readAsDataURL(file);
              });
              const asset = await api<{ url: string }>("/api/assets", {
                method: "POST",
                body: JSON.stringify({ name: file.name, mimeType: file.type, data: dataUrl, kind: "audio" }),
              });
              await api("/api/music", {
                method: "POST",
                body: JSON.stringify({ entity: "track", title: file.name, url: asset.url, source: "local", playlistId: newTrackPlaylist || null }),
              });
              await reload();
            }}
          />
        </label>
      </section>
    </div>
  );
}

export function ResourcesView() {
  const { data, reload } = useKawaii();
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Resources & vault</h1>
      <p className="mb-3 text-sm text-pink-500">Upload images, copy their links, paste them as covers or stickers — your own tiny Obsidian.</p>
      <label className="pink-btn inline-block cursor-pointer">
        Upload file
        <input
          type="file"
          accept="image/*,audio/*"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const dataUrl = await new Promise<string>((resolve) => {
              const r = new FileReader();
              r.onload = () => resolve(String(r.result));
              r.readAsDataURL(file);
            });
            await api("/api/assets", {
              method: "POST",
              body: JSON.stringify({
                name: file.name,
                mimeType: file.type,
                data: dataUrl,
                kind: file.type.startsWith("audio") ? "audio" : "image",
              }),
            });
            await reload();
          }}
        />
      </label>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(data?.assets ?? []).map((a) => {
          const url = a.url || `/api/assets/${a.id}`;
          return (
            <article key={a.id} className="card">
              {a.kind === "image" ? <img src={url} alt={a.name} className="h-28 w-full rounded-xl object-cover" /> : <p className="text-3xl">🎵</p>}
              <p className="mt-2 truncate text-sm font-bold">{a.name}</p>
              <button
                className="ghost-btn mt-2"
                onClick={() => navigator.clipboard.writeText(`${window.location.origin}${url}`)}
              >
                Copy link
              </button>
            </article>
          );
        })}
      </div>
    </div>
  );
}

export function TrashView() {
  const { data, reload } = useKawaii();
  const trashed = (data?.notes ?? []).filter((n) => n.archived);
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Trash</h1>
      {trashed.length === 0 && <p className="empty-state">Trash is empty — sparkling clean.</p>}
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {trashed.map((n) => (
          <article key={n.id} className="card flex items-center gap-3">
            <img src={n.coverImage || DEFAULT_COVERS[0]} alt="" className="h-14 w-14 rounded-xl object-cover" />
            <div className="flex-1">
              <p className="font-bold">{n.title}</p>
              <div className="mt-1 flex gap-2">
                <button
                  className="ghost-btn"
                  onClick={async () => {
                    await api(`/api/notes/${n.id}`, { method: "PATCH", body: JSON.stringify({ archived: false }) });
                    await reload();
                  }}
                >
                  Restore
                </button>
                <button
                  className="ghost-btn"
                  onClick={async () => {
                    await api(`/api/notes/${n.id}`, { method: "DELETE" });
                    await reload();
                  }}
                >
                  Delete forever
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}



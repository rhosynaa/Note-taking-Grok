import { addDays, todayKey } from "./timer";

export interface TimeEntryLike {
  id: string;
  subjectId: string | null;
  projectId: string | null;
  date: string;
  durationSeconds: number;
  note?: string | null;
  createdAt?: string | Date;
}

export interface SubjectLike {
  id: string;
  name: string;
  color: string;
  icon?: string;
  targetMinutes: number;
}

export function secondsOnDate(entries: TimeEntryLike[], date: string) {
  return entries
    .filter((e) => e.date === date)
    .reduce((sum, e) => sum + (e.durationSeconds || 0), 0);
}

export function minutesOnDate(entries: TimeEntryLike[], date: string) {
  return Math.round(secondsOnDate(entries, date) / 60);
}

export function dailyBreakdown(entries: TimeEntryLike[], date = todayKey()) {
  const ofDay = entries.filter((e) => e.date === date);
  const totalSeconds = ofDay.reduce((s, e) => s + e.durationSeconds, 0);
  const sessions = ofDay.length;
  const bySubject: Record<string, number> = {};
  for (const e of ofDay) {
    const key = e.subjectId ?? "none";
    bySubject[key] = (bySubject[key] ?? 0) + e.durationSeconds;
  }
  return { date, totalSeconds, sessions, bySubject, entries: ofDay };
}

export function rangeKeys(end: string, days: number) {
  const keys: string[] = [];
  for (let i = days - 1; i >= 0; i--) keys.push(addDays(end, -i));
  return keys;
}

export function weeklyBreakdown(entries: TimeEntryLike[], end = todayKey()) {
  const keys = rangeKeys(end, 7);
  const days = keys.map((date) => ({
    date,
    totalSeconds: secondsOnDate(entries, date),
  }));
  const totalSeconds = days.reduce((s, d) => s + d.totalSeconds, 0);
  const bySubject: Record<string, number> = {};
  for (const e of entries) {
    if (!keys.includes(e.date)) continue;
    const key = e.subjectId ?? "none";
    bySubject[key] = (bySubject[key] ?? 0) + e.durationSeconds;
  }
  return { keys, days, totalSeconds, bySubject };
}

export function monthlyBreakdown(entries: TimeEntryLike[], end = todayKey()) {
  const keys = rangeKeys(end, 30);
  const days = keys.map((date) => ({
    date,
    totalSeconds: secondsOnDate(entries, date),
  }));
  const totalSeconds = days.reduce((s, d) => s + d.totalSeconds, 0);
  const bySubject: Record<string, number> = {};
  for (const e of entries) {
    if (!keys.includes(e.date)) continue;
    const key = e.subjectId ?? "none";
    bySubject[key] = (bySubject[key] ?? 0) + e.durationSeconds;
  }
  return { keys, days, totalSeconds, bySubject };
}

export function subjectProgress(entries: TimeEntryLike[], subjects: SubjectLike[]) {
  return subjects.map((s) => {
    const seconds = entries
      .filter((e) => e.subjectId === s.id)
      .reduce((sum, e) => sum + e.durationSeconds, 0);
    const minutes = Math.round(seconds / 60);
    const pct = s.targetMinutes > 0 ? Math.min(100, Math.round((minutes / s.targetMinutes) * 100)) : 0;
    return { ...s, minutes, seconds, pct };
  });
}

export function computeStreak(entries: TimeEntryLike[], end = todayKey()) {
  const daysWithTime = new Set(entries.filter((e) => e.durationSeconds > 0).map((e) => e.date));
  let streak = 0;
  let cursor = daysWithTime.has(end) ? end : addDays(end, -1);
  while (daysWithTime.has(cursor)) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

export function mostStudiedSubject(entries: TimeEntryLike[], subjects: SubjectLike[]) {
  const prog = subjectProgress(entries, subjects).sort((a, b) => b.seconds - a.seconds);
  return prog[0] ?? null;
}

export function totalMinutes(entries: TimeEntryLike[]) {
  return Math.round(entries.reduce((s, e) => s + e.durationSeconds, 0) / 60);
}

export function rebuildProgressRecords(entries: TimeEntryLike[]) {
  const map = new Map<string, { date: string; subjectId: string | null; minutes: number; sessions: number }>();
  for (const e of entries) {
    const key = `${e.date}::${e.subjectId ?? "none"}`;
    const cur = map.get(key) ?? {
      date: e.date,
      subjectId: e.subjectId,
      minutes: 0,
      sessions: 0,
    };
    cur.minutes += Math.round(e.durationSeconds / 60);
    cur.sessions += 1;
    map.set(key, cur);
  }
  return Array.from(map.values());
}

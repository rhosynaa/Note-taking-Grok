import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export const USER_COOKIE = "kawaii_user_id";

export async function readUserId() {
  const jar = await cookies();
  return jar.get(USER_COOKIE)?.value ?? null;
}

export async function getUserById(id: string) {
  const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getOrCreateUser() {
  const existingId = await readUserId();
  if (existingId) {
    const found = await getUserById(existingId);
    if (found) return found;
  }
  const anyUser = await db.select().from(users).limit(1);
  if (anyUser[0]) return anyUser[0];
  const inserted = await db
    .insert(users)
    .values({
      name: "Dreamy Student",
      email: "dreamy@studyspace.local",
      avatar: "/art/avatar-student.jpg",
      preferences: {
        pomodoroMinutes: 25,
        shortBreakMinutes: 5,
        longBreakMinutes: 15,
        focusMode: false,
      },
    })
    .returning();
  return inserted[0];
}

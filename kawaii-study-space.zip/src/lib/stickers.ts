import { makeElement, newId } from "./elements";
import type { CanvasElement } from "./types";

export interface StickerDef {
  id: string;
  name: string;
  category: string;
  emoji?: string;
  svg?: string;
}

export const STICKERS: StickerDef[] = [
  { id: "moon", name: "Moon", category: "sky", emoji: "🌙" },
  { id: "star", name: "Star", category: "sky", emoji: "⭐" },
  { id: "sparkles", name: "Sparkles", category: "sky", emoji: "✨" },
  { id: "cloud", name: "Cloud", category: "sky", emoji: "☁️" },
  { id: "rainbow", name: "Rainbow", category: "sky", emoji: "🌈" },
  { id: "cat", name: "Cat", category: "friends", emoji: "🐱" },
  { id: "bunny", name: "Bunny", category: "friends", emoji: "🐰" },
  { id: "bear", name: "Bear", category: "friends", emoji: "🧸" },
  { id: "chick", name: "Chick", category: "friends", emoji: "🐤" },
  { id: "frog", name: "Frog", category: "friends", emoji: "🐸" },
  { id: "heart", name: "Heart", category: "love", emoji: "💗" },
  { id: "hearts", name: "Hearts", category: "love", emoji: "💕" },
  { id: "ribbon", name: "Ribbon", category: "love", emoji: "🎀" },
  { id: "flower", name: "Blossom", category: "nature", emoji: "🌸" },
  { id: "tulip", name: "Tulip", category: "nature", emoji: "🌷" },
  { id: "leaf", name: "Leaf", category: "nature", emoji: "🍃" },
  { id: "crystal", name: "Crystal", category: "nature", emoji: "💎" },
  { id: "turtle", name: "Turtle", category: "ocean", emoji: "🐢" },
  { id: "whale", name: "Whale", category: "ocean", emoji: "🐋" },
  { id: "fish", name: "Fish", category: "ocean", emoji: "🐠" },
  { id: "coral", name: "Coral", category: "ocean", emoji: "🪸" },
  { id: "book", name: "Book", category: "study", emoji: "📓" },
  { id: "pencil", name: "Pencil", category: "study", emoji: "✏️" },
  { id: "memo", name: "Memo", category: "study", emoji: "📝" },
  { id: "brain", name: "Brain", category: "study", emoji: "🧠" },
  { id: "microscope", name: "Science", category: "study", emoji: "🔬" },
  { id: "flask", name: "Flask", category: "study", emoji: "🧪" },
  { id: "strawberry", name: "Strawberry", category: "food", emoji: "🍓" },
  { id: "boba", name: "Boba", category: "food", emoji: "🧋" },
  { id: "cake", name: "Cake", category: "food", emoji: "🍰" },
  { id: "music", name: "Notes", category: "fun", emoji: "🎵" },
  { id: "fire", name: "Streak", category: "fun", emoji: "🔥" },
  { id: "butterfly", name: "Butterfly", category: "nature", emoji: "🦋" },
  { id: "paw", name: "Paw", category: "friends", emoji: "🐾" },
  { id: "clover", name: "Clover", category: "nature", emoji: "🍀" },
  { id: "star2", name: "Glow star", category: "sky", emoji: "🌟" },
];

export const KAWAII_SVGS: Record<string, string> = {
  blobCat: `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><ellipse cx="32" cy="38" rx="20" ry="16" fill="#fff6fb" stroke="#f9a8d4" stroke-width="2"/><path d="M16 28 L20 12 L28 26" fill="#fff6fb" stroke="#f9a8d4" stroke-width="2"/><path d="M48 28 L44 12 L36 26" fill="#fff6fb" stroke="#f9a8d4" stroke-width="2"/><circle cx="26" cy="38" r="2.2" fill="#4a3558"/><circle cx="38" cy="38" r="2.2" fill="#4a3558"/><path d="M30 44 Q32 46 34 44" stroke="#f9a8d4" fill="none" stroke-width="1.6" stroke-linecap="round"/><circle cx="22" cy="42" r="3" fill="#fecdd3"/><circle cx="42" cy="42" r="3" fill="#fecdd3"/></svg>`,
  sleepyMoon: `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><path d="M40 10a22 22 0 1 0 14 38A20 20 0 0 1 40 10z" fill="#fde68a" stroke="#fbbf24" stroke-width="2"/><circle cx="28" cy="30" r="1.6" fill="#92400e"/><path d="M24 36 q4 3 8 0" stroke="#92400e" fill="none" stroke-width="1.5"/></svg>`,
  miniBear: `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><circle cx="20" cy="20" r="8" fill="#f5d0c5"/><circle cx="44" cy="20" r="8" fill="#f5d0c5"/><circle cx="32" cy="36" r="18" fill="#f5d0c5"/><circle cx="26" cy="34" r="2" fill="#4a3558"/><circle cx="38" cy="34" r="2" fill="#4a3558"/><ellipse cx="32" cy="42" rx="4" ry="3" fill="#fda4af"/></svg>`,
};

export function makeSticker(
  stickerId: string,
  partial: Partial<CanvasElement> = {},
): CanvasElement {
  const def = STICKERS.find((s) => s.id === stickerId);
  return makeElement("sticker", {
    w: 56,
    h: 56,
    content: def?.emoji ?? "✨",
    meta: { stickerId, name: def?.name ?? "sticker" },
    style: { fontSize: "42px", display: "grid", placeItems: "center" },
    ...partial,
  });
}

export function stickerFromAsset(url: string, name = "upload"): CanvasElement {
  return makeElement("image", {
    w: 88,
    h: 88,
    content: url,
    meta: { sticker: true, name },
    id: newId("sticker"),
  });
}

export const STICKER_CATEGORIES = Array.from(new Set(STICKERS.map((s) => s.category)));

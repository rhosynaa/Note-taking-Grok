import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  audioTracks,
  contentItems,
  customAssets,
  dashboardWidgets,
  flashcardReviews,
  noteTags,
  notes,
  playlists,
  progressRecords,
  projects,
  subjects,
  tags,
  tasks,
  templates,
  timeEntries,
  timerSessions,
  users,
} from "@/db/schema";
import { MOTIVATIONS, QUOTES, SUBJECT_PALETTE, randomCover } from "./types";
import { getTemplate, instantiateTemplate, TEMPLATES } from "./templates";
import { todayKey } from "./timer";
import {
  computeStreak,
  monthlyBreakdown,
  rebuildProgressRecords,
  subjectProgress,
  weeklyBreakdown,
  dailyBreakdown,
} from "./analytics";

const DEFAULT_WIDGETS = [
  "greeting",
  "progress",
  "plan",
  "calendar",
  "recent",
  "deadlines",
  "subjects",
  "music",
  "quick",
  "streak",
  "focus",
  "motivation",
  "tags",
  "quote",
];

export async function seedWorkspace(userId: string) {
  const existingContent = await db.select({ id: contentItems.id }).from(contentItems).where(eq(contentItems.userId, userId)).limit(1);
  if (!existingContent.length) {
    await db.insert(contentItems).values([
      ...QUOTES.map((text) => ({ userId, kind: "quote", text })),
      ...MOTIVATIONS.map((text) => ({ userId, kind: "motivation", text })),
    ]);
  }

  const existingSubjects = await db.select().from(subjects).where(eq(subjects.userId, userId)).limit(1);
  if (existingSubjects.length) return;

  const subjectRows = await db
    .insert(subjects)
    .values(
      SUBJECT_PALETTE.map((s, i) => ({
        userId,
        name: s.name,
        color: s.color,
        icon: s.icon,
        targetMinutes: [2400, 1800, 1680, 1800, 1200][i] ?? 1200,
      })),
    )
    .returning();

  const byName = Object.fromEntries(subjectRows.map((s) => [s.name, s]));

  await db.insert(projects).values([
    {
      userId,
      subjectId: byName.Mathematics?.id,
      name: "Algebra sprint",
      description: "Functions, inverses, and practice sets",
      targetMinutes: 600,
    },
    {
      userId,
      subjectId: byName.Biology?.id,
      name: "Cells unit",
      description: "Chapter 2 + gene basics",
      targetMinutes: 480,
    },
  ]);

  const tagRows = await db
    .insert(tags)
    .values([
      { userId, name: "Important", color: "#fda4af" },
      { userId, name: "Biology", color: "#86efac" },
      { userId, name: "Math", color: "#c4b5fd" },
      { userId, name: "Physics", color: "#7dd3fc" },
      { userId, name: "Chemistry", color: "#67e8f9" },
      { userId, name: "English", color: "#fdba74" },
      { userId, name: "Practice", color: "#f9a8d4" },
      { userId, name: "Lecture", color: "#ddd6fe" },
    ])
    .returning();

  const tagBy = Object.fromEntries(tagRows.map((t) => [t.name, t]));

  const seedNotes = [
    {
      title: "Cell Structure Notes",
      templateId: "cells-tissue",
      subject: "Biology",
      tags: ["Biology", "Important"],
    },
    {
      title: "Quadratic Equations",
      templateId: "functions-inverse",
      subject: "Mathematics",
      tags: ["Math", "Practice"],
    },
    {
      title: "Photosynthesis Process",
      templateId: "coral-reef",
      subject: "Biology",
      tags: ["Biology"],
    },
    {
      title: "Newton's Laws Summary",
      templateId: "cornell-notes",
      subject: "Physics",
      tags: ["Physics"],
    },
    {
      title: "Organic Chemistry Basics",
      templateId: "hypothesis-testing",
      subject: "Chemistry",
      tags: ["Chemistry", "Lecture"],
    },
    {
      title: "Figures of Speech",
      templateId: "figures-of-speech",
      subject: "English Literature",
      tags: ["English"],
    },
    {
      title: "Dream Journal — Sapphire Ocean",
      templateId: "dream-journal",
      subject: "English Literature",
      tags: ["English"],
    },
    {
      title: "Patriotism Mind Map",
      templateId: "patriotism-mindmap",
      subject: "English Literature",
      tags: ["English", "Important"],
    },
  ];

  for (const sn of seedNotes) {
    const tmpl = getTemplate(sn.templateId);
    const inst = tmpl
      ? instantiateTemplate(tmpl)
      : { elements: [], background: "#fffdf8", width: 900, height: 1200 };
    const [note] = await db
      .insert(notes)
      .values({
        userId,
        subjectId: byName[sn.subject]?.id ?? null,
        templateId: sn.templateId,
        title: sn.title,
        kind: sn.templateId.includes("mindmap") ? "mindmap" : "note",
        content: inst.elements,
        coverImage: tmpl?.cover ?? randomCover(sn.title),
        background: inst.background,
        canvasWidth: inst.width,
        canvasHeight: inst.height,
      })
      .returning();
    for (const tn of sn.tags) {
      const tag = tagBy[tn];
      if (tag && note) {
        await db.insert(noteTags).values({ noteId: note.id, tagId: tag.id });
      }
    }
  }

  const now = new Date();
  const daysOut = (n: number) => {
    const d = new Date(now);
    d.setDate(d.getDate() + n);
    d.setHours(17, 0, 0, 0);
    return d;
  };

  await db.insert(tasks).values([
    { userId, subjectId: byName.Mathematics?.id, title: "Math Problem Set", completed: true, dueDate: daysOut(0) },
    { userId, subjectId: byName.Biology?.id, title: "Biology Diagrams", completed: true, dueDate: daysOut(0) },
    { userId, subjectId: byName.Physics?.id, title: "Physics Revision", completed: false, dueDate: daysOut(0) },
    { userId, subjectId: byName.Chemistry?.id, title: "Chemistry Lab Report", completed: false, dueDate: daysOut(2) },
    { userId, subjectId: byName["English Literature"]?.id, title: "Read English Poem", completed: false, dueDate: daysOut(1) },
    { userId, subjectId: byName["English Literature"]?.id, title: "English Essay: Romanticism", completed: false, dueDate: daysOut(4) },
    { userId, subjectId: byName.Mathematics?.id, title: "Math Quiz 3", completed: false, dueDate: daysOut(7) },
    { userId, subjectId: byName.Biology?.id, title: "Biology Unit Test", completed: false, dueDate: daysOut(12) },
  ]);

  await db.insert(dashboardWidgets).values(
    DEFAULT_WIDGETS.map((key, i) => ({
      userId,
      widgetKey: key,
      layoutOrder: i,
      visible: true,
      pinned: key === "greeting" || key === "progress",
    })),
  );

  const [playlist] = await db
    .insert(playlists)
    .values({ userId, name: "My Playlist" })
    .returning();

  if (playlist) {
    await db.insert(audioTracks).values([
      {
        playlistId: playlist.id,
        userId,
        title: "lofi girl - studying",
        artist: "lofi hip hop radio",
        source: "youtube",
        url: "https://www.youtube.com/watch?v=jfKfPfyJRdk",
        durationSeconds: 0,
        sortOrder: 0,
      },
      {
        playlistId: playlist.id,
        userId,
        title: "purple cat - evening",
        artist: "lofi",
        source: "youtube",
        url: "https://www.youtube.com/watch?v=bMva_nNhZbg",
        durationSeconds: 0,
        sortOrder: 1,
      },
      {
        playlistId: playlist.id,
        userId,
        title: "chill vibes - night",
        artist: "lofi",
        source: "youtube",
        url: "https://www.youtube.com/watch?v=7NOSDKb0HlU",
        durationSeconds: 0,
        sortOrder: 2,
      },
      {
        playlistId: playlist.id,
        userId,
        title: "moonlight - piano",
        artist: "calm",
        source: "youtube",
        url: "https://www.youtube.com/watch?v=lTRiuFIWV54",
        durationSeconds: 0,
        sortOrder: 3,
      },
      {
        playlistId: playlist.id,
        userId,
        title: "rain drops - calm",
        artist: "ambience",
        source: "youtube",
        url: "https://www.youtube.com/watch?v=q76bMs-NwRk",
        durationSeconds: 0,
        sortOrder: 4,
      },
    ]);
  }
}

export async function loadWorkspace(userId: string) {
  const [
    userRows,
    subjectRows,
    projectRows,
    noteRows,
    taskRows,
    tagRows,
    noteTagRows,
    widgetRows,
    playlistRows,
    trackRows,
    entryRows,
    assetRows,
    sessionRows,
    customTemplateRows,
    contentRows,
    reviewRows,
  ] = await Promise.all([
    db.select().from(users).where(eq(users.id, userId)).limit(1),
    db.select().from(subjects).where(eq(subjects.userId, userId)),
    db.select().from(projects).where(eq(projects.userId, userId)),
    db.select().from(notes).where(eq(notes.userId, userId)).orderBy(desc(notes.updatedAt)),
    db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(tasks.dueDate),
    db.select().from(tags).where(eq(tags.userId, userId)),
    db.select().from(noteTags),
    db.select().from(dashboardWidgets).where(eq(dashboardWidgets.userId, userId)),
    db.select().from(playlists).where(eq(playlists.userId, userId)),
    db.select().from(audioTracks).where(eq(audioTracks.userId, userId)),
    db.select().from(timeEntries).where(eq(timeEntries.userId, userId)),
    db.select({
      id: customAssets.id,
      name: customAssets.name,
      mimeType: customAssets.mimeType,
      kind: customAssets.kind,
      createdAt: customAssets.createdAt,
    }).from(customAssets).where(eq(customAssets.userId, userId)),
    db.select().from(timerSessions).where(eq(timerSessions.userId, userId)).orderBy(desc(timerSessions.createdAt)).limit(8),
    db.select().from(templates).where(eq(templates.userId, userId)),
    db.select().from(contentItems).where(eq(contentItems.userId, userId)),
    db.select().from(flashcardReviews).where(eq(flashcardReviews.userId, userId)),
  ]);

  const user = userRows[0];
  const entries = entryRows.map((e) => ({
    ...e,
    createdAt: e.createdAt?.toISOString?.() ?? String(e.createdAt),
    updatedAt: e.updatedAt?.toISOString?.() ?? String(e.updatedAt),
  }));

  const analytics = {
    daily: dailyBreakdown(entries),
    weekly: weeklyBreakdown(entries),
    monthly: monthlyBreakdown(entries),
    subjects: subjectProgress(entries, subjectRows),
    streak: computeStreak(entries),
    totalMinutes: Math.round(entries.reduce((s, e) => s + e.durationSeconds, 0) / 60),
  };

  return {
    user,
    subjects: subjectRows,
    projects: projectRows,
    notes: noteRows,
    tasks: taskRows,
    tags: tagRows,
    noteTags: noteTagRows,
    widgets: widgetRows,
    playlists: playlistRows,
    tracks: trackRows,
    timeEntries: entries,
    assets: assetRows,
    timerSessions: sessionRows,
    customTemplates: customTemplateRows,
    quotes: contentRows
      .filter((c) => c.kind === "quote")
      .map((c) => ({ id: c.id, text: c.text, author: c.author })),
    motivations: contentRows
      .filter((c) => c.kind === "motivation")
      .map((c) => ({ id: c.id, text: c.text })),
    flashcardReviews: reviewRows.map((r) => ({
      id: r.id,
      noteId: r.noteId,
      result: r.result,
      difficulty: r.difficulty,
      createdAt: r.createdAt?.toISOString?.() ?? String(r.createdAt),
    })),
    systemTemplates: TEMPLATES.map((t) => ({
      id: t.id,
      name: t.name,
      category: t.category,
      description: t.description,
      cover: t.cover,
      paper: t.paper,
    })),
    analytics,
    today: todayKey(),
  };
}

export async function refreshProgress(userId: string) {
  const entries = await db.select().from(timeEntries).where(eq(timeEntries.userId, userId));
  const rebuilt = rebuildProgressRecords(entries);
  await db.delete(progressRecords).where(eq(progressRecords.userId, userId));
  if (rebuilt.length) {
    await db.insert(progressRecords).values(
      rebuilt.map((r) => ({
        userId,
        subjectId: r.subjectId,
        date: r.date,
        minutesStudied: r.minutes,
        sessionsCount: r.sessions,
      })),
    );
  }
}

export async function searchNotes(userId: string, q: string) {
  const query = q.trim();
  if (!query) {
    return db.select().from(notes).where(and(eq(notes.userId, userId), eq(notes.archived, false)));
  }
  const pattern = `%${query}%`;
  return db
    .select()
    .from(notes)
    .where(
      and(
        eq(notes.userId, userId),
        or(ilike(notes.title, pattern), sql`${notes.content}::text ilike ${pattern}`),
      ),
    );
}

import type { CanvasElement, CanvasElementType } from "./types";

export function newId(prefix = "el") {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export function makeElement(
  type: CanvasElementType,
  partial: Partial<CanvasElement> = {},
): CanvasElement {
  const { style, id, ...rest } = partial;
  return {
    id: id ?? newId(type),
    type,
    x: 40,
    y: 40,
    w: 280,
    h: 48,
    z: 1,
    content: "",
    ...rest,
    style: { ...(style ?? {}) },
  };
}

export function baseText(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("text", {
    w: 420,
    h: 36,
    style: {
      fontFamily: "Nunito, sans-serif",
      fontSize: "16px",
      color: "#4a3558",
      lineHeight: "1.5",
    },
    ...partial,
  });
}

export function headingEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("heading", {
    w: 520,
    h: 52,
    style: {
      fontFamily: "Fredoka, Nunito, sans-serif",
      fontSize: "28px",
      fontWeight: "700",
      color: "#7c3aed",
    },
    ...partial,
  });
}

export function calloutEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("callout", {
    w: 360,
    h: 120,
    style: {
      background: "#fff0f6",
      border: "2px solid #f9a8d4",
      borderRadius: "18px",
      padding: "12px",
      fontFamily: "Nunito, sans-serif",
      color: "#5b3a62",
    },
    ...partial,
  });
}

export function progressEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("progress", {
    w: 280,
    h: 48,
    content: "60",
    meta: { label: "Progress", color: "#f9a8d4" },
    ...partial,
  });
}

export function todoEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("todo", {
    w: 280,
    h: 160,
    content: JSON.stringify([
      { text: "Review notes", done: false },
      { text: "Practice problems", done: false },
    ]),
    ...partial,
  });
}

export function tableEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("table", {
    w: 420,
    h: 160,
    content: JSON.stringify({
      rows: 3,
      cols: 3,
      cells: [
        ["Term", "Definition", "Example"],
        ["", "", ""],
        ["", "", ""],
      ],
    }),
    ...partial,
  });
}

export function columnsEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("columns", {
    w: 640,
    h: 180,
    content: JSON.stringify({
      cols: 2,
      texts: ["Column A", "Column B"],
    }),
    ...partial,
  });
}

export function chartEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("chart", {
    w: 220,
    h: 160,
    content: JSON.stringify({ kind: "bell", label: "distribution" }),
    ...partial,
  });
}

export function listEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("list", {
    w: 360,
    h: 140,
    content: "• First point\n• Second point\n• Third point",
    style: {
      fontFamily: "Nunito, sans-serif",
      fontSize: "15px",
      color: "#4a3558",
    },
    ...partial,
  });
}

export function dividerEl(partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("divider", {
    w: 640,
    h: 16,
    content: "line",
    ...partial,
  });
}

export function imageEl(src: string, partial: Partial<CanvasElement> = {}): CanvasElement {
  return makeElement("image", {
    w: 180,
    h: 120,
    content: src,
    ...partial,
  });
}

export const ELEMENT_LIBRARY: {
  id: string;
  name: string;
  hint: string;
  factory: () => CanvasElement;
}[] = [
  { id: "text", name: "Text", hint: "Start typing", factory: () => baseText({ content: "Type here…" }) },
  { id: "h1", name: "Heading 1", hint: "Big title", factory: () => headingEl({ content: "Heading 1", style: { fontSize: "32px", fontFamily: "Fredoka, sans-serif", color: "#be185d" } }) },
  { id: "h2", name: "Heading 2", hint: "Section", factory: () => headingEl({ content: "Heading 2", style: { fontSize: "24px", color: "#7c3aed" } }) },
  { id: "h3", name: "Heading 3", hint: "Subhead", factory: () => headingEl({ content: "Heading 3", style: { fontSize: "18px", color: "#db2777" } }) },
  { id: "callout", name: "Callout", hint: "Pretty box", factory: () => calloutEl({ content: "Remember this!" }) },
  { id: "todo", name: "To-do list", hint: "Checklist", factory: () => todoEl() },
  { id: "table", name: "Table", hint: "Grid of cells", factory: () => tableEl() },
  { id: "columns", name: "Columns", hint: "2-up layout", factory: () => columnsEl() },
  { id: "progress", name: "Progress bar", hint: "Track a goal", factory: () => progressEl() },
  { id: "chart", name: "Chart", hint: "Bell / pie", factory: () => chartEl() },
  { id: "list", name: "Bullets", hint: "List", factory: () => listEl() },
  { id: "divider", name: "Divider", hint: "Line", factory: () => dividerEl() },
];

export type CanvasElementType =
  | "text"
  | "heading"
  | "sticker"
  | "shape"
  | "widget"
  | "image"
  | "divider"
  | "list"
  | "callout"
  | "chart"
  | "table"
  | "todo"
  | "progress"
  | "columns"
  | "html";

export type ElementStyle = Record<string, string>;

export interface CanvasElement {
  id: string;
  type: CanvasElementType;
  x: number;
  y: number;
  w: number;
  h: number;
  z: number;
  rotation?: number;
  content: string;
  html?: string;
  style: ElementStyle;
  locked?: boolean;
  opacity?: number;
  meta?: Record<string, unknown>;
  connections?: string[];
}

export interface NoteTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  cover: string;
  width: number;
  height: number;
  background: string;
  paper: "plain" | "lined" | "grid" | "dots" | "cream" | "pink" | "navy";
  elements: CanvasElement[];
}

export type NoteKind = "note" | "flashcard" | "mindmap";

export interface UserPref {
  focusMode?: boolean;
  pomodoroMinutes?: number;
  shortBreakMinutes?: number;
  longBreakMinutes?: number;
  displayName?: string;
}

export const DEFAULT_COVERS = [
  "/covers/night-cat.jpg",
  "/covers/sakura-desk.jpg",
  "/covers/starry-clouds.jpg",
  "/covers/strawberry-stationery.jpg",
] as const;

export function randomCover(seed?: string) {
  if (!seed) {
    return DEFAULT_COVERS[Math.floor(Math.random() * DEFAULT_COVERS.length)];
  }
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) | 0;
  return DEFAULT_COVERS[Math.abs(hash) % DEFAULT_COVERS.length];
}

export const SUBJECT_PALETTE = [
  { name: "Mathematics", color: "#f9a8d4", icon: "📗" },
  { name: "Biology", color: "#c4b5fd", icon: "🌿" },
  { name: "Physics", color: "#86efac", icon: "⚙️" },
  { name: "Chemistry", color: "#7dd3fc", icon: "🧪" },
  { name: "English Literature", color: "#fdba74", icon: "📙" },
] as const;

export const QUOTES = [
  "The expert in anything was once a beginner.",
  "Small progress is still progress. Keep going, future you is proud of you!",
  "Study like the moon — quietly, consistently, lighting your own way.",
  "You are enough, just as you are.",
  "Notes today, magic tomorrow.",
  "Soft heart, sharp mind, sparkly highlighter.",
  "One page at a time, little star.",
];

export const MOTIVATIONS = [
  "Small progress is still progress. Keep going, future you is proud of you!",
  "Sip some water, stretch, then conquer one tiny task.",
  "Your brain is doing cute little push-ups right now.",
  "Even 10 focused minutes count as a win.",
  "Be the main character of today's study session.",
];

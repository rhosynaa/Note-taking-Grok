import { baseText, headingEl, makeElement, newId } from "./elements";
import { makeShape } from "./shapes";
import { makeSticker } from "./stickers";
import type { CanvasElement, NoteTemplate } from "./types";

export function buildTemplateName(name: string) {
  return name.replace(/\s+/g, " ").trim();
}

function T(
  partial: Omit<NoteTemplate, "elements"> & { elements: CanvasElement[] },
): NoteTemplate {
  return partial;
}

function txt(
  content: string,
  x: number,
  y: number,
  w: number,
  extra: Partial<CanvasElement> = {},
): CanvasElement {
  return baseText({
    content,
    x,
    y,
    w,
    h: extra.h ?? 32,
    ...extra,
    style: {
      fontFamily: "Nunito, sans-serif",
      fontSize: "15px",
      color: "#3f2d4d",
      ...(extra.style ?? {}),
    },
  });
}

function hd(
  content: string,
  x: number,
  y: number,
  extra: Partial<CanvasElement> = {},
): CanvasElement {
  return headingEl({
    content,
    x,
    y,
    w: extra.w ?? 520,
    h: extra.h ?? 48,
    ...extra,
  });
}

export function instantiateTemplate(t: NoteTemplate): {
  elements: CanvasElement[];
  background: string;
  width: number;
  height: number;
} {
  const idMap = new Map<string, string>();
  const cloned = t.elements.map((el) => {
    const nid = newId(el.type);
    idMap.set(el.id, nid);
    return { ...el, id: nid, style: { ...el.style }, meta: el.meta ? { ...el.meta } : undefined };
  });
  const elements = cloned.map((el) => ({
    ...el,
    connections: (el.connections ?? []).map((c) => idMap.get(c) ?? c),
  }));
  return {
    elements,
    background: t.background,
    width: t.width,
    height: t.height,
  };
}

const hypothesis: NoteTemplate = T({
  id: "hypothesis-testing",
  name: "Hypothesis Testing",
  category: "STEM",
  description: "Lined-page stats notes with bell curves, one- and two-tailed tests, and z-score boxes.",
  cover: "/covers/sakura-desk.jpg",
  width: 900,
  height: 1280,
  background: "#fbf6e9",
  paper: "lined",
  elements: [
    hd("HYPOTHESIS TESTING", 48, 28, {
      style: {
        fontFamily: "Caveat, cursive",
        fontSize: "42px",
        color: "#65a30d",
        letterSpacing: "0.04em",
      },
    }),
    txt("a statistical procedure for deciding whether or not a claim is valid", 52, 78, 760, {
      style: { fontFamily: "Patrick Hand, cursive", fontSize: "16px", color: "#57534e", fontStyle: "italic" },
    }),
    makeSticker("star", { x: 820, y: 24, w: 48, h: 48 }),
    hd("Ho : the null hypothesis", 52, 130, {
      w: 380,
      h: 30,
      style: { fontSize: "18px", color: "#1e3a5f", fontFamily: "Nunito, sans-serif" },
    }),
    txt("H1 : the alternative hypothesis", 52, 162, 400, {
      style: { fontSize: "16px", color: "#1e3a5f", fontWeight: "700" },
    }),
    txt("POSSIBLE OUTCOMES:\n• Ho is rejected in favor of H1\n• failed to reject Ho", 52, 198, 320, {
      h: 90,
      style: { fontSize: "14px", whiteSpace: "pre-wrap" },
    }),
    makeElement("chart", {
      x: 400,
      y: 120,
      w: 200,
      h: 140,
      content: JSON.stringify({ kind: "bell", shade: "two", label: "TWO-TAILED TEST" }),
    }),
    makeElement("chart", {
      x: 640,
      y: 120,
      w: 200,
      h: 140,
      content: JSON.stringify({ kind: "bell", shade: "left", label: "ONE-TAILED TEST" }),
    }),
    makeElement("callout", {
      x: 52,
      y: 310,
      w: 420,
      h: 150,
      content:
        "FORMULA:  z  =  (x̄ − μ) / (σ / √n)\n\nTry keep numbers the same across Ho & H1.\nTest at 5% level of significance.",
      style: {
        background: "#e0f2fe",
        border: "2px dashed #38bdf8",
        borderRadius: "16px",
        padding: "14px",
        fontFamily: "Nunito, sans-serif",
        fontSize: "14px",
        color: "#0c4a6e",
      },
    }),
    makeElement("callout", {
      x: 500,
      y: 310,
      w: 350,
      h: 150,
      content:
        "Ho : μ = number\nH1 : μ ≠ number   ★ two-tailed\nH1 : μ < number   ★ left tail\nH1 : μ > number   ★ right tail",
      style: {
        background: "#fef9c3",
        border: "2px solid #facc15",
        borderRadius: "16px",
        padding: "14px",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "16px",
        color: "#713f12",
      },
    }),
    txt(
      "The government claims that teachers earn $45,000 with σ = $6,000.\nA sample of 16 teachers found the mean income to be $42,500.\nTest if the mean income is equal to $45,000.  α = 0.05",
      52,
      490,
      800,
      { h: 90, style: { fontSize: "15px", lineHeight: "1.55" } },
    ),
    makeElement("callout", {
      x: 52,
      y: 590,
      w: 800,
      h: 120,
      content:
        "z = (42500 − 45000) / (6000 / √16)  =  −2500 / 1500  =  −1.67\nCritical value ±1.96   →   −1.67 is inside  →  failed to reject Ho",
      style: {
        background: "#ecfccb",
        border: "2px solid #84cc16",
        borderRadius: "18px",
        padding: "16px",
        fontFamily: "Nunito, sans-serif",
        fontWeight: "700",
        color: "#365314",
      },
    }),
    makeSticker("pencil", { x: 800, y: 740, w: 56, h: 56 }),
    makeSticker("star2", { x: 40, y: 740, w: 48, h: 48 }),
  ],
});

const loveLetter: NoteTemplate = T({
  id: "love-letter",
  name: "Ink & Hearts Letter",
  category: "Journal",
  description: "Handwritten letter page with a quill, cascading red hearts, and ink-drawn borders.",
  cover: "/covers/strawberry-stationery.jpg",
  width: 780,
  height: 1100,
  background: "#fffaf3",
  paper: "plain",
  elements: [
    hd("To: My Love (Always)", 70, 40, {
      style: { fontFamily: "Caveat, cursive", fontSize: "30px", color: "#1c1917" },
    }),
    txt(
      "I love every thing about you. I love your laugh, your smile, the way you look at me.\nI just can't believe that we met like this — accidentally — and that everything was just so perfect.\nI don't know what the future brings or what life will throw at us, but I know we will get through it.\nNo matter what together. I know what I want and need, and that's you.\nI love you. That's true. That's you. That's us.",
      70,
      100,
      430,
      {
        h: 520,
        style: {
          fontFamily: "Caveat, cursive",
          fontSize: "22px",
          lineHeight: "1.45",
          color: "#1c1917",
          whiteSpace: "pre-wrap",
        },
      },
    ),
    makeSticker("hearts", { x: 560, y: 40, w: 48, h: 48 }),
    makeSticker("heart", { x: 620, y: 90, w: 44, h: 44 }),
    makeSticker("hearts", { x: 680, y: 150, w: 48, h: 48 }),
    makeSticker("heart", { x: 600, y: 210, w: 40, h: 40 }),
    makeSticker("hearts", { x: 670, y: 270, w: 52, h: 52 }),
    makeSticker("heart", { x: 580, y: 340, w: 46, h: 46 }),
    makeShape("rectangle", {
      x: 540,
      y: 430,
      w: 180,
      h: 260,
      content: "rectangle",
      style: { fill: "#1c1917", stroke: "#1c1917", color: "#fafafa" },
      meta: { kind: "rectangle", text: "✒  quill\n& inkwell" },
    }),
    txt("from forever —", 420, 900, 260, {
      style: { fontFamily: "Caveat, cursive", fontSize: "22px", textAlign: "right" },
    }),
  ],
});

const figures: NoteTemplate = T({
  id: "figures-of-speech",
  name: "Figures of Speech",
  category: "Language",
  description: "Pastel notebook spread defining metaphor, simile, personification, and repetition.",
  cover: "/covers/sakura-desk.jpg",
  width: 900,
  height: 1200,
  background: "#fff5f8",
  paper: "lined",
  elements: [
    hd("Figures of Speech ✿", 60, 30, {
      style: { fontFamily: "Pacifico, cursive", fontSize: "34px", color: "#db2777" },
    }),
    txt("special language used to create comparison & beauty", 70, 82, 640, {
      style: { fontFamily: "Patrick Hand, cursive", fontSize: "18px", color: "#9d174d" },
    }),
    makeSticker("butterfly", { x: 780, y: 28, w: 56, h: 56 }),
    makeSticker("flower", { x: 820, y: 80, w: 44, h: 44 }),
    hd("1. Metaphor", 60, 130, {
      style: { fontSize: "22px", color: "#be185d", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "• A direct comparison without using \"like\" or \"as\".\n• Tells that one thing is another.\nExamples: Time is a thief.  /  Her eyes are stars.  /  Life is a dream.",
      70,
      175,
      760,
      { h: 110, style: { whiteSpace: "pre-wrap", fontSize: "15px" } },
    ),
    hd("2. Simile", 60, 300, {
      style: { fontSize: "22px", color: "#7c3aed", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "• A comparison using \"like\" or \"as\".\n• Makes meaning clearer and more beautiful.\nExamples: Her smile is like a shining star.  /  The night is as dark as ink.",
      70,
      345,
      760,
      { h: 110, style: { whiteSpace: "pre-wrap" } },
    ),
    hd("3. Personification", 60, 470, {
      style: { fontSize: "22px", color: "#0369a1", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "• Giving human qualities to non-living things, animals, or abstract ideas.\nExamples: The wind whispered through the trees.\nOpportunity knocked at his door.  /  The sun smiled on us.",
      70,
      515,
      760,
      { h: 120, style: { whiteSpace: "pre-wrap" } },
    ),
    hd("4. Repetition", 60, 650, {
      style: { fontSize: "22px", color: "#0f766e", fontFamily: "Fredoka, sans-serif" },
    }),
    txt("• Repetition of same initial sounds, words, or phrases for emphasis and rhythm.", 70, 700, 760, {
      h: 70,
    }),
    makeSticker("tulip", { x: 60, y: 800, w: 48, h: 48 }),
    makeSticker("butterfly", { x: 780, y: 790, w: 52, h: 52 }),
  ],
});

const cells: NoteTemplate = T({
  id: "cells-tissue",
  name: "Chapter 2 · Cells & Tissue",
  category: "STEM",
  description: "Spiral-notebook biology chapter with color-blocked sections for organelles and membrane.",
  cover: "/covers/night-cat.jpg",
  width: 900,
  height: 1300,
  background: "#eef6ff",
  paper: "plain",
  elements: [
    hd("Chapter 2", 48, 28, {
      style: {
        fontFamily: "Fredoka, sans-serif",
        fontSize: "48px",
        color: "#2563eb",
        fontStyle: "italic",
      },
    }),
    makeElement("callout", {
      x: 330,
      y: 36,
      w: 160,
      h: 40,
      content: "CELLS & TISSUE",
      style: {
        background: "#38bdf8",
        color: "white",
        borderRadius: "8px",
        fontWeight: "800",
        fontSize: "12px",
        display: "grid",
        placeItems: "center",
      },
    }),
    txt(
      "The cell is the basic unit of living structure in the human organism. A body structure more complex than a cell is a collection of cells (tissues, organs) and their products.",
      48,
      100,
      800,
      { h: 70, style: { fontSize: "14px", lineHeight: "1.5" } },
    ),
    hd("CELL THEORY", 48, 180, {
      style: { fontSize: "18px", color: "#1d4ed8", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "• Cells are building blocks of plants and animals.\n• Cells are the smallest functional unit of life.\n• Cells are produced by the division of pre-existing cells.",
      48,
      220,
      380,
      { h: 140, style: { whiteSpace: "pre-wrap", fontSize: "14px" } },
    ),
    hd("cell membrane", 460, 180, {
      style: { fontFamily: "Caveat, cursive", fontSize: "32px", color: "#2563eb" },
    }),
    txt(
      "Made of phospholipid bilayer. The membrane is more complex than a simple wall — proteins are channels, pumps and receptors. A plasma membrane lets some things in and keeps others out.",
      460,
      230,
      390,
      { h: 150, style: { fontSize: "13px", lineHeight: "1.45" } },
    ),
    hd("CELL ORGANELLES", 48, 390, {
      style: { fontSize: "18px", color: "#1d4ed8", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "Mitochondria: the major organelles converting energy from nutrients.\nNucleus: control center of the cell, stores DNA.\nRibosomes: protein synthesis.",
      48,
      430,
      800,
      { h: 110, style: { whiteSpace: "pre-wrap", fontSize: "14px" } },
    ),
    hd("cytoplasm", 48, 560, {
      style: { fontFamily: "Caveat, cursive", fontSize: "36px", color: "#0ea5e9" },
    }),
    txt(
      "The ground substance of the cell excluding the nucleus. Contains the organelles and inclusions (secretions, pigments, glycogen).",
      48,
      615,
      800,
      { h: 80 },
    ),
    hd("RIBOSOMES", 48, 720, {
      style: { fontSize: "28px", color: "#1e3a8a", fontFamily: "Fredoka, sans-serif", letterSpacing: "0.08em" },
    }),
    txt("Tiny protein factories. Found free in cytoplasm or attached to endoplasmic reticulum.", 48, 770, 800, {
      h: 60,
    }),
    makeSticker("microscope", { x: 800, y: 28, w: 56, h: 56 }),
  ],
});

const dailyJournal: NoteTemplate = T({
  id: "daily-journal",
  name: "Pastel Daily Spread",
  category: "Journal",
  description: "Dated grid journal with currently / highlight / brain dump / quote boxes.",
  cover: "/covers/starry-clouds.jpg",
  width: 900,
  height: 1200,
  background: "#fff7fb",
  paper: "plain",
  elements: [
    hd("12th June 2024", 48, 24, {
      style: { fontFamily: "Caveat, cursive", fontSize: "28px", color: "#4a3558" },
    }),
    txt("wednesday", 48, 64, 200, { style: { color: "#c084fc", letterSpacing: "0.2em", fontSize: "12px" } }),
    makeSticker("moon", { x: 780, y: 20, w: 48, h: 48 }),
    makeSticker("cloud", { x: 820, y: 70, w: 44, h: 44 }),
    makeElement("callout", {
      x: 40,
      y: 110,
      w: 260,
      h: 200,
      content: "currently…\nlistening to  ♪\nslightly sleepy\none direction\nobsessed with gel pens",
      style: {
        background: "#fce7f3",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "16px",
        color: "#9d174d",
      },
    }),
    makeElement("callout", {
      x: 320,
      y: 110,
      w: 260,
      h: 200,
      content: "today's highlight\nget lots of study done + feel productive ♡",
      style: {
        background: "#ede9fe",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "16px",
        color: "#5b21b6",
      },
    }),
    makeElement("callout", {
      x: 600,
      y: 110,
      w: 260,
      h: 200,
      content: "random thoughts\nmaybe I'm not lost, maybe I'm just exploring.",
      style: {
        background: "#fbcfe8",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "16px",
        color: "#9d174d",
      },
    }),
    makeElement("callout", {
      x: 40,
      y: 330,
      w: 260,
      h: 210,
      content: "things I loved today\n☐ the weather\n☐ a good song\n☐ talking to my friend\n☐ finishing a chapter",
      style: {
        background: "#fce7f3",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Nunito, sans-serif",
        fontSize: "15px",
      },
    }),
    makeElement("callout", {
      x: 320,
      y: 330,
      w: 260,
      h: 210,
      content: "little wins\n☐ woke up on time\n☐ did my homework\n☐ drank enough water\n☐ didn't overthink",
      style: {
        background: "#fce7f3",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
      },
    }),
    makeElement("callout", {
      x: 600,
      y: 330,
      w: 260,
      h: 210,
      content: "note to self\nbe proud of how far you've come. you're doing better than you think.",
      style: {
        background: "#fbcfe8",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "16px",
      },
    }),
    makeElement("callout", {
      x: 40,
      y: 560,
      w: 400,
      h: 180,
      content: "brain dump\nI feel like I have so much to do and also so many feelings. Write it out — it'll be worth it.",
      style: {
        background: "#ede9fe",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
      },
    }),
    makeElement("callout", {
      x: 460,
      y: 560,
      w: 400,
      h: 180,
      content: "dear future me,\na hope you're happy. keep living the life you always dreamed of — but here, in you.",
      style: {
        background: "#fce7f3",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Caveat, cursive",
        fontSize: "20px",
      },
    }),
    makeElement("callout", {
      x: 40,
      y: 760,
      w: 400,
      h: 100,
      content: "quote of the day\n“You are enough, just as you are.”",
      style: {
        background: "#fff",
        border: "2px dashed #f9a8d4",
        borderRadius: "18px",
        padding: "12px",
        whiteSpace: "pre-wrap",
      },
    }),
    makeElement("callout", {
      x: 460,
      y: 760,
      w: 400,
      h: 100,
      content: "mood tracker  😊  😌  🥲  😴  💪",
      style: {
        background: "#fce7f3",
        borderRadius: "18px",
        padding: "12px",
        fontSize: "18px",
      },
    }),
  ],
});

const actionResearch: NoteTemplate = T({
  id: "action-research",
  name: "Action Research Chapter",
  category: "Planning",
  description: "Pink study sheet with a looping action-research cycle and summary bubbles.",
  cover: "/covers/strawberry-stationery.jpg",
  width: 900,
  height: 1200,
  background: "#fff1f5",
  paper: "pink",
  elements: [
    hd("ACTION RESEARCH", 80, 36, {
      style: { fontFamily: "Fredoka, sans-serif", fontSize: "36px", color: "#db2777", letterSpacing: "0.06em" },
    }),
    txt("chapter 1", 80, 84, 200, {
      style: { fontFamily: "Caveat, cursive", fontSize: "22px", color: "#f472b6" },
    }),
    makeSticker("heart", { x: 520, y: 30, w: 48, h: 48 }),
    makeSticker("ribbon", { x: 780, y: 36, w: 48, h: 48 }),
    makeShape("circle", {
      x: 70,
      y: 140,
      w: 150,
      h: 150,
      style: { fill: "#fce7f3", stroke: "#f472b6", color: "#9d174d", fontSize: "13px" },
      meta: { kind: "circle", text: "1. Identify\nthe problem" },
    }),
    makeShape("circle", {
      x: 260,
      y: 140,
      w: 150,
      h: 150,
      style: { fill: "#fbcfe8", stroke: "#ec4899", color: "#9d174d", fontSize: "13px" },
      meta: { kind: "circle", text: "2. Gather\ndata" },
    }),
    makeShape("circle", {
      x: 450,
      y: 140,
      w: 150,
      h: 150,
      style: { fill: "#fce7f3", stroke: "#f472b6", color: "#9d174d", fontSize: "13px" },
      meta: { kind: "circle", text: "3. Plan\naction" },
    }),
    makeShape("circle", {
      x: 640,
      y: 140,
      w: 150,
      h: 150,
      style: { fill: "#fbcfe8", stroke: "#ec4899", color: "#9d174d", fontSize: "13px" },
      meta: { kind: "circle", text: "4. Act &\nobserve" },
    }),
    makeElement("callout", {
      x: 70,
      y: 330,
      w: 760,
      h: 90,
      content: "5. Reflect  →  revise the plan  →  loop again. Action research is a spiral, not a straight line.",
      style: {
        background: "#fff",
        border: "2px solid #f9a8d4",
        borderRadius: "20px",
        padding: "16px",
        fontFamily: "Nunito, sans-serif",
        color: "#9d174d",
      },
    }),
    hd("writing · observing · learning", 70, 450, {
      style: { fontFamily: "Caveat, cursive", fontSize: "24px", color: "#be185d" },
    }),
    txt(
      "Process\n1. Notice a classroom or study problem.\n2. Collect small, kind evidence (notes, ticks, scores).\n3. Try one gentle change.\n4. Watch what happens.\n5. Write a reflection — then begin again.",
      70,
      510,
      760,
      { h: 200, style: { whiteSpace: "pre-wrap", fontSize: "15px", lineHeight: "1.55" } },
    ),
    makeSticker("flower", { x: 70, y: 760, w: 48, h: 48 }),
    makeSticker("heart", { x: 130, y: 770, w: 40, h: 40 }),
  ],
});

const functions: NoteTemplate = T({
  id: "functions-inverse",
  name: "Functions & Inverses",
  category: "STEM",
  description: "Graph-paper algebra notes with f(x) sketches and inverse-function steps.",
  cover: "/covers/sakura-desk.jpg",
  width: 900,
  height: 1200,
  background: "#f7f4ea",
  paper: "grid",
  elements: [
    hd("FUNCTIONS & INVERSE FUNCTIONS", 48, 24, {
      style: { fontFamily: "Nunito, sans-serif", fontSize: "22px", color: "#1e3a5f", letterSpacing: "0.04em" },
    }),
    makeElement("chart", {
      x: 48,
      y: 80,
      w: 250,
      h: 180,
      content: JSON.stringify({ kind: "fn", fn: "x2" }),
    }),
    makeElement("chart", {
      x: 320,
      y: 80,
      w: 250,
      h: 180,
      content: JSON.stringify({ kind: "fn", fn: "sqrt" }),
    }),
    makeElement("chart", {
      x: 592,
      y: 80,
      w: 250,
      h: 180,
      content: JSON.stringify({ kind: "fn", fn: "inv" }),
    }),
    hd("INVERSE FUNCTIONS", 48, 290, {
      style: { fontSize: "18px", color: "#1d4ed8", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "An inverse function undoes the original function. Swap x and y, then solve for y.\nIf f(a) = b then f⁻¹(b) = a. Graphs of inverses reflect across y = x.",
      48,
      330,
      800,
      { h: 80, style: { fontSize: "15px" } },
    ),
    makeElement("callout", {
      x: 48,
      y: 430,
      w: 380,
      h: 160,
      content: "Example\nf(x) = 2x + 3\ny = 2x + 3\nx = 2y + 3\n(x − 3)/2 = y\nf⁻¹(x) = (x − 3)/2",
      style: {
        background: "#fff",
        border: "2px solid #93c5fd",
        borderRadius: "12px",
        padding: "12px",
        whiteSpace: "pre-wrap",
        fontFamily: "Nunito, sans-serif",
        fontSize: "14px",
      },
    }),
    makeElement("callout", {
      x: 460,
      y: 430,
      w: 390,
      h: 160,
      content:
        "Check\nf(f⁻¹(x)) = x\nf⁻¹(f(x)) = x\nDomain of f = range of f⁻¹",
      style: {
        background: "#fef9c3",
        border: "2px solid #facc15",
        borderRadius: "12px",
        padding: "12px",
        whiteSpace: "pre-wrap",
        fontSize: "14px",
      },
    }),
    makeSticker("pencil", { x: 800, y: 24, w: 48, h: 48 }),
  ],
});

const mindPatriot: NoteTemplate = T({
  id: "patriotism-mindmap",
  name: "Main Idea Mind Map",
  category: "Mind Map",
  description: "Radial mind map with a central claim and satellite bubbles — ready to reconnect.",
  cover: "/covers/starry-clouds.jpg",
  width: 1100,
  height: 900,
  background: "#fffdfa",
  paper: "plain",
  elements: [
    hd("notes on patriotism", 40, 16, {
      style: { fontFamily: "Caveat, cursive", fontSize: "28px", color: "#e11d48" },
    }),
    makeShape("rounded", {
      x: 430,
      y: 340,
      w: 240,
      h: 120,
      style: { fill: "#fecdd3", stroke: "#e11d48", color: "#881337", fontSize: "16px", fontWeight: "700" },
      meta: { kind: "rounded", text: "Main Idea" },
      connections: [],
    }),
    makeShape("circle", {
      x: 80,
      y: 80,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "history &\nmemory" },
    }),
    makeShape("circle", {
      x: 460,
      y: 40,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "symbols &\nrituals" },
    }),
    makeShape("circle", {
      x: 840,
      y: 80,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "belonging\n& identity" },
    }),
    makeShape("circle", {
      x: 40,
      y: 360,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "critique &\ncare" },
    }),
    makeShape("circle", {
      x: 860,
      y: 360,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "duty &\nvoice" },
    }),
    makeShape("circle", {
      x: 200,
      y: 620,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "youth &\nhope" },
    }),
    makeShape("circle", {
      x: 700,
      y: 620,
      w: 170,
      h: 170,
      style: { fill: "#fff", stroke: "#fb7185", color: "#9f1239", fontSize: "12px" },
      meta: { kind: "circle", text: "stories we\ntell" },
    }),
    txt("topic summary — when art begins to serve a purpose other than simply beauty, the conversation becomes unforgettable.", 200, 820, 700, {
      h: 50,
      style: { fontFamily: "Patrick Hand, cursive", fontSize: "16px", color: "#9f1239" },
    }),
  ],
});

const narrativa: NoteTemplate = T({
  id: "nueva-narrativa",
  name: "Nueva Narrativa Hispanoamericana",
  category: "Language",
  description: "Literary study sheet with three-column characteristics and author cards.",
  cover: "/covers/sakura-desk.jpg",
  width: 900,
  height: 1300,
  background: "#f8fafc",
  paper: "plain",
  elements: [
    hd("Nueva", 48, 24, {
      style: { fontFamily: "Fredoka, sans-serif", fontSize: "22px", color: "#4c1d95", background: "#ddd6fe", padding: "4px 10px" },
    }),
    hd("narrativa", 48, 60, {
      style: { fontFamily: "Pacifico, cursive", fontSize: "40px", color: "#1e1b4b" },
    }),
    txt("HISPANOAMERICANA", 52, 112, 400, {
      style: { letterSpacing: "0.28em", fontSize: "12px", color: "#6d28d9", fontWeight: "800" },
    }),
    makeSticker("sparkles", { x: 780, y: 30, w: 48, h: 48 }),
    txt(
      "Resultado del impacto de las corrientes vanguardistas en el campo de los géneros narrativos. Tendencia que se desarrolló en Latinoamérica (1920–1970) influida por las nuevas técnicas narrativas.",
      48,
      150,
      800,
      { h: 80, style: { fontSize: "14px", lineHeight: "1.5" } },
    ),
    hd("Características", 48, 240, {
      style: { fontFamily: "Caveat, cursive", fontSize: "32px", color: "#6d28d9" },
    }),
    makeElement("columns", {
      x: 40,
      y: 290,
      w: 820,
      h: 160,
      content: JSON.stringify({
        cols: 3,
        texts: [
          "Multiplicidad de voces o puntos de vista — participación activa del lector.",
          "Ruptura del orden lógico y cronológico del relato — experimentalismo lingüístico.",
          "Transculturación narrativa — realismo mágico o real maravilloso.",
        ],
      }),
    }),
    makeElement("callout", {
      x: 40,
      y: 470,
      w: 260,
      h: 70,
      content: "E. EMERGENTE",
      style: { background: "#c4b5fd", color: "#4c1d95", borderRadius: "8px", fontWeight: "800", display: "grid", placeItems: "center" },
    }),
    makeElement("callout", {
      x: 320,
      y: 470,
      w: 260,
      h: 70,
      content: "CONSOLIDACIÓN",
      style: { background: "#a78bfa", color: "white", borderRadius: "8px", fontWeight: "800", display: "grid", placeItems: "center" },
    }),
    makeElement("callout", {
      x: 600,
      y: 470,
      w: 260,
      h: 70,
      content: "E. DE APOGEO",
      style: { background: "#6d28d9", color: "white", borderRadius: "8px", fontWeight: "800", display: "grid", placeItems: "center" },
    }),
    makeElement("callout", {
      x: 40,
      y: 560,
      w: 400,
      h: 150,
      content: "MIGUEL ÁNGEL ASTURIAS\nLeyendas de Guatemala · El señor Presidente · Hombres de maíz",
      style: { background: "#fff", border: "2px solid #c4b5fd", borderRadius: "12px", padding: "12px", whiteSpace: "pre-wrap", fontSize: "14px" },
    }),
    makeElement("callout", {
      x: 460,
      y: 560,
      w: 400,
      h: 150,
      content: "ALEJO CARPENTIER\nEl reino de este mundo · realismo mágico · Premio Cervantes 1977",
      style: { background: "#fff", border: "2px solid #c4b5fd", borderRadius: "12px", padding: "12px", whiteSpace: "pre-wrap", fontSize: "14px" },
    }),
    makeElement("callout", {
      x: 40,
      y: 730,
      w: 400,
      h: 150,
      content: "JORGE LUIS BORGES\nEl Aleph · Ficciones · estilo conciso, laberintos, el infinito",
      style: { background: "#fff", border: "2px solid #c4b5fd", borderRadius: "12px", padding: "12px", whiteSpace: "pre-wrap", fontSize: "14px" },
    }),
    makeElement("callout", {
      x: 460,
      y: 730,
      w: 400,
      h: 150,
      content: "JUAN RULFO\nPedro Páramo · El llano en llamas · narradores que cuentan la historia desde diferentes planos",
      style: { background: "#fff", border: "2px solid #c4b5fd", borderRadius: "12px", padding: "12px", whiteSpace: "pre-wrap", fontSize: "14px" },
    }),
  ],
});

const dreamJournal: NoteTemplate = T({
  id: "dream-journal",
  name: "Sapphire Ocean Dream Journal",
  category: "Journal",
  description: "Moonlit blue dream log with mood chips, symbols, and a reflection tide.",
  cover: "/covers/night-cat.jpg",
  width: 900,
  height: 1200,
  background: "#eef5ff",
  paper: "plain",
  elements: [
    imageElArt("/art/dream-ocean.jpg", { x: 0, y: 0, w: 900, h: 160 }),
    hd("DREAM JOURNAL", 48, 24, {
      style: { fontFamily: "Fredoka, sans-serif", fontSize: "28px", color: "#1e3a8a", letterSpacing: "0.12em" },
    }),
    txt("Oct 28th, Mon", 48, 64, 240, { style: { color: "#1d4ed8", fontWeight: "700" } }),
    txt("BEFORE SLEEP MOOD  😊", 520, 64, 320, { style: { color: "#1e40af" } }),
    hd("DREAM TITLE: The Sapphire Ocean", 48, 180, {
      style: { fontFamily: "Caveat, cursive", fontSize: "28px", color: "#1d4ed8" },
    }),
    makeElement("callout", {
      x: 40,
      y: 230,
      w: 820,
      h: 200,
      content:
        "DREAM DESCRIPTION\nI was swimming in a vast, glowing blue ocean. The water was clear and warm. I swam with bioluminescent sea turtles and saw an ancient city made of sapphire and aquamarine on the seafloor. A wise old turtle gave me a glowing blue pearl.",
      style: {
        background: "#dbeafe",
        borderRadius: "20px",
        padding: "16px",
        whiteSpace: "pre-wrap",
        fontFamily: "Nunito, sans-serif",
        color: "#1e3a8a",
        fontSize: "15px",
      },
    }),
    makeElement("callout", {
      x: 40,
      y: 450,
      w: 400,
      h: 150,
      content: "EMOTION DURING DREAM\nCALM / HAPPY / EXCITED / OTHER:\npeaceful · enchanted · serene",
      style: {
        background: "#eff6ff",
        border: "2px solid #93c5fd",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        color: "#1e3a8a",
      },
    }),
    makeElement("callout", {
      x: 460,
      y: 450,
      w: 400,
      h: 150,
      content: "SYMBOLS I REMEMBER\nBlue ocean · Sea turtles\nSapphire city · Blue pearl",
      style: {
        background: "#dbeafe",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        color: "#1e3a8a",
      },
    }),
    makeElement("callout", {
      x: 40,
      y: 620,
      w: 820,
      h: 140,
      content: "POSSIBLE MEANING / REFLECTION\nExploring emotions, seeking wisdom and clarity. How I felt when waking: Peaceful · Enchanted · Serene",
      style: {
        background: "#fff",
        border: "2px dashed #60a5fa",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        color: "#1e3a8a",
      },
    }),
    makeSticker("moon", { x: 800, y: 180, w: 52, h: 52 }),
    makeSticker("turtle", { x: 48, y: 790, w: 52, h: 52 }),
    makeSticker("crystal", { x: 110, y: 800, w: 48, h: 48 }),
    makeSticker("butterfly", { x: 170, y: 790, w: 48, h: 48 }),
  ],
});

function imageElArt(src: string, partial: Partial<CanvasElement>): CanvasElement {
  return makeElement("image", { content: src, ...partial });
}

const cornell: NoteTemplate = T({
  id: "cornell-notes",
  name: "Cornell Notetaking",
  category: "Study",
  description: "Classic Cornell layout: cues, notes column, and a summary banner.",
  cover: "/covers/strawberry-stationery.jpg",
  width: 900,
  height: 1200,
  background: "#fffef8",
  paper: "plain",
  elements: [
    hd("CORNELL NOTETAKING", 200, 24, {
      style: { fontFamily: "Fredoka, sans-serif", fontSize: "28px", letterSpacing: "0.12em", color: "#1c1917" },
    }),
    makeElement("callout", {
      x: 40,
      y: 90,
      w: 240,
      h: 50,
      content: "CUES",
      style: { background: "#1c1917", color: "white", display: "grid", placeItems: "center", fontWeight: "800", letterSpacing: "0.2em" },
    }),
    makeElement("callout", {
      x: 300,
      y: 90,
      w: 560,
      h: 50,
      content: "NOTETAKING",
      style: { background: "#1c1917", color: "white", display: "grid", placeItems: "center", fontWeight: "800", letterSpacing: "0.2em" },
    }),
    makeElement("callout", {
      x: 40,
      y: 150,
      w: 240,
      h: 620,
      content:
        "CREATE\nPRACTICE\nQUESTIONS\n\nto quiz your understanding after class.\n\nNOTED\nINFO\nfrom the right-hand notetaking column",
      style: {
        background: "#fafaf9",
        border: "2px solid #1c1917",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Nunito, sans-serif",
        fontSize: "14px",
      },
    }),
    makeElement("callout", {
      x: 300,
      y: 150,
      w: 560,
      h: 620,
      content:
        "RECORD  during the class, information in concise sentences.\n\nQUESTIONS  consider the use of this data — the principle, the significance, and its future application.\n\nRECITE  search for terminology, meaning and implementation.\n\nEXEMPLIFY  use examples and mnemonics for better retention.\n\nAPPEALS  make it aesthetically pleasing along with practical.",
      style: {
        background: "#fff",
        border: "2px solid #1c1917",
        padding: "16px",
        whiteSpace: "pre-wrap",
        fontSize: "15px",
        lineHeight: "1.5",
      },
    }),
    makeElement("callout", {
      x: 40,
      y: 790,
      w: 820,
      h: 140,
      content:
        "SUMMARY   Condense your notes using CUES to aid REVISION for ASSESSMENTS.",
      style: {
        background: "#fafaf9",
        border: "3px solid #1c1917",
        padding: "16px",
        fontWeight: "700",
        letterSpacing: "0.04em",
      },
    }),
  ],
});

const genes: NoteTemplate = T({
  id: "gene-basics",
  name: "Gene Basics & Pedigrees",
  category: "STEM",
  description: "Kawaii biology page covering gene basics, pedigree patterns, and punnett hearts.",
  cover: "/covers/starry-clouds.jpg",
  width: 900,
  height: 1250,
  background: "#fffaf4",
  paper: "lined",
  elements: [
    hd("U2AOS1", 48, 20, {
      style: { fontFamily: "Fredoka, sans-serif", fontSize: "28px", color: "#be185d" },
    }),
    makeSticker("strawberry", { x: 180, y: 16, w: 40, h: 40 }),
    makeSticker("strawberry", { x: 220, y: 16, w: 40, h: 40 }),
    makeSticker("bear", { x: 780, y: 16, w: 56, h: 56 }),
    hd("GENE BASICS:", 48, 80, {
      style: { fontSize: "18px", color: "#9d174d", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "• Gene — a section of DNA that codes for a specific trait.\n• Genome — the complete genetic set of an organism.\n• Alleles — different versions of the same gene or trait.\n• Nucleotide — the basic building blocks of DNA.\n• Autosomal / Sex Chromosomes — the numbered chromosomes vs X and Y.",
      48,
      120,
      800,
      { h: 160, style: { whiteSpace: "pre-wrap", fontSize: "14px" } },
    ),
    hd("PEDIGREE PATTERNS:", 48, 300, {
      style: { fontSize: "18px", color: "#9d174d", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "• Autosomal Dominant — trait appears every generation; affected kids have an affected parent.\n• Autosomal Recessive — may skip generations; two carriers can have an affected child.\n• X-linked Recessive — more common in males; never father-to-son.\n• X-linked Dominant — affected fathers pass to all daughters.",
      48,
      340,
      800,
      { h: 160, style: { whiteSpace: "pre-wrap", fontSize: "14px" } },
    ),
    makeSticker("paw", { x: 48, y: 520, w: 48, h: 48 }),
    hd("MONO / DIHYBRID CROSS PATTERNS:", 48, 580, {
      style: { fontSize: "16px", color: "#be185d", fontFamily: "Fredoka, sans-serif" },
    }),
    txt(
      "Monohybrid Aa × Aa  →  3:1 phenotype, 1:2:1 genotype\nDihybrid AaBb × AaBb  →  9:3:3:1\nTest cross with recessive to reveal unknowns.",
      48,
      620,
      700,
      { h: 110, style: { whiteSpace: "pre-wrap" } },
    ),
    makeSticker("heart", { x: 780, y: 620, w: 48, h: 48 }),
    makeSticker("chick", { x: 780, y: 680, w: 52, h: 52 }),
  ],
});

const coral: NoteTemplate = T({
  id: "coral-reef",
  name: "Arrecife Coralino",
  category: "STEM",
  description: "Dotted ocean study poster with creature callouts, habitat chips, and a quote bubble.",
  cover: "/covers/night-cat.jpg",
  width: 900,
  height: 1250,
  background: "#f4fbff",
  paper: "dots",
  elements: [
    imageElArt("/art/coral-banner.jpg", { x: 0, y: 0, w: 900, h: 120 }),
    hd("ARRECIFE", 300, 20, {
      style: { fontFamily: "Fredoka, sans-serif", fontSize: "18px", color: "#1e3a8a", letterSpacing: "0.4em" },
    }),
    hd("coralino", 250, 48, {
      style: { fontFamily: "Pacifico, cursive", fontSize: "42px", color: "#2563eb" },
    }),
    txt(
      "Estos ecosistemas subacuáticos son extraordinariamente diversos, formados en aguas cálidas, limpias y poco profundas de los mares tropicales. Los corales son los elementos fundamentales de la construcción de arrecifes.",
      48,
      140,
      800,
      { h: 90, style: { fontSize: "14px", color: "#1e3a8a", lineHeight: "1.5" } },
    ),
    makeElement("callout", {
      x: 40,
      y: 250,
      w: 380,
      h: 220,
      content:
        "Los ecosistemas de los arrecifes de coral son grupos intrínsecos y diversos de especies que interactúan entre sí y con el entorno físico. Los corales son una clase de colonia de animales.",
      style: {
        background: "#e0f2fe",
        borderRadius: "18px",
        padding: "16px",
        color: "#0c4a6e",
        fontSize: "14px",
      },
    }),
    makeElement("callout", {
      x: 440,
      y: 250,
      w: 420,
      h: 220,
      content:
        "Los corales pétreos se caracterizan por su esqueleto duro. Las colonias extraen el calcio disuelto del agua de mar y lo solidifican en carbonato de calcio — un soporte esquelético que puede tener décadas de antigüedad.",
      style: {
        background: "#dbeafe",
        borderRadius: "18px",
        padding: "16px",
        color: "#1e3a8a",
        fontSize: "14px",
      },
    }),
    makeSticker("whale", { x: 780, y: 140, w: 56, h: 56 }),
    makeSticker("fish", { x: 40, y: 490, w: 52, h: 52 }),
    makeElement("callout", {
      x: 40,
      y: 550,
      w: 500,
      h: 180,
      content:
        "Las zooxantelas son algas microscópicas que mantienen una relación simbiótica con los corales.\n\nhábitat  →  alimento  (producto fotosintético)",
      style: {
        background: "#fff",
        border: "2px solid #7dd3fc",
        borderRadius: "18px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        color: "#0c4a6e",
      },
    }),
    makeElement("callout", {
      x: 560,
      y: 550,
      w: 300,
      h: 220,
      content:
        "“Debido a que la fotosíntesis necesita de la luz del sol, la mayoría de los corales viven en aguas transparentes, superficiales.”",
      style: {
        background: "#38bdf8",
        color: "white",
        borderRadius: "999px",
        padding: "24px",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "16px",
      },
    }),
    makeSticker("coral", { x: 48, y: 760, w: 48, h: 48 }),
    makeSticker("turtle", { x: 110, y: 770, w: 48, h: 48 }),
  ],
});

const doodle: NoteTemplate = T({
  id: "doodle-journal",
  name: "Kawaii Doodle Dump",
  category: "Journal",
  description: "Sticker-bomb journal page with handwritten rambles, hearts, and snack doodles.",
  cover: "/covers/strawberry-stationery.jpg",
  width: 900,
  height: 1100,
  background: "#fff7fb",
  paper: "plain",
  elements: [
    hd("brain dump but make it cute", 48, 24, {
      style: { fontFamily: "Caveat, cursive", fontSize: "32px", color: "#db2777" },
    }),
    txt(
      "I gotta get wrapped around your fingers tonight.\nThoughts run through my head like tiny trains.\nSometimes the world feels upside down — that's okay.\nPudding club is now in session.",
      48,
      90,
      520,
      {
        h: 200,
        style: { fontFamily: "Caveat, cursive", fontSize: "22px", lineHeight: "1.45", whiteSpace: "pre-wrap" },
      },
    ),
    makeSticker("music", { x: 600, y: 80, w: 56, h: 56 }),
    makeSticker("cake", { x: 680, y: 140, w: 56, h: 56 }),
    makeSticker("boba", { x: 760, y: 90, w: 56, h: 56 }),
    makeSticker("heart", { x: 620, y: 220, w: 48, h: 48 }),
    makeSticker("star", { x: 700, y: 250, w: 44, h: 44 }),
    makeSticker("cat", { x: 780, y: 210, w: 52, h: 52 }),
    makeElement("callout", {
      x: 48,
      y: 330,
      w: 260,
      h: 80,
      content: "mood: sparkly tired",
      style: {
        background: "#fce7f3",
        borderRadius: "999px",
        display: "grid",
        placeItems: "center",
        fontFamily: "Fredoka, sans-serif",
        color: "#be185d",
      },
    }),
    makeElement("callout", {
      x: 330,
      y: 330,
      w: 260,
      h: 80,
      content: "snack: strawberry milk",
      style: {
        background: "#fbcfe8",
        borderRadius: "999px",
        display: "grid",
        placeItems: "center",
        fontFamily: "Fredoka, sans-serif",
        color: "#9d174d",
      },
    }),
    makeElement("callout", {
      x: 610,
      y: 330,
      w: 240,
      h: 80,
      content: "song: lo-fi rain",
      style: {
        background: "#ede9fe",
        borderRadius: "999px",
        display: "grid",
        placeItems: "center",
        fontFamily: "Fredoka, sans-serif",
        color: "#6d28d9",
      },
    }),
    txt("write whatever is buzzing… this page is a safe mess.", 48, 440, 800, {
      h: 80,
      style: { fontFamily: "Patrick Hand, cursive", fontSize: "20px", color: "#9d174d" },
    }),
    makeSticker("ribbon", { x: 48, y: 540, w: 48, h: 48 }),
    makeSticker("flower", { x: 110, y: 550, w: 44, h: 44 }),
    makeSticker("sparkles", { x: 170, y: 540, w: 44, h: 44 }),
  ],
});

const planner: NoteTemplate = T({
  id: "kawaii-planner",
  name: "Pink Binder Planner",
  category: "Planning",
  description: "Cute binder daily planner with schedule, tiny mascot, and gratitude lines.",
  cover: "/covers/starry-clouds.jpg",
  width: 780,
  height: 1100,
  background: "#fff0f6",
  paper: "pink",
  elements: [
    hd("today's little plan", 70, 30, {
      style: { fontFamily: "Pacifico, cursive", fontSize: "30px", color: "#be185d" },
    }),
    makeSticker("bunny", { x: 640, y: 24, w: 56, h: 56 }),
    makeSticker("star", { x: 700, y: 70, w: 40, h: 40 }),
    makeElement("todo", {
      x: 50,
      y: 110,
      w: 680,
      h: 260,
      content: JSON.stringify([
        { text: "morning pages + tea", done: false },
        { text: "deep work block", done: false },
        { text: "stretch / water", done: false },
        { text: "review flashcards", done: false },
        { text: "evening recap", done: false },
      ]),
    }),
    makeElement("callout", {
      x: 50,
      y: 400,
      w: 330,
      h: 180,
      content: "schedule\n9:00  warm-up\n10:00 focus\n1:00  lunch walk\n3:00  review",
      style: {
        background: "#fff",
        border: "2px solid #f9a8d4",
        borderRadius: "22px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Nunito, sans-serif",
        color: "#9d174d",
      },
    }),
    makeElement("callout", {
      x: 400,
      y: 400,
      w: 330,
      h: 180,
      content: "gratitude\n1.\n2.\n3.",
      style: {
        background: "#fce7f3",
        borderRadius: "22px",
        padding: "14px",
        whiteSpace: "pre-wrap",
        fontFamily: "Patrick Hand, cursive",
        fontSize: "18px",
        color: "#9d174d",
      },
    }),
    makeElement("callout", {
      x: 50,
      y: 600,
      w: 680,
      h: 140,
      content: "a note from me to me — I tried, and that is already a soft kind of brave.",
      style: {
        background: "#fff",
        border: "2px dashed #f472b6",
        borderRadius: "22px",
        padding: "16px",
        fontFamily: "Caveat, cursive",
        fontSize: "22px",
        color: "#9d174d",
      },
    }),
    makeSticker("heart", { x: 50, y: 770, w: 44, h: 44 }),
    makeSticker("cat", { x: 110, y: 770, w: 48, h: 48 }),
  ],
});

const blank: NoteTemplate = T({
  id: "blank-page",
  name: "Blank Cream Page",
  category: "Blank",
  description: "Empty free-flow canvas. Click anywhere and start typing.",
  cover: "/covers/starry-clouds.jpg",
  width: 900,
  height: 1200,
  background: "#fffdf8",
  paper: "plain",
  elements: [
    txt("Click anywhere and start typing…", 60, 60, 500, {
      style: { color: "#d8b4c8", fontStyle: "italic" },
    }),
  ],
});

export const TEMPLATES: NoteTemplate[] = [
  blank,
  hypothesis,
  loveLetter,
  figures,
  cells,
  dailyJournal,
  actionResearch,
  functions,
  mindPatriot,
  narrativa,
  dreamJournal,
  cornell,
  genes,
  coral,
  doodle,
  planner,
];

export function getTemplate(id: string) {
  return TEMPLATES.find((t) => t.id === id);
}

export function makeWidget(
  kind: "progress" | "todo" | "quote" | "timer",
  partial: Partial<CanvasElement> = {},
): CanvasElement {
  if (kind === "progress") {
    return makeElement("progress", { content: "40", meta: { label: "Goal", color: "#f9a8d4" }, ...partial });
  }
  if (kind === "todo") {
    return makeElement("todo", {
      content: JSON.stringify([{ text: "New task", done: false }]),
      ...partial,
    });
  }
  if (kind === "timer") {
    return makeElement("widget", { content: "timer", w: 200, h: 80, ...partial });
  }
  return makeElement("callout", {
    content: "The expert in anything was once a beginner.",
    ...partial,
  });
}

export const DEFAULT_POMODORO = 25 * 60;
export const SHORT_BREAK = 5 * 60;
export const LONG_BREAK = 15 * 60;

export type SessionType = "pomodoro" | "short_break" | "long_break" | "custom";
export type SessionStatus = "idle" | "running" | "paused" | "completed";

export function formatTime(totalSeconds: number) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

export function formatHours(minutes: number) {
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  if (h <= 0) return `${m}m`;
  return `${h}h ${m}m`;
}

export function hoursLabel(minutes: number, targetMinutes: number) {
  const studied = minutes / 60;
  const target = targetMinutes / 60;
  return `${studied.toFixed(0)} / ${target.toFixed(0)} hrs`;
}

export function sessionTypeLabel(type: SessionType) {
  switch (type) {
    case "pomodoro":
      return "Pomodoro";
    case "short_break":
      return "Short Break";
    case "long_break":
      return "Long Break";
    default:
      return "Focus";
  }
}

export function durationForType(
  type: SessionType,
  prefs?: { pomodoroMinutes?: number; shortBreakMinutes?: number; longBreakMinutes?: number },
) {
  if (type === "pomodoro") return (prefs?.pomodoroMinutes ?? 25) * 60;
  if (type === "short_break") return (prefs?.shortBreakMinutes ?? 5) * 60;
  if (type === "long_break") return (prefs?.longBreakMinutes ?? 15) * 60;
  return DEFAULT_POMODORO;
}

export function todayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(key: string, days: number) {
  const [y, m, d] = key.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  return todayKey(dt);
}

import { makeElement } from "./elements";
import type { CanvasElement } from "./types";

export type ShapeKind =
  | "circle"
  | "rectangle"
  | "rounded"
  | "cloud"
  | "blob"
  | "diamond"
  | "star"
  | "arrow"
  | "hex"
  | "heart";

export const SHAPES: { id: ShapeKind; name: string }[] = [
  { id: "circle", name: "Circle" },
  { id: "rectangle", name: "Rectangle" },
  { id: "rounded", name: "Rounded" },
  { id: "cloud", name: "Cloud" },
  { id: "blob", name: "Blob" },
  { id: "diamond", name: "Diamond" },
  { id: "star", name: "Star" },
  { id: "arrow", name: "Arrow" },
  { id: "hex", name: "Hexagon" },
  { id: "heart", name: "Heart" },
];

export function makeShape(
  kind: ShapeKind,
  partial: Partial<CanvasElement> = {},
): CanvasElement {
  const defaults: Record<ShapeKind, Partial<CanvasElement>> = {
    circle: { w: 140, h: 140 },
    rectangle: { w: 180, h: 90 },
    rounded: { w: 180, h: 100 },
    cloud: { w: 180, h: 110 },
    blob: { w: 160, h: 140 },
    diamond: { w: 130, h: 130 },
    star: { w: 120, h: 120 },
    arrow: { w: 160, h: 48 },
    hex: { w: 130, h: 130 },
    heart: { w: 120, h: 110 },
  };
  return makeElement("shape", {
    ...defaults[kind],
    content: kind,
    style: {
      fill: "#fce7f3",
      stroke: "#f9a8d4",
      strokeWidth: "2.5",
      color: "#4a3558",
      fontFamily: "Nunito, sans-serif",
      fontSize: "13px",
    },
    meta: { kind, text: "" },
    connections: [],
    ...partial,
  });
}

export function shapeCenter(el: CanvasElement) {
  return { x: el.x + el.w / 2, y: el.y + el.h / 2 };
}

export function distance(a: CanvasElement, b: CanvasElement) {
  const ca = shapeCenter(a);
  const cb = shapeCenter(b);
  return Math.hypot(ca.x - cb.x, ca.y - cb.y);
}

export function autoConnect(shapes: CanvasElement[], threshold = 180) {
  const next = shapes.map((s) => ({ ...s, connections: [...(s.connections ?? [])] }));
  for (let i = 0; i < next.length; i++) {
    for (let j = i + 1; j < next.length; j++) {
      if (distance(next[i], next[j]) < threshold) {
        if (!next[i].connections!.includes(next[j].id)) next[i].connections!.push(next[j].id);
        if (!next[j].connections!.includes(next[i].id)) next[j].connections!.push(next[i].id);
      }
    }
  }
  return next;
}

export function toggleConnection(elements: CanvasElement[], aId: string, bId: string) {
  return elements.map((el) => {
    if (el.id !== aId && el.id !== bId) return el;
    const other = el.id === aId ? bId : aId;
    const has = (el.connections ?? []).includes(other);
    const connections = has
      ? (el.connections ?? []).filter((id) => id !== other)
      : [...(el.connections ?? []), other];
    return { ...el, connections };
  });
}

import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { noteTags, notes } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const user = await getOrCreateUser();
  const rows = await db
    .select()
    .from(notes)
    .where(and(eq(notes.id, id), eq(notes.userId, user.id)))
    .limit(1);
  if (!rows[0]) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const links = await db.select().from(noteTags).where(eq(noteTags.noteId, id));
  return NextResponse.json({ ...rows[0], tagIds: links.map((l) => l.tagId) });
}

export async function PATCH(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const user = await getOrCreateUser();
  const body = (await req.json()) as Record<string, unknown>;
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  const allowed = [
    "title",
    "subjectId",
    "projectId",
    "templateId",
    "kind",
    "content",
    "coverImage",
    "pinned",
    "archived",
    "canvasWidth",
    "canvasHeight",
    "background",
  ];
  for (const key of allowed) {
    if (key in body) patch[key] = body[key];
  }
  const [row] = await db
    .update(notes)
    .set(patch)
    .where(and(eq(notes.id, id), eq(notes.userId, user.id)))
    .returning();
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (Array.isArray(body.tagIds)) {
    await db.delete(noteTags).where(eq(noteTags.noteId, id));
    const ids = body.tagIds as string[];
    if (ids.length) {
      await db.insert(noteTags).values(ids.map((tagId) => ({ noteId: id, tagId })));
    }
  }
  return NextResponse.json(row);
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const user = await getOrCreateUser();
  const existing = await db
    .select()
    .from(notes)
    .where(and(eq(notes.id, id), eq(notes.userId, user.id)))
    .limit(1);
  if (!existing[0]) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!existing[0].archived) {
    const [row] = await db
      .update(notes)
      .set({ archived: true, updatedAt: new Date() })
      .where(eq(notes.id, id))
      .returning();
    return NextResponse.json(row);
  }
  await db.delete(notes).where(eq(notes.id, id));
  return NextResponse.json({ ok: true, deleted: true });
}

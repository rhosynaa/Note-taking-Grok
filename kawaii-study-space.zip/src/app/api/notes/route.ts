import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notes } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";
import { getTemplate, instantiateTemplate } from "@/lib/templates";
import { randomCover } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db.select().from(notes).where(eq(notes.userId, user.id)).orderBy(desc(notes.updatedAt));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    title?: string;
    templateId?: string;
    subjectId?: string | null;
    projectId?: string | null;
    kind?: string;
    coverImage?: string | null;
    content?: unknown[];
    background?: string;
    canvasWidth?: number;
    canvasHeight?: number;
  };
  const tmpl = body.templateId ? getTemplate(body.templateId) : undefined;
  const inst = tmpl ? instantiateTemplate(tmpl) : null;
  const [row] = await db
    .insert(notes)
    .values({
      userId: user.id,
      title: body.title || tmpl?.name || "Untitled note",
      templateId: body.templateId ?? null,
      subjectId: body.subjectId ?? null,
      projectId: body.projectId ?? null,
      kind: body.kind || (body.templateId?.includes("mindmap") ? "mindmap" : "note"),
      content: body.content ?? inst?.elements ?? [],
      coverImage: body.coverImage ?? tmpl?.cover ?? randomCover(body.title || String(Date.now())),
      background: body.background ?? inst?.background ?? tmpl?.background ?? "#fffdf8",
      canvasWidth: body.canvasWidth ?? inst?.width ?? 900,
      canvasHeight: body.canvasHeight ?? inst?.height ?? 1200,
    })
    .returning();
  return NextResponse.json(row);
}

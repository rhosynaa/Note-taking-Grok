import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { subjects, timeEntries } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";
import {
  computeStreak,
  dailyBreakdown,
  monthlyBreakdown,
  mostStudiedSubject,
  subjectProgress,
  totalMinutes,
  weeklyBreakdown,
} from "@/lib/analytics";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const entries = await db.select().from(timeEntries).where(eq(timeEntries.userId, user.id));
  const subjectRows = await db.select().from(subjects).where(eq(subjects.userId, user.id));
  const mapped = entries.map((e) => ({
    ...e,
    createdAt: e.createdAt?.toISOString?.() ?? String(e.createdAt),
  }));
  return NextResponse.json({
    daily: dailyBreakdown(mapped),
    weekly: weeklyBreakdown(mapped),
    monthly: monthlyBreakdown(mapped),
    subjects: subjectProgress(mapped, subjectRows),
    streak: computeStreak(mapped),
    totalMinutes: totalMinutes(mapped),
    mostStudied: mostStudiedSubject(mapped, subjectRows),
  });
}

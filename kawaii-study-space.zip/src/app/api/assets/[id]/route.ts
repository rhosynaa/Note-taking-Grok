import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { customAssets } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const rows = await db.select().from(customAssets).where(eq(customAssets.id, id)).limit(1);
  const row = rows[0];
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const base64 = row.data.includes(",") ? row.data.split(",")[1] : row.data;
  const buf = Buffer.from(base64, "base64");
  return new NextResponse(new Uint8Array(buf), {
    headers: {
      "Content-Type": row.mimeType || "application/octet-stream",
      "Cache-Control": "public, max-age=31536000, immutable",
      "Content-Disposition": `inline; filename="${encodeURIComponent(row.name)}"`,
    },
  });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  await db.delete(customAssets).where(eq(customAssets.id, id));
  return NextResponse.json({ ok: true });
}

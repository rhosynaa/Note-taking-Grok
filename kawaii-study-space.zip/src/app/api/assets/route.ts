import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { customAssets } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db
    .select({
      id: customAssets.id,
      name: customAssets.name,
      mimeType: customAssets.mimeType,
      kind: customAssets.kind,
      createdAt: customAssets.createdAt,
      url: customAssets.id,
    })
    .from(customAssets)
    .where(eq(customAssets.userId, user.id));
  return NextResponse.json(rows.map((r) => ({ ...r, url: `/api/assets/${r.id}` })));
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    name?: string;
    mimeType?: string;
    data?: string;
    kind?: string;
  };
  if (!body.data) return NextResponse.json({ error: "Missing file data" }, { status: 400 });
  if (body.data.length > 8_000_000) {
    return NextResponse.json({ error: "File too large (max ~6MB)" }, { status: 413 });
  }
  const [row] = await db
    .insert(customAssets)
    .values({
      userId: user.id,
      name: body.name || "upload",
      mimeType: body.mimeType || "application/octet-stream",
      data: body.data,
      kind: body.kind || "image",
    })
    .returning({
      id: customAssets.id,
      name: customAssets.name,
      mimeType: customAssets.mimeType,
      kind: customAssets.kind,
      createdAt: customAssets.createdAt,
    });
  return NextResponse.json({ ...row, url: `/api/assets/${row.id}` });
}

import { NextResponse } from "next/server";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { notes, tags, tasks } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const user = await getOrCreateUser();
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").trim();
  if (!q) return NextResponse.json({ notes: [], tasks: [], tags: [] });
  const pattern = `%${q}%`;
  const [noteRows, taskRows, tagRows] = await Promise.all([
    db
      .select()
      .from(notes)
      .where(
        and(
          eq(notes.userId, user.id),
          or(ilike(notes.title, pattern), sql`coalesce(${notes.content}::text, '') ilike ${pattern}`),
        ),
      ),
    db
      .select()
      .from(tasks)
      .where(and(eq(tasks.userId, user.id), ilike(tasks.title, pattern))),
    db
      .select()
      .from(tags)
      .where(and(eq(tags.userId, user.id), ilike(tags.name, pattern))),
  ]);
  return NextResponse.json({ notes: noteRows, tasks: taskRows, tags: tagRows });
}

import { NextResponse } from "next/server";
import { USER_COOKIE, getOrCreateUser } from "@/lib/session";
import { loadWorkspace, seedWorkspace } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  await seedWorkspace(user.id);
  const data = await loadWorkspace(user.id);
  const res = NextResponse.json(data);
  res.cookies.set(USER_COOKIE, user.id, {
    httpOnly: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
  return res;
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    name?: string;
    email?: string;
    avatar?: string | null;
    googleId?: string | null;
    preferences?: Record<string, unknown>;
  };
  const user = await getOrCreateUser();
  const patch: { name?: string; email?: string | null; avatar?: string | null; googleId?: string | null; preferences?: Record<string, unknown> } = {};
  if (body.name !== undefined && body.name.trim()) patch.name = body.name.trim();
  if (body.email !== undefined) patch.email = body.email.trim() || null;
  if (body.avatar !== undefined) patch.avatar = body.avatar || null;
  if (body.googleId !== undefined) patch.googleId = body.googleId || null;
  if (body.preferences !== undefined) {
    patch.preferences = { ...((user.preferences as Record<string, unknown> | null) ?? {}), ...body.preferences };
  }
  if (Object.keys(patch).length > 0) {
    const { db } = await import("@/db");
    const { users } = await import("@/db/schema");
    const { eq } = await import("drizzle-orm");
    const [updated] = await db.update(users).set(patch).where(eq(users.id, user.id)).returning();
    const data = await loadWorkspace(updated.id);
    const res = NextResponse.json(data);
    res.cookies.set(USER_COOKIE, updated.id, { path: "/", maxAge: 60 * 60 * 24 * 365 });
    return res;
  }
  return GET();
}

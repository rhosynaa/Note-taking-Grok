import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { tasks } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  return NextResponse.json(await db.select().from(tasks).where(eq(tasks.userId, user.id)));
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    id?: string;
    title?: string;
    completed?: boolean;
    dueDate?: string | null;
    subjectId?: string | null;
    noteId?: string | null;
    priority?: string;
    _delete?: boolean;
  };
  if (body.id && body._delete) {
    await db.delete(tasks).where(and(eq(tasks.id, body.id), eq(tasks.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const patch: Record<string, unknown> = {};
    if (body.title !== undefined) patch.title = body.title;
    if (body.completed !== undefined) patch.completed = body.completed;
    if (body.dueDate !== undefined) patch.dueDate = body.dueDate ? new Date(body.dueDate) : null;
    if (body.subjectId !== undefined) patch.subjectId = body.subjectId;
    if (body.noteId !== undefined) patch.noteId = body.noteId;
    if (body.priority !== undefined) patch.priority = body.priority;
    const [row] = await db
      .update(tasks)
      .set(patch)
      .where(and(eq(tasks.id, body.id), eq(tasks.userId, user.id)))
      .returning();
    return NextResponse.json(row);
  }
  const [row] = await db
    .insert(tasks)
    .values({
      userId: user.id,
      title: body.title || "New task",
      completed: body.completed ?? false,
      dueDate: body.dueDate ? new Date(body.dueDate) : null,
      subjectId: body.subjectId ?? null,
      noteId: body.noteId ?? null,
      priority: body.priority || "normal",
    })
    .returning();
  return NextResponse.json(row);
}

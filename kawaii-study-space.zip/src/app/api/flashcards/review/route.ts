import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { flashcardReviews, notes } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    noteId?: string;
    result?: "pass" | "fail";
    difficulty?: "easy" | "good" | "hard";
  };
  if (!body.noteId) {
    return NextResponse.json({ error: "noteId is required" }, { status: 400 });
  }
  const result = body.result === "fail" ? "fail" : "pass";
  const difficulty =
    body.difficulty === "easy" || body.difficulty === "hard" ? body.difficulty : "good";

  const [review] = await db
    .insert(flashcardReviews)
    .values({ userId: user.id, noteId: body.noteId, result, difficulty })
    .returning();

  // Keep the note's current difficulty in sync for the "needs review" list.
  await db
    .update(notes)
    .set({ difficulty, updatedAt: new Date() })
    .where(and(eq(notes.id, body.noteId), eq(notes.userId, user.id)));

  return NextResponse.json({
    id: review.id,
    noteId: review.noteId,
    result: review.result,
    difficulty: review.difficulty,
    createdAt: review.createdAt?.toISOString?.() ?? String(review.createdAt),
  });
}

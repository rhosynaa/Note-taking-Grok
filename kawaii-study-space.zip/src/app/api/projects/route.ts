import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  return NextResponse.json(await db.select().from(projects).where(eq(projects.userId, user.id)));
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    id?: string;
    name?: string;
    description?: string;
    subjectId?: string | null;
    targetMinutes?: number;
    _delete?: boolean;
  };
  if (body.id && body._delete) {
    await db.delete(projects).where(and(eq(projects.id, body.id), eq(projects.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const [row] = await db
      .update(projects)
      .set({
        name: body.name,
        description: body.description,
        subjectId: body.subjectId,
        targetMinutes: body.targetMinutes,
      })
      .where(and(eq(projects.id, body.id), eq(projects.userId, user.id)))
      .returning();
    return NextResponse.json(row);
  }
  const [row] = await db
    .insert(projects)
    .values({
      userId: user.id,
      name: body.name || "New project",
      description: body.description || "",
      subjectId: body.subjectId ?? null,
      targetMinutes: body.targetMinutes ?? 600,
    })
    .returning();
  return NextResponse.json(row);
}

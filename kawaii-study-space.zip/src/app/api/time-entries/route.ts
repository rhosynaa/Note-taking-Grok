import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { timeEntries } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";
import { refreshProgress } from "@/lib/data";
import { todayKey } from "@/lib/timer";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db
    .select()
    .from(timeEntries)
    .where(eq(timeEntries.userId, user.id))
    .orderBy(desc(timeEntries.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    id?: string;
    subjectId?: string | null;
    projectId?: string | null;
    noteId?: string | null;
    date?: string;
    durationSeconds?: number;
    note?: string;
    _delete?: boolean;
  };
  if (body.id && body._delete) {
    await db.delete(timeEntries).where(and(eq(timeEntries.id, body.id), eq(timeEntries.userId, user.id)));
    await refreshProgress(user.id);
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const [row] = await db
      .update(timeEntries)
      .set({
        subjectId: body.subjectId,
        projectId: body.projectId,
        noteId: body.noteId,
        date: body.date,
        durationSeconds: body.durationSeconds,
        note: body.note,
        updatedAt: new Date(),
      })
      .where(and(eq(timeEntries.id, body.id), eq(timeEntries.userId, user.id)))
      .returning();
    await refreshProgress(user.id);
    return NextResponse.json(row);
  }
  const [row] = await db
    .insert(timeEntries)
    .values({
      userId: user.id,
      subjectId: body.subjectId ?? null,
      projectId: body.projectId ?? null,
      noteId: body.noteId ?? null,
      date: body.date || todayKey(),
      durationSeconds: body.durationSeconds ?? 0,
      note: body.note || "",
    })
    .returning();
  await refreshProgress(user.id);
  return NextResponse.json(row);
}

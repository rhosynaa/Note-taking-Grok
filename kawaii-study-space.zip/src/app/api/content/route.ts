import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { contentItems } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db.select().from(contentItems).where(eq(contentItems.userId, user.id));
  return NextResponse.json({
    quotes: rows.filter((r) => r.kind === "quote").map((r) => ({ id: r.id, text: r.text, author: r.author })),
    motivations: rows.filter((r) => r.kind === "motivation").map((r) => ({ id: r.id, text: r.text })),
  });
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    id?: string;
    kind?: string;
    text?: string;
    author?: string | null;
    _delete?: boolean;
  };
  if (body.id && body._delete) {
    await db.delete(contentItems).where(and(eq(contentItems.id, body.id), eq(contentItems.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const patch: Record<string, unknown> = {};
    if (body.text !== undefined) patch.text = body.text;
    if (body.author !== undefined) patch.author = body.author;
    if (body.kind !== undefined) patch.kind = body.kind;
    const [row] = await db
      .update(contentItems)
      .set(patch)
      .where(and(eq(contentItems.id, body.id), eq(contentItems.userId, user.id)))
      .returning();
    return NextResponse.json(row);
  }
  if (!body.text?.trim()) {
    return NextResponse.json({ error: "Text is required" }, { status: 400 });
  }
  const [row] = await db
    .insert(contentItems)
    .values({
      userId: user.id,
      kind: body.kind === "motivation" ? "motivation" : "quote",
      text: body.text.trim(),
      author: body.author?.trim() || null,
    })
    .returning();
  return NextResponse.json(row);
}

import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { subjects } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db.select().from(subjects).where(eq(subjects.userId, user.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    name?: string;
    color?: string;
    icon?: string;
    targetMinutes?: number;
    id?: string;
    _delete?: boolean;
  };
  if (body.id && body._delete) {
    await db.delete(subjects).where(and(eq(subjects.id, body.id), eq(subjects.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const [row] = await db
      .update(subjects)
      .set({
        name: body.name,
        color: body.color,
        icon: body.icon,
        targetMinutes: body.targetMinutes,
      })
      .where(and(eq(subjects.id, body.id), eq(subjects.userId, user.id)))
      .returning();
    return NextResponse.json(row);
  }
  const [row] = await db
    .insert(subjects)
    .values({
      userId: user.id,
      name: body.name || "New subject",
      color: body.color || "#f9a8d4",
      icon: body.icon || "📚",
      targetMinutes: body.targetMinutes ?? 1200,
    })
    .returning();
  return NextResponse.json(row);
}

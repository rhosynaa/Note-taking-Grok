import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { audioTracks, playlists } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const lists = await db.select().from(playlists).where(eq(playlists.userId, user.id));
  const tracks = await db.select().from(audioTracks).where(eq(audioTracks.userId, user.id));
  return NextResponse.json({ playlists: lists, tracks });
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    entity?: "playlist" | "track";
    id?: string;
    name?: string;
    title?: string;
    artist?: string;
    source?: string;
    url?: string;
    playlistId?: string | null;
    durationSeconds?: number;
    sortOrder?: number;
    _delete?: boolean;
  };
  const entity = body.entity || "track";
  if (entity === "playlist") {
    if (body.id && body._delete) {
      await db.delete(playlists).where(and(eq(playlists.id, body.id), eq(playlists.userId, user.id)));
      return NextResponse.json({ ok: true });
    }
    if (body.id) {
      const [row] = await db
        .update(playlists)
        .set({ name: body.name })
        .where(and(eq(playlists.id, body.id), eq(playlists.userId, user.id)))
        .returning();
      return NextResponse.json(row);
    }
    const [row] = await db.insert(playlists).values({ userId: user.id, name: body.name || "Playlist" }).returning();
    return NextResponse.json(row);
  }
  if (body.id && body._delete) {
    await db.delete(audioTracks).where(and(eq(audioTracks.id, body.id), eq(audioTracks.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const [row] = await db
      .update(audioTracks)
      .set({
        title: body.title,
        artist: body.artist,
        source: body.source,
        url: body.url,
        playlistId: body.playlistId,
        durationSeconds: body.durationSeconds,
        sortOrder: body.sortOrder,
      })
      .where(and(eq(audioTracks.id, body.id), eq(audioTracks.userId, user.id)))
      .returning();
    return NextResponse.json(row);
  }
  const [row] = await db
    .insert(audioTracks)
    .values({
      userId: user.id,
      playlistId: body.playlistId ?? null,
      title: body.title || "Untitled track",
      artist: body.artist || "",
      source: body.source || "url",
      url: body.url || "",
      durationSeconds: body.durationSeconds ?? 0,
      sortOrder: body.sortOrder ?? 0,
    })
    .returning();
  return NextResponse.json(row);
}

import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { timeEntries, timerSessions } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";
import { refreshProgress } from "@/lib/data";
import { durationForType, todayKey, type SessionType } from "@/lib/timer";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db
    .select()
    .from(timerSessions)
    .where(eq(timerSessions.userId, user.id))
    .orderBy(desc(timerSessions.createdAt))
    .limit(20);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    action?: "start" | "pause" | "resume" | "reset" | "complete" | "log";
    type?: SessionType;
    subjectId?: string | null;
    projectId?: string | null;
    noteId?: string | null;
    durationSeconds?: number;
    remainingSeconds?: number;
    sessionId?: string;
  };
  const action = body.action || "start";
  const type = body.type || "pomodoro";
  const duration = body.durationSeconds ?? durationForType(type);

  if (action === "start") {
    const [row] = await db
      .insert(timerSessions)
      .values({
        userId: user.id,
        type,
        subjectId: body.subjectId ?? null,
        projectId: body.projectId ?? null,
        noteId: body.noteId ?? null,
        durationSeconds: duration,
        remainingSeconds: duration,
        startedAt: new Date(),
        status: "running",
      })
      .returning();
    return NextResponse.json(row);
  }

  if (action === "pause" && body.sessionId) {
    const [row] = await db
      .update(timerSessions)
      .set({ status: "paused", remainingSeconds: body.remainingSeconds ?? 0 })
      .where(eq(timerSessions.id, body.sessionId))
      .returning();
    return NextResponse.json(row);
  }

  if (action === "resume" && body.sessionId) {
    const [row] = await db
      .update(timerSessions)
      .set({ status: "running" })
      .where(eq(timerSessions.id, body.sessionId))
      .returning();
    return NextResponse.json(row);
  }

  if (action === "reset" && body.sessionId) {
    const [row] = await db
      .update(timerSessions)
      .set({
        status: "idle",
        remainingSeconds: duration,
        startedAt: null,
        endedAt: null,
      })
      .where(eq(timerSessions.id, body.sessionId))
      .returning();
    return NextResponse.json(row);
  }

  if ((action === "complete" || action === "log") && body.sessionId) {
    const existing = await db.select().from(timerSessions).where(eq(timerSessions.id, body.sessionId)).limit(1);
    const session = existing[0];
    if (!session) return NextResponse.json({ error: "Missing session" }, { status: 404 });
    const elapsed = Math.max(0, session.durationSeconds - (body.remainingSeconds ?? 0));
    const [row] = await db
      .update(timerSessions)
      .set({
        status: "completed",
        remainingSeconds: body.remainingSeconds ?? 0,
        endedAt: new Date(),
      })
      .where(eq(timerSessions.id, body.sessionId))
      .returning();
    if (elapsed >= 15 && session.type === "pomodoro") {
      await db.insert(timeEntries).values({
        userId: user.id,
        subjectId: session.subjectId,
        projectId: session.projectId,
        noteId: session.noteId,
        sessionId: session.id,
        date: todayKey(),
        durationSeconds: elapsed,
        note: `${session.type} session`,
      });
      await refreshProgress(user.id);
    }
    return NextResponse.json(row);
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}

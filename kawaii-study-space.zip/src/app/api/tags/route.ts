import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { noteTags, tags } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const tagRows = await db.select().from(tags).where(eq(tags.userId, user.id));
  const links = await db.select().from(noteTags);
  const counts: Record<string, number> = {};
  for (const l of links) counts[l.tagId] = (counts[l.tagId] ?? 0) + 1;
  return NextResponse.json(tagRows.map((t) => ({ ...t, count: counts[t.id] ?? 0 })));
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as { id?: string; name?: string; color?: string; _delete?: boolean };
  if (body.id && body._delete) {
    await db.delete(tags).where(and(eq(tags.id, body.id), eq(tags.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  if (body.id) {
    const [row] = await db
      .update(tags)
      .set({ name: body.name, color: body.color })
      .where(and(eq(tags.id, body.id), eq(tags.userId, user.id)))
      .returning();
    return NextResponse.json(row);
  }
  const [row] = await db
    .insert(tags)
    .values({ userId: user.id, name: body.name || "tag", color: body.color || "#f9a8d4" })
    .returning();
  return NextResponse.json(row);
}

import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { dashboardWidgets } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const DEFAULT_WIDGETS = [
  "greeting",
  "progress",
  "plan",
  "calendar",
  "recent",
  "deadlines",
  "subjects",
  "music",
  "quick",
  "streak",
  "focus",
  "motivation",
  "tags",
  "quote",
];

export async function GET() {
  const user = await getOrCreateUser();
  const rows = await db.select().from(dashboardWidgets).where(eq(dashboardWidgets.userId, user.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    restore?: boolean;
    widgets?: { widgetKey: string; layoutOrder?: number; order?: number; visible: boolean; pinned: boolean }[];
  };
  if (body.restore) {
    await db.delete(dashboardWidgets).where(eq(dashboardWidgets.userId, user.id));
    const rows = await db
      .insert(dashboardWidgets)
      .values(
        DEFAULT_WIDGETS.map((key, i) => ({
          userId: user.id,
          widgetKey: key,
          layoutOrder: i,
          visible: true,
          pinned: key === "greeting" || key === "progress",
        })),
      )
      .returning();
    return NextResponse.json(rows);
  }
  if (body.widgets) {
    await db.delete(dashboardWidgets).where(eq(dashboardWidgets.userId, user.id));
    const rows = await db
      .insert(dashboardWidgets)
      .values(
        body.widgets.map((w) => ({
          userId: user.id,
          widgetKey: w.widgetKey,
          layoutOrder: w.layoutOrder ?? w.order ?? 0,
          visible: w.visible,
          pinned: w.pinned,
        })),
      )
      .returning();
    return NextResponse.json(rows);
  }
  return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
}

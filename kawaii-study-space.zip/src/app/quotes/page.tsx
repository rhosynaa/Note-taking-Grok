import { AppShell } from "@/components/shell";
import { QuotesView } from "@/components/quotes-view";

export const dynamic = "force-dynamic";

export default function QuotesPage() {
  return (
    <AppShell>
      <QuotesView />
    </AppShell>
  );
}

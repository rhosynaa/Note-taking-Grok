import { AppShell } from "@/components/shell";
import { TasksView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function TasksPage() {
  return (
    <AppShell>
      <TasksView />
    </AppShell>
  );
}

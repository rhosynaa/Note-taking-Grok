import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Caveat, Fredoka, Nunito, Pacifico, Patrick_Hand } from "next/font/google";
import "./globals.css";
import { AppProviders } from "@/components/provider";

const nunito = Nunito({
  subsets: ["latin"],
  variable: "--font-nunito",
});
const fredoka = Fredoka({
  subsets: ["latin"],
  variable: "--font-fredoka",
});
const caveat = Caveat({
  subsets: ["latin"],
  variable: "--font-caveat",
});
const patrick = Patrick_Hand({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-patrick",
});
const pacifico = Pacifico({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-pacifico",
});

export const metadata: Metadata = {
  title: "Kawaii Study Space",
  description: "A pastel study workspace for notes, timers, music, and cozy productivity.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

/* Applies saved dark-mode / desktop-mode prefs before first paint (no flash).
   Desktop mode only applies below 768px and never rewrites the viewport —
   it's a pure CSS 2-column grid, so no zoom-out or horizontal scrolling. */
const BOOT_SCRIPT = `(function(){try{var raw=localStorage.getItem("kawaii-ui");if(!raw)return;var s=JSON.parse(raw);var root=document.documentElement;if(s.dark)root.classList.add("dark");if(s.desktop&&window.matchMedia("(max-width: 767.98px)").matches)root.classList.add("desktop-mode");}catch(e){}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${nunito.variable} ${fredoka.variable} ${caveat.variable} ${patrick.variable} ${pacifico.variable} antialiased`}
      >
        <script dangerouslySetInnerHTML={{ __html: BOOT_SCRIPT }} />
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}

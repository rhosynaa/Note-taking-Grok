import { AppShell } from "@/components/shell";
import { MusicView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function MusicPage() {
  return (
    <AppShell>
      <MusicView />
    </AppShell>
  );
}

import { AppShell } from "@/components/shell";
import { TimerView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function TimerPage() {
  return (
    <AppShell>
      <TimerView />
    </AppShell>
  );
}

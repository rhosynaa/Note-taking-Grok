import { AppShell } from "@/components/shell";
import { CalendarView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function CalendarPage() {
  return (
    <AppShell>
      <CalendarView />
    </AppShell>
  );
}

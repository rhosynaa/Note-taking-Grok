import { AppShell } from "@/components/shell";
import { ResourcesView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function ResourcesPage() {
  return (
    <AppShell>
      <ResourcesView />
    </AppShell>
  );
}

import { NoteEditor } from "@/components/editor";
import { AppShell } from "@/components/shell";

export const dynamic = "force-dynamic";

export default async function NotePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <AppShell>
      <NoteEditor noteId={id} />
    </AppShell>
  );
}

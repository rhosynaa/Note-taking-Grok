import { Suspense } from "react";
import { NotesBoard } from "@/components/notes-board";
import { AppShell } from "@/components/shell";

export const dynamic = "force-dynamic";

export default function NotesPage() {
  return (
    <AppShell>
      <Suspense fallback={<p className="empty-state">Opening your pastel binders…</p>}>
        <NotesBoard />
      </Suspense>
    </AppShell>
  );
}

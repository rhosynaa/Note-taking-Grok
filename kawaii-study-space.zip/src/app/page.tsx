import { DashboardView } from "@/components/dashboard";
import { AppShell } from "@/components/shell";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <AppShell>
      <DashboardView />
    </AppShell>
  );
}

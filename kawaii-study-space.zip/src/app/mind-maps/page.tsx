import { AppShell } from "@/components/shell";
import { MindMapsView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function MindMapsPage() {
  return (
    <AppShell>
      <MindMapsView />
    </AppShell>
  );
}

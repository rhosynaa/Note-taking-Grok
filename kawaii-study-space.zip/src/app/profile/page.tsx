import { AppShell } from "@/components/shell";
import { ProfileView } from "@/components/profile-view";

export const dynamic = "force-dynamic";

export default function ProfilePage() {
  return (
    <AppShell>
      <ProfileView />
    </AppShell>
  );
}

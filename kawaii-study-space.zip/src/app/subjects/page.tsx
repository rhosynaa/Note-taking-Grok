import { AppShell } from "@/components/shell";
import { SubjectsView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function SubjectsPage() {
  return (
    <AppShell>
      <SubjectsView />
    </AppShell>
  );
}

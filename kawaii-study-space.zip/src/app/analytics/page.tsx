import { AppShell } from "@/components/shell";
import { AnalyticsView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function AnalyticsPage() {
  return (
    <AppShell>
      <AnalyticsView />
    </AppShell>
  );
}

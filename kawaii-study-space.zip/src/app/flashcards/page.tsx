import { AppShell } from "@/components/shell";
import { FlashcardsView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function FlashcardsPage() {
  return (
    <AppShell>
      <FlashcardsView />
    </AppShell>
  );
}

import Link from "next/link";
import { AppShell } from "@/components/shell";

export const dynamic = "force-dynamic";

function Guide({ id, icon, title, children }: { id: string; icon: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="card scroll-mt-4">
      <h2 className="font-[var(--font-fredoka)] text-xl text-fuchsia-700">
        {icon} {title}
      </h2>
      <div className="mt-2 flex flex-col gap-2 text-sm text-pink-900">{children}</div>
    </section>
  );
}

function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <p>
      <span className="mr-2 inline-grid h-6 w-6 place-items-center rounded-full bg-pink-400 text-xs font-extrabold text-white">{n}</span>
      {children}
    </p>
  );
}

export default function HelpPage() {
  return (
    <AppShell>
      <div className="flex flex-col gap-4">
        <div>
          <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Help & guides ❔</h1>
          <p className="text-sm text-pink-500">Everything you need to master your Kawaii Study Space.</p>
        </div>

        <nav className="card flex flex-wrap gap-2">
          {[
            ["#templates", "🎀 Add templates"],
            ["#google", "🔐 Google login"],
            ["#tasks", "✅ Tasks & deadlines"],
            ["#flashcards", "🃏 Flashcards"],
            ["#quotes", "💬 Quotes"],
            ["#profile", "🌸 Profile & sync"],
            ["#editor", "🖌️ Editor & images"],
          ].map(([href, label]) => (
            <a key={href} href={href} className="ghost-btn">
              {label}
            </a>
          ))}
        </nav>

        <Guide id="templates" icon="🎀" title="Adding new templates">
          <p>
            Found a layout you love elsewhere, or dreamed one up yourself? There are <b>two ways</b> to add your own
            templates — both live on the <Link href="/templates" className="font-bold text-fuchsia-600 underline">Templates page</Link>.
          </p>
          <p className="font-bold text-fuchsia-700">Option A — Build a blank template from scratch</p>
          <Step n={1}>Open <b>Templates → Create your own template</b> at the top of the page.</Step>
          <Step n={2}>Give it a <b>name</b> and <b>category</b> (note, mind map, planner, journal…).</Step>
          <Step n={3}>Pick a <b>paper style</b>, <b>background color</b>, and the <b>font</b> your starter text should use.</Step>
          <Step n={4}>
            Choose a <b>cover</b>: tap a default kawaii cover, <b>upload</b> your own picture, or <b>paste an image URL</b>.
          </Step>
          <Step n={5}>
            Press <b>Create template</b>. It appears under <b>“Yours”</b> — press <b>Duplicate</b> to open it as a note and
            decorate it with elements, stickers, shapes, and more fonts in the editor.
          </Step>
          <p className="font-bold text-fuchsia-700">Option B — Save any note as a template</p>
          <Step n={1}>Recreate the layout you like inside any note (fonts, colors, stickers, images — everything).</Step>
          <Step n={2}>In the note editor, press <b>Save template</b> in the top bar.</Step>
          <Step n={3}>It lands in <b>Templates → Yours</b> with your note&apos;s cover as its thumbnail.</Step>
          <p>
            <b>Managing your templates:</b> press <b>Edit</b> on any of your templates to rename it, change its category
            or thumbnail. Use <b>“Update design from note”</b> to refresh its layout from any note you pick, or{" "}
            <b>Delete</b> to remove it.
          </p>
        </Guide>

        <Guide id="google" icon="🔐" title="Logging in with your Google account">
          <Step n={1}>
            Click your <b>name in the top header</b> (or the ▾ menu → <b>Open profile settings</b>) to open the{" "}
            <Link href="/profile" className="font-bold text-fuchsia-600 underline">Profile page</Link>.
          </Step>
          <Step n={2}>Find the <b>Google integration</b> card and press <b>Log in with Google</b>.</Step>
          <Step n={3}>Enter the <b>Google email</b> and <b>display name</b> you want this workspace linked to, then press <b>Connect Google account</b>.</Step>
          <Step n={4}>
            Your header, greeting, and profile now use your Google identity. Press <b>Disconnect</b> any time to unlink.
          </Step>
          <p className="rounded-xl bg-pink-50 p-2 text-xs text-pink-600">
            Your Google details are stored only in your own study database on this device — nothing is sent anywhere else.
          </p>
        </Guide>

        <Guide id="tasks" icon="✅" title="Tasks, priorities & calendar deadlines">
          <Step n={1}>
            Go to <Link href="/tasks" className="font-bold text-fuchsia-600 underline">Tasks</Link>. At the top, type the{" "}
            <b>task name</b>, pick a <b>priority</b> (low / medium / high), a <b>due date</b>, and a <b>subject</b>, then press{" "}
            <b>Add task</b>.
          </Step>
          <Step n={2}>
            Filter the list with <b>All / Pending / Completed</b> plus the <b>subject dropdown</b> to focus on one class.
          </Step>
          <Step n={3}>
            Deadlines appear automatically on the{" "}
            <Link href="/calendar" className="font-bold text-fuchsia-600 underline">Calendar</Link> and in the dashboard&apos;s{" "}
            <b>Today&apos;s Plan</b> and <b>Upcoming Deadlines</b>. The <b>🔔 bell</b> in the header always shows what&apos;s due in the next 7 days.
          </Step>
          <Step n={4}>
            On the calendar, <b>click any day</b> to add a deadline straight onto that date, or press the <b>×</b> on a
            deadline chip to delete it. Use <b>Open all tasks →</b> to jump back to the full task list.
          </Step>
        </Guide>

        <Guide id="flashcards" icon="🃏" title="Flashcard decks & study mode">
          <Step n={1}>
            Open <Link href="/flashcards" className="font-bold text-fuchsia-600 underline">Flashcards</Link> — every{" "}
            <b>subject is a deck</b>, showing its icon, name, and card count.
          </Step>
          <Step n={2}>Click a deck to enter <b>study mode</b>: one question at a time, with Previous / Next navigation.</Step>
          <Step n={3}>Press <b>Show Answer</b> to flip the card with a smooth animation, then <b>Hide Answer</b> to flip back.</Step>
          <Step n={4}>
            Press <b>Manage</b> at the top of study mode to <b>add</b>, <b>edit</b>, or <b>delete</b> cards in that deck.
          </Step>
        </Guide>

        <Guide id="quotes" icon="💬" title="Quotes of the day & daily motivation">
          <Step n={1}>
            Open <Link href="/quotes" className="font-bold text-fuchsia-600 underline">Quotes</Link> in the sidebar to see every
            stored <b>quote of the day</b> and <b>daily motivation</b>.
          </Step>
          <Step n={2}>Use the <b>tabs</b> to switch between quotes and motivations, then <b>add</b>, <b>edit</b>, or <b>delete</b> entries.</Step>
          <Step n={3}>
            Each day the dashboard picks a <b>new random quote and motivation</b> from your collection automatically.
          </Step>
        </Guide>

        <Guide id="profile" icon="🌸" title="Profile, avatar & auto-sync">
          <Step n={1}>
            Click your <b>name in the header</b> to open{" "}
            <Link href="/profile" className="font-bold text-fuchsia-600 underline">Profile settings</Link>.
          </Step>
          <Step n={2}>Change your <b>username</b> and <b>email</b>, and <b>upload a new avatar</b> (or paste an image link).</Step>
          <Step n={3}>
            Keep <b>Auto-sync</b> switched on and your workspace refreshes from the database every 30 seconds on its own.
          </Step>
          <Step n={4}>Tune your <b>pomodoro lengths</b> and restyle the dashboard&apos;s <b>hero art, side art, and music art</b>.</Step>
        </Guide>

        <Guide id="editor" icon="🖌️" title="Editor toolbar & changing images">
          <p>
            In any <b>note or mind map</b>, press <b>Hide tools / Show tools</b> in the top bar to collapse or expand the{" "}
            <b>elements · stickers · shapes · covers</b> panel and reclaim canvas space.
          </p>
          <p>
            <b>Every image can be changed:</b> note covers (Cover button), pictures inside your canvas (select the image →
            use the image panel to paste a link, upload, or pick from your uploads), your avatar, and all dashboard art
            (Profile → Appearance).
          </p>
        </Guide>
      </div>
    </AppShell>
  );
}

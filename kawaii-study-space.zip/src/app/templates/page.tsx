import { AppShell } from "@/components/shell";
import { TemplatesView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function TemplatesPage() {
  return (
    <AppShell>
      <TemplatesView />
    </AppShell>
  );
}

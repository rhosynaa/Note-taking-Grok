import { AppShell } from "@/components/shell";
import { TrashView } from "@/components/views";

export const dynamic = "force-dynamic";

export default function TrashPage() {
  return (
    <AppShell>
      <TrashView />
    </AppShell>
  );
}

"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { api, trackEmbed, useKawaii } from "./provider";

const NAV = [
  { href: "/", label: "Dashboard", icon: "🏠" },
  { href: "/notes", label: "Notes", icon: "📓" },
  { href: "/templates", label: "Templates", icon: "🎀" },
  { href: "/subjects", label: "Subjects", icon: "📚" },
  { href: "/quotes", label: "Quotes", icon: "💬" },
  { href: "/calendar", label: "Calendar", icon: "🗓️" },
  { href: "/tasks", label: "Tasks", icon: "✅" },
  { href: "/flashcards", label: "Flashcards", icon: "🃏" },
  { href: "/mind-maps", label: "Mind Maps", icon: "🗺️" },
  { href: "/timer", label: "Timer", icon: "⏱️" },
  { href: "/analytics", label: "Analytics", icon: "📊" },
  { href: "/music", label: "Music", icon: "🎵" },
  { href: "/resources", label: "Resources", icon: "🗂️" },
  { href: "/trash", label: "Trash", icon: "🗑️" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const {
    data,
    reload,
    focusMode,
    sidebarOpen,
    setSidebarOpen,
    search,
    setSearch,
    searchResults,
    timer,
    startTimer,
    pauseTimer,
    setTimerType,
    music,
    togglePlay,
  } = useKawaii();
  const pathname = usePathname();
  const router = useRouter();
  const tracks = music.tracks ?? data?.tracks ?? [];
  const current = tracks[music.index];
  const embed = music.playing ? trackEmbed(current) : null;
  const [profileOpen, setProfileOpen] = useState(false);
  const [deadlinesOpen, setDeadlinesOpen] = useState(false);

  useEffect(() => {
    setSidebarOpen(false);
  }, [pathname, setSidebarOpen]);

  useEffect(() => {
    setDeadlinesOpen(false);
    setProfileOpen(false);
  }, [pathname]);

  const upcomingDeadlines = useMemo(() => {
    const now = Date.now();
    const week = now + 7 * 86400000;
    return (data?.tasks ?? [])
      .filter((t) => {
        if (t.completed || !t.dueDate) return false;
        const d = new Date(t.dueDate).getTime();
        return d >= now - 86400000 && d <= week;
      })
      .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
      .slice(0, 8);
  }, [data?.tasks]);

  const deadlineCount = upcomingDeadlines.length;

  return (
    <div className={`kawaii-app ${focusMode ? "focus-mode" : ""}`}>
      <div className="kawaii-window">
        <header className="kawaii-titlebar">
          <button className="icon-btn md:hidden" onClick={() => setSidebarOpen(!sidebarOpen)} aria-label="Menu">
            ☰
          </button>
          <div className="brand-mark">
            <span className="sparkle">🌙</span>
            <span className="full">KAWAII STUDY SPACE</span>
          </div>
          <label className="search-pill">
            <span>🔍</span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search notes, topics, tags…"
              aria-label="Search notes, topics, tags"
            />
          </label>
          <Link href="/calendar" className="icon-btn" title="Calendar">
            📅
          </Link>
          <button
            className="icon-btn relative"
            title={deadlineCount > 0 ? `${deadlineCount} upcoming deadlines` : "No upcoming deadlines"}
            aria-label="Upcoming deadlines"
            onClick={() => {
              setDeadlinesOpen((v) => !v);
              setProfileOpen(false);
            }}
          >
            🔔
            {deadlineCount > 0 && (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-extrabold text-white">
                {deadlineCount}
              </span>
            )}
          </button>
          <button className="icon-btn" title="Help & guides" onClick={() => router.push("/help")}>
            ❔
          </button>
          <div className="flex items-center gap-1 rounded-full border-2 border-pink-200 bg-white py-1 pl-1 pr-2">
            <Link href="/profile" className="flex items-center gap-2 rounded-full px-1" title="Open profile settings">
              <img src={data?.user.avatar || "/art/avatar-student.jpg"} alt="" className="h-7 w-7 rounded-full object-cover" />
              <span className="hidden text-sm font-bold text-fuchsia-800 hover:underline sm:inline">{data?.user.name ?? "Dreamy Student"}</span>
            </Link>
            <button
              className="rounded-full px-1 text-xs text-fuchsia-500 hover:bg-pink-100"
              aria-label="Account quick menu"
              onClick={() => {
                setProfileOpen((v) => !v);
                setDeadlinesOpen(false);
              }}
            >
              ▾
            </button>
          </div>
        </header>

        {searchResults && (
          <div className="border-b-2 border-pink-200 bg-white/90 px-4 py-3">
            <p className="card-title mb-2">Search results</p>
            <div className="flex flex-wrap gap-2">
              {searchResults.notes.map((n) => (
                <Link key={n.id} href={`/notes/${n.id}`} className="kawaii-chip bg-pink-100 text-pink-700">
                  📓 {n.title}
                </Link>
              ))}
              {searchResults.tasks.map((t) => (
                <Link key={t.id} href="/tasks" className="kawaii-chip bg-violet-100 text-violet-700">
                  ✅ {t.title}
                </Link>
              ))}
              {searchResults.tags.map((t) => (
                <Link key={t.id} href={`/notes?tag=${t.id}`} className="kawaii-chip" style={{ background: t.color }}>
                  #{t.name}
                </Link>
              ))}
              {searchResults.notes.length + searchResults.tasks.length + searchResults.tags.length === 0 && (
                <span className="text-sm text-pink-400">No matches yet — try another sparkly word.</span>
              )}
            </div>
          </div>
        )}

        <div className="kawaii-body">
          <aside className={`kawaii-sidebar ${sidebarOpen ? "open" : ""}`}>
            <div className="hub-label">STUDY HUB</div>
            <nav className="flex flex-col gap-0.5">
              {NAV.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`nav-link ${pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href)) ? "active" : ""}`}
                >
                  <span>{item.icon}</span>
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto card music-dock !bg-fuchsia-50">
              <div className="mb-2 flex gap-2 text-[11px] font-extrabold tracking-wide text-fuchsia-500">
                <button className={timer.type === "pomodoro" ? "text-fuchsia-700" : ""} onClick={() => setTimerType("pomodoro")}>
                  Pomodoro
                </button>
                <button className={timer.type === "short_break" ? "text-fuchsia-700" : ""} onClick={() => setTimerType("short_break")}>
                  Short Break
                </button>
              </div>
              <p className="text-center font-[var(--font-fredoka)] text-4xl font-bold text-fuchsia-700">{timer.label}</p>
              <div className="mt-2 flex justify-center">
                <button
                  className="pink-btn !rounded-full !px-5"
                  onClick={() => (timer.running ? pauseTimer() : startTimer())}
                  aria-label={timer.running ? "Pause timer" : "Start timer"}
                >
                  {timer.running ? "Pause" : "▶"}
                </button>
              </div>
            </div>
          </aside>
          <main className="kawaii-main">{children}</main>
        </div>

        {embed && (
          <div className="hidden">
            <iframe title="music" src={embed} allow="autoplay; encrypted-media" />
          </div>
        )}
        {current && current.source !== "youtube" && !current.url.includes("youtu") && music.playing && (
          <audio src={current.url} autoPlay muted={music.muted} />
        )}

        {deadlinesOpen && (
          <div className="fixed right-6 top-16 z-50 w-80 rounded-2xl border-2 border-pink-200 bg-white p-4 shadow-xl">
            <div className="mb-2 flex items-center justify-between">
              <p className="card-title">Upcoming deadlines</p>
              <button className="text-xs font-bold text-pink-400" onClick={() => setDeadlinesOpen(false)}>
                ✕
              </button>
            </div>
            {upcomingDeadlines.length === 0 && (
              <p className="empty-state">No deadlines in the next 7 days — enjoy the calm ☁️</p>
            )}
            <div className="flex max-h-72 flex-col gap-2 overflow-auto">
              {upcomingDeadlines.map((t) => {
                const due = new Date(t.dueDate!);
                const days = Math.ceil((due.getTime() - Date.now()) / 86400000);
                const sub = (data?.subjects ?? []).find((s) => s.id === t.subjectId);
                return (
                  <div key={t.id} className="flex items-center gap-2 rounded-xl bg-pink-50 px-2 py-2">
                    <input
                      type="checkbox"
                      checked={t.completed}
                      title="Mark complete"
                      onChange={async () => {
                        await api("/api/tasks", { method: "POST", body: JSON.stringify({ id: t.id, completed: !t.completed }) });
                        await reload();
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-fuchsia-900">{t.title}</p>
                      <p className="text-[11px] text-pink-500">
                        {days <= 0 ? "due today" : `${days}d left`} · {due.toLocaleDateString()}
                        {sub ? ` · ${sub.icon} ${sub.name}` : ""}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-3 flex gap-2">
              <Link href="/calendar" className="ghost-btn flex-1 text-center" onClick={() => setDeadlinesOpen(false)}>
                Open calendar
              </Link>
              <Link href="/tasks" className="ghost-btn flex-1 text-center" onClick={() => setDeadlinesOpen(false)}>
                Open tasks
              </Link>
            </div>
          </div>
        )}

        {profileOpen && (
          <div className="fixed right-6 top-16 z-50 w-64 rounded-2xl border-2 border-pink-200 bg-white p-4 shadow-xl">
            <p className="font-bold text-fuchsia-800">{data?.user.name}</p>
            <p className="text-xs text-pink-400">{data?.user.email}</p>
            <p className="mt-2 text-sm text-pink-700">Workspace syncs through your study cloud (this device + database).</p>
            <Link href="/profile" className="pink-btn mt-3 block w-full text-center !shadow-none" onClick={() => setProfileOpen(false)}>
              Open profile settings
            </Link>
            <button className="ghost-btn mt-2 w-full" onClick={() => setProfileOpen(false)}>
              Close
            </button>
          </div>
        )}

        <button
          className="fixed bottom-4 right-4 z-30 rounded-full bg-white/90 px-3 py-2 text-xs font-bold text-fuchsia-600 shadow md:hidden"
          onClick={togglePlay}
        >
          {music.playing ? "⏸ music" : "▶ music"} · {current?.title ?? "playlist"}
        </button>
      </div>
    </div>
  );
}

import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { notes, templates } from "@/db/schema";
import { getOrCreateUser } from "@/lib/session";
import { TEMPLATES, buildTemplateName } from "@/lib/templates";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  const custom = await db.select().from(templates).where(eq(templates.userId, user.id));
  return NextResponse.json({
    system: TEMPLATES.map((t) => ({
      id: t.id,
      name: t.name,
      category: t.category,
      description: t.description,
      cover: t.cover,
      paper: t.paper,
    })),
    custom,
  });
}

export async function POST(req: Request) {
  const user = await getOrCreateUser();
  const body = (await req.json()) as {
    name?: string;
    category?: string;
    thumbnail?: string;
    data?: Record<string, unknown>;
    fromNoteId?: string;
    id?: string;
    _delete?: boolean;
  };
  if (body.id && body._delete) {
    await db.delete(templates).where(and(eq(templates.id, body.id), eq(templates.userId, user.id)));
    return NextResponse.json({ ok: true });
  }
  let data = body.data ?? {};
  let thumbnail = body.thumbnail;
  if (body.fromNoteId) {
    const rows = await db.select().from(notes).where(eq(notes.id, body.fromNoteId)).limit(1);
    const n = rows[0];
    if (n) {
      data = {
        elements: n.content,
        background: n.background,
        width: n.canvasWidth,
        height: n.canvasHeight,
      };
      thumbnail = n.coverImage ?? thumbnail;
    }
  }
  const [row] = await db
    .insert(templates)
    .values({
      userId: user.id,
      name: buildTemplateName(body.name || "My template"),
      category: body.category || "custom",
      thumbnail: thumbnail ?? null,
      data,
    })
    .returning();
  return NextResponse.json(row);
}

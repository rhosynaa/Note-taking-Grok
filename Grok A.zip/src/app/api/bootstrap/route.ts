import { NextResponse } from "next/server";
import { USER_COOKIE, getOrCreateUser } from "@/lib/session";
import { loadWorkspace, seedWorkspace } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getOrCreateUser();
  await seedWorkspace(user.id);
  const data = await loadWorkspace(user.id);
  const res = NextResponse.json(data);
  res.cookies.set(USER_COOKIE, user.id, {
    httpOnly: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
  return res;
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { name?: string; email?: string };
  const user = await getOrCreateUser();
  if (body.name || body.email) {
    const { db } = await import("@/db");
    const { users } = await import("@/db/schema");
    const { eq } = await import("drizzle-orm");
    const [updated] = await db
      .update(users)
      .set({
        name: body.name || user.name,
        email: body.email || user.email,
      })
      .where(eq(users.id, user.id))
      .returning();
    const data = await loadWorkspace(updated.id);
    const res = NextResponse.json(data);
    res.cookies.set(USER_COOKIE, updated.id, { path: "/", maxAge: 60 * 60 * 24 * 365 });
    return res;
  }
  return GET();
}

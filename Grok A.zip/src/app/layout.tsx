import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Caveat, Fredoka, Nunito, Pacifico, Patrick_Hand } from "next/font/google";
import "./globals.css";
import { AppProviders } from "@/components/provider";

const nunito = Nunito({
  subsets: ["latin"],
  variable: "--font-nunito",
});
const fredoka = Fredoka({
  subsets: ["latin"],
  variable: "--font-fredoka",
});
const caveat = Caveat({
  subsets: ["latin"],
  variable: "--font-caveat",
});
const patrick = Patrick_Hand({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-patrick",
});
const pacifico = Pacifico({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-pacifico",
});

export const metadata: Metadata = {
  title: "Kawaii Study Space",
  description: "A pastel study workspace for notes, timers, music, and cozy productivity.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body
        className={`${nunito.variable} ${fredoka.variable} ${caveat.variable} ${patrick.variable} ${pacifico.variable} antialiased`}
      >
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}

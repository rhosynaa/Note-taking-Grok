"use client";

import Link from "next/link";
import { useState } from "react";
import { TEMPLATES } from "@/lib/templates";
import { formatHours, formatTime, hoursLabel } from "@/lib/timer";
import { api, trackEmbed, useKawaii } from "./provider";
import { DEFAULT_COVERS } from "@/lib/types";

export function TemplatesView() {
  const { data, reload } = useKawaii();
  async function createFrom(id: string, kind = "note") {
    const row = await api<{ id: string }>("/api/notes", {
      method: "POST",
      body: JSON.stringify({ templateId: id, kind }),
    });
    window.location.href = `/notes/${row.id}`;
  }
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Individual Templates</h1>
      <p className="mb-4 text-sm text-pink-500">Each reference kept its own layout, type, and color story — nothing was mashed into one generic page.</p>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {TEMPLATES.map((t) => (
          <article key={t.id} className="cover-card">
            <img src={t.cover} alt="" />
            <div className="p-3">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-pink-400">{t.category}</p>
              <h2 className="font-bold text-fuchsia-900">{t.name}</h2>
              <p className="mt-1 text-xs text-pink-500">{t.description}</p>
              <button className="pink-btn mt-3 !shadow-none" onClick={() => createFrom(t.id, t.category === "Mind Map" ? "mindmap" : "note")}>
                Use template
              </button>
            </div>
          </article>
        ))}
        {(data?.customTemplates ?? []).map((t) => (
          <article key={t.id} className="cover-card">
            <img src={t.thumbnail || DEFAULT_COVERS[0]} alt="" />
            <div className="p-3">
              <p className="text-[11px] font-extrabold uppercase text-pink-400">Yours</p>
              <h2 className="font-bold">{t.name}</h2>
              <button
                className="pink-btn mt-3 !shadow-none"
                onClick={async () => {
                  const d = t.data as { elements?: unknown[]; background?: string; width?: number; height?: number };
                  const row = await api<{ id: string }>("/api/notes", {
                    method: "POST",
                    body: JSON.stringify({
                      title: t.name,
                      content: d.elements ?? [],
                      background: d.background,
                      canvasWidth: d.width,
                      canvasHeight: d.height,
                      coverImage: t.thumbnail,
                    }),
                  });
                  window.location.href = `/notes/${row.id}`;
                }}
              >
                Duplicate
              </button>
              <button
                className="ghost-btn mt-2"
                onClick={async () => {
                  await api("/api/templates", { method: "POST", body: JSON.stringify({ id: t.id, _delete: true }) });
                  await reload();
                }}
              >
                Delete
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export function SubjectsView() {
  const { data, reload } = useKawaii();
  const [name, setName] = useState("");
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Subjects</h1>
      <div className="mt-4 flex gap-2">
        <input className="rounded-2xl border-2 border-pink-200 px-3 py-2" placeholder="New subject" value={name} onChange={(e) => setName(e.target.value)} />
        <button
          className="pink-btn"
          onClick={async () => {
            if (!name.trim()) return;
            await api("/api/subjects", { method: "POST", body: JSON.stringify({ name }) });
            setName("");
            await reload();
          }}
        >
          Add
        </button>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {(data?.analytics.subjects ?? []).map((s) => (
          <article key={s.id} className="card">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold">
                {s.icon} {s.name}
              </h2>
              <button
                className="ghost-btn"
                onClick={async () => {
                  await api("/api/subjects", { method: "POST", body: JSON.stringify({ id: s.id, _delete: true }) });
                  await reload();
                }}
              >
                Remove
              </button>
            </div>
            <p className="text-sm text-pink-500">{hoursLabel(s.minutes, s.targetMinutes)}</p>
            <div className="progress-track mt-2">
              <div className="progress-fill" style={{ width: `${s.pct}%`, background: s.color }} />
            </div>
            <label className="mt-2 block text-xs">
              Target minutes
              <input
                type="number"
                className="ml-2 w-24 rounded-lg border border-pink-200 px-2"
                defaultValue={s.targetMinutes}
                onBlur={async (e) => {
                  await api("/api/subjects", {
                    method: "POST",
                    body: JSON.stringify({ id: s.id, targetMinutes: Number(e.target.value) }),
                  });
                  await reload();
                }}
              />
            </label>
            <ProjectsFor subjectId={s.id} />
          </article>
        ))}
      </div>
    </div>
  );
}

function ProjectsFor({ subjectId }: { subjectId: string }) {
  const { data, reload } = useKawaii();
  const list = (data?.projects ?? []).filter((p) => p.subjectId === subjectId);
  const [name, setName] = useState("");
  return (
    <div className="mt-3 rounded-2xl bg-pink-50 p-2">
      <p className="text-xs font-extrabold uppercase text-pink-400">Projects</p>
      {list.map((p) => (
        <p key={p.id} className="text-sm">
          {p.name} · target {p.targetMinutes}m
        </p>
      ))}
      <div className="mt-1 flex gap-1">
        <input className="min-w-0 flex-1 rounded-lg border border-pink-200 px-2 text-sm" value={name} onChange={(e) => setName(e.target.value)} placeholder="Project name" />
        <button
          className="ghost-btn"
          onClick={async () => {
            if (!name.trim()) return;
            await api("/api/projects", { method: "POST", body: JSON.stringify({ name, subjectId }) });
            setName("");
            await reload();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}

export function CalendarView() {
  const { data, reload } = useKawaii();
  const [cursor, setCursor] = useState(() => new Date());
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const tasks = data?.tasks ?? [];
  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <button
          className="ghost-btn"
          onClick={() => setCursor(new Date(year, month - 1, 1))}
        >
          ‹
        </button>
        <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">
          {cursor.toLocaleString("en-US", { month: "long", year: "numeric" })}
        </h1>
        <button className="ghost-btn" onClick={() => setCursor(new Date(year, month + 1, 1))}>
          ›
        </button>
      </div>
      <div className="grid grid-cols-7 gap-2">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
          <div key={d} className="text-center text-xs font-extrabold text-pink-400">
            {d}
          </div>
        ))}
        {cells.map((d, i) => {
          const dayTasks = d
            ? tasks.filter((t) => t.dueDate && new Date(t.dueDate).getFullYear() === year && new Date(t.dueDate).getMonth() === month && new Date(t.dueDate).getDate() === d)
            : [];
          return (
            <div key={i} className="min-h-24 rounded-2xl border-2 border-pink-100 bg-white p-2">
              <p className="text-xs font-bold text-fuchsia-500">{d ?? ""}</p>
              {dayTasks.map((t) => (
                <button
                  key={t.id}
                  className={`mt-1 block w-full truncate rounded-lg px-1 text-left text-[11px] ${t.completed ? "bg-green-100 line-through" : "bg-pink-100"}`}
                  onClick={async () => {
                    await api("/api/tasks", { method: "POST", body: JSON.stringify({ id: t.id, completed: !t.completed }) });
                    await reload();
                  }}
                >
                  {t.title}
                </button>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function TasksView() {
  const { data, reload } = useKawaii();
  const [title, setTitle] = useState("");
  const [due, setDue] = useState("");
  const [subjectId, setSubjectId] = useState("");
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Tasks</h1>
      <div className="mt-3 flex flex-wrap gap-2">
        <input className="rounded-2xl border-2 border-pink-200 px-3 py-2" placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input type="date" className="rounded-2xl border-2 border-pink-200 px-3 py-2" value={due} onChange={(e) => setDue(e.target.value)} />
        <select className="rounded-2xl border-2 border-pink-200 px-3 py-2" value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
          <option value="">Subject</option>
          {(data?.subjects ?? []).map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <button
          className="pink-btn"
          onClick={async () => {
            if (!title.trim()) return;
            await api("/api/tasks", {
              method: "POST",
              body: JSON.stringify({ title, dueDate: due ? new Date(due).toISOString() : null, subjectId: subjectId || null }),
            });
            setTitle("");
            await reload();
          }}
        >
          Add task
        </button>
      </div>
      <div className="mt-4 flex flex-col gap-2">
        {(data?.tasks ?? []).map((t) => (
          <label key={t.id} className="card flex items-center gap-3">
            <input
              type="checkbox"
              checked={t.completed}
              onChange={async () => {
                await api("/api/tasks", { method: "POST", body: JSON.stringify({ id: t.id, completed: !t.completed }) });
                await reload();
              }}
            />
            <span className={`flex-1 ${t.completed ? "text-pink-300 line-through" : ""}`}>{t.title}</span>
            <span className="text-xs text-pink-400">{t.dueDate ? new Date(t.dueDate).toLocaleDateString() : ""}</span>
            <button
              className="ghost-btn"
              onClick={async () => {
                await api("/api/tasks", { method: "POST", body: JSON.stringify({ id: t.id, _delete: true }) });
                await reload();
              }}
            >
              Delete
            </button>
          </label>
        ))}
      </div>
    </div>
  );
}

export function FlashcardsView() {
  const { data, reload } = useKawaii();
  const cards = (data?.notes ?? []).filter((n) => n.kind === "flashcard" && !n.archived);
  const [q, setQ] = useState("");
  const [a, setA] = useState("");
  const [flip, setFlip] = useState<Record<string, boolean>>({});
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Flashcards</h1>
      <div className="mt-3 grid gap-2 md:grid-cols-2">
        <textarea className="rounded-2xl border-2 border-pink-200 p-3" placeholder="Question" value={q} onChange={(e) => setQ(e.target.value)} />
        <textarea className="rounded-2xl border-2 border-pink-200 p-3" placeholder="Answer" value={a} onChange={(e) => setA(e.target.value)} />
      </div>
      <button
        className="pink-btn mt-3"
        onClick={async () => {
          if (!q.trim()) return;
          await api("/api/notes", {
            method: "POST",
            body: JSON.stringify({
              title: q.slice(0, 80),
              kind: "flashcard",
              coverImage: DEFAULT_COVERS[1],
              content: [
                { id: "q", type: "text", x: 40, y: 40, w: 700, h: 80, z: 1, content: q, style: {} },
                { id: "a", type: "text", x: 40, y: 140, w: 700, h: 120, z: 1, content: a, style: {} },
              ],
            }),
          });
          setQ("");
          setA("");
          await reload();
        }}
      >
        Add card
      </button>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        {cards.map((c) => {
          const els = c.content as { content?: string }[];
          const front = els[0]?.content ?? c.title;
          const back = els[1]?.content ?? "";
          const show = flip[c.id];
          return (
            <button key={c.id} className="card min-h-40 text-left" onClick={() => setFlip((f) => ({ ...f, [c.id]: !f[c.id] }))}>
              <p className="text-[11px] font-extrabold uppercase text-pink-400">{show ? "Answer" : "Question"}</p>
              <p className="mt-2 text-lg font-bold text-fuchsia-800">{show ? back : front}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function MindMapsView() {
  const { data } = useKawaii();
  const maps = (data?.notes ?? []).filter((n) => (n.kind === "mindmap" || n.templateId === "patriotism-mindmap") && !n.archived);
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Mind Maps</h1>
      <p className="mb-3 text-sm text-pink-500">Shapes auto-connect when nearby. Use Connect mode in the editor to wire them by hand.</p>
      <div className="flex gap-2">
        <Link href="/templates" className="pink-btn">
          Start from a map template
        </Link>
        <CreateMindMap />
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {maps.map((n) => (
          <Link key={n.id} href={`/notes/${n.id}`} className="cover-card">
            <img src={n.coverImage || DEFAULT_COVERS[2]} alt="" />
            <p className="p-3 font-bold">{n.title}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

function CreateMindMap() {
  return (
    <button
      className="ghost-btn"
      onClick={async () => {
        const row = await api<{ id: string }>("/api/notes", {
          method: "POST",
          body: JSON.stringify({ templateId: "patriotism-mindmap", kind: "mindmap", title: "New mind map" }),
        });
        window.location.href = `/notes/${row.id}`;
      }}
    >
      Blank radial map
    </button>
  );
}

export function TimerView() {
  const { data, timer, startTimer, pauseTimer, resetTimer, setTimerType, setTimerSubject, reload } = useKawaii();
  const [manual, setManual] = useState({ minutes: 25, note: "", subjectId: "" });
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="card text-center">
        <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Pomodoro</h1>
        <div className="mt-3 flex justify-center gap-2">
          {(["pomodoro", "short_break", "long_break"] as const).map((t) => (
            <button key={t} className={`ghost-btn ${timer.type === t ? "active" : ""}`} onClick={() => setTimerType(t)}>
              {t.replace("_", " ")}
            </button>
          ))}
        </div>
        <p className="mt-6 font-[var(--font-fredoka)] text-7xl text-fuchsia-600">{timer.label}</p>
        <select className="mt-4 rounded-2xl border-2 border-pink-200 px-3 py-2" value={timer.subjectId ?? ""} onChange={(e) => setTimerSubject(e.target.value || null)}>
          <option value="">Link a subject</option>
          {(data?.subjects ?? []).map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <div className="mt-4 flex justify-center gap-2">
          <button className="pink-btn" onClick={() => (timer.running ? pauseTimer() : startTimer())}>
            {timer.running ? "Pause" : "Start"}
          </button>
          <button className="ghost-btn" onClick={resetTimer}>
            Reset
          </button>
        </div>
        <p className="mt-3 text-sm text-pink-500">Completed pomodoros auto-log into time entries and analytics.</p>
      </section>
      <section className="card">
        <h2 className="card-title">Manual time entry</h2>
        <div className="mt-3 flex flex-col gap-2">
          <input type="number" className="rounded-xl border-2 border-pink-200 px-2 py-1" value={manual.minutes} onChange={(e) => setManual({ ...manual, minutes: Number(e.target.value) })} />
          <select className="rounded-xl border-2 border-pink-200 px-2 py-1" value={manual.subjectId} onChange={(e) => setManual({ ...manual, subjectId: e.target.value })}>
            <option value="">Subject</option>
            {(data?.subjects ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <input className="rounded-xl border-2 border-pink-200 px-2 py-1" placeholder="Note" value={manual.note} onChange={(e) => setManual({ ...manual, note: e.target.value })} />
          <button
            className="pink-btn"
            onClick={async () => {
              await api("/api/time-entries", {
                method: "POST",
                body: JSON.stringify({
                  durationSeconds: Math.round(manual.minutes * 60),
                  subjectId: manual.subjectId || null,
                  note: manual.note,
                }),
              });
              await reload();
            }}
          >
            Log minutes
          </button>
        </div>
        <h3 className="card-title mt-6">Sessions</h3>
        <div className="mt-2 flex max-h-72 flex-col gap-2 overflow-auto">
          {(data?.timeEntries ?? []).map((e) => (
            <div key={e.id} className="flex items-center justify-between rounded-xl bg-pink-50 px-2 py-2 text-sm">
              <span>
                {e.date} · {formatTime(e.durationSeconds)} · {e.note}
              </span>
              <button
                className="ghost-btn"
                onClick={async () => {
                  await api("/api/time-entries", { method: "POST", body: JSON.stringify({ id: e.id, _delete: true }) });
                  await reload();
                }}
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export function AnalyticsView() {
  const { data } = useKawaii();
  const a = data?.analytics;
  if (!a) return <div className="empty-state">Loading analytics…</div>;
  const maxW = Math.max(1, ...a.weekly.days.map((d) => d.totalSeconds));
  const maxM = Math.max(1, ...a.monthly.days.map((d) => d.totalSeconds));
  return (
    <div className="flex flex-col gap-4">
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Analytics</h1>
      <p className="text-sm text-pink-500">Every number below is computed from real time entries — empty until you study.</p>
      <div className="grid gap-3 md:grid-cols-3">
        <div className="card">
          <p className="card-title">Today</p>
          <p className="text-3xl font-bold text-fuchsia-700">{formatHours(Math.round(a.daily.totalSeconds / 60))}</p>
          <p className="text-sm">{a.daily.sessions} sessions</p>
        </div>
        <div className="card">
          <p className="card-title">This week</p>
          <p className="text-3xl font-bold text-fuchsia-700">{formatHours(Math.round(a.weekly.totalSeconds / 60))}</p>
        </div>
        <div className="card">
          <p className="card-title">30 days</p>
          <p className="text-3xl font-bold text-fuchsia-700">{formatHours(Math.round(a.monthly.totalSeconds / 60))}</p>
        </div>
      </div>
      <section className="card">
        <h2 className="card-title mb-3">Weekly breakdown</h2>
        <div className="flex h-40 items-end gap-2">
          {a.weekly.days.map((d) => (
            <div key={d.date} className="flex flex-1 flex-col items-center justify-end">
              <div className="w-full rounded-t-lg bg-pink-300" style={{ height: `${Math.round((d.totalSeconds / maxW) * 100)}%` }} />
              <span className="mt-1 text-[10px] text-pink-400">{d.date.slice(5)}</span>
            </div>
          ))}
        </div>
      </section>
      <section className="card">
        <h2 className="card-title mb-3">Monthly sparkline</h2>
        <div className="flex h-24 items-end gap-px">
          {a.monthly.days.map((d) => (
            <div key={d.date} className="flex-1 rounded-t bg-violet-300" style={{ height: `${Math.round((d.totalSeconds / maxM) * 100)}%` }} />
          ))}
        </div>
      </section>
      <section className="card">
        <h2 className="card-title mb-3">Subjects</h2>
        {(a.subjects ?? []).map((s) => (
          <div key={s.id} className="mb-2">
            <div className="flex justify-between text-sm">
              <span>
                {s.icon} {s.name}
              </span>
              <span>
                {s.pct}% · {hoursLabel(s.minutes, s.targetMinutes)}
              </span>
            </div>
            <div className="progress-track">
              <div className="progress-fill" style={{ width: `${s.pct}%`, background: s.color }} />
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

export function MusicView() {
  const { data, music, setMusicIndex, togglePlay, reload, setMuted, setVolume } = useKawaii();
  const tracks = data?.tracks ?? [];
  const current = tracks[music.index];
  const embed = music.playing ? trackEmbed(current) : null;
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  return (
    <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
      <section className="card music-dock">
        <h1 className="font-[var(--font-fredoka)] text-3xl text-violet-700">Music</h1>
        <p className="mt-1 font-bold">{current?.title ?? "Nothing queued"}</p>
        <p className="text-sm text-violet-400">{current?.artist}</p>
        <div className="mt-4 flex items-center gap-3">
          <button className="pink-btn" onClick={togglePlay}>
            {music.playing ? "Pause" : "Play"}
          </button>
          <button className="ghost-btn" onClick={() => setMuted(!music.muted)}>
            {music.muted ? "Unmute" : "Mute"}
          </button>
          <input type="range" min={0} max={1} step={0.05} value={music.volume} onChange={(e) => setVolume(Number(e.target.value))} />
        </div>
        {embed && <iframe className="mt-4 h-52 w-full rounded-2xl" src={embed} title="player" allow="autoplay; encrypted-media" />}
        {current && current.source !== "youtube" && !current.url.includes("youtu") && (
          <audio className="mt-4 w-full" src={current.url} controls autoPlay={music.playing} />
        )}
      </section>
      <section className="card">
        <h2 className="card-title">Playlist</h2>
        {tracks.map((t, i) => (
          <button key={t.id} className="mt-2 flex w-full items-center justify-between rounded-xl bg-violet-50 px-2 py-2 text-left" onClick={() => setMusicIndex(i)}>
            <span>
              {i + 1}. {t.title}
            </span>
            <button
              className="ghost-btn"
              onClick={async (e) => {
                e.stopPropagation();
                await api("/api/music", { method: "POST", body: JSON.stringify({ entity: "track", id: t.id, _delete: true }) });
                await reload();
              }}
            >
              ×
            </button>
          </button>
        ))}
        <h3 className="card-title mt-4">Add YouTube / Spotify / URL</h3>
        <input className="mt-2 w-full rounded-xl border-2 border-violet-200 px-2 py-1" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input className="mt-2 w-full rounded-xl border-2 border-violet-200 px-2 py-1" placeholder="https://…" value={url} onChange={(e) => setUrl(e.target.value)} />
        <button
          className="pink-btn mt-2"
          onClick={async () => {
            if (!url.trim()) return;
            const source = url.includes("youtu") ? "youtube" : url.includes("spotify") ? "spotify" : "url";
            await api("/api/music", {
              method: "POST",
              body: JSON.stringify({
                entity: "track",
                title: title || "Track",
                url,
                source,
                playlistId: data?.playlists[0]?.id ?? null,
              }),
            });
            setUrl("");
            setTitle("");
            await reload();
          }}
        >
          Add track
        </button>
        <label className="ghost-btn mt-3 block cursor-pointer text-center">
          Upload MP3 / WAV / M4A
          <input
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const dataUrl = await new Promise<string>((resolve) => {
                const r = new FileReader();
                r.onload = () => resolve(String(r.result));
                r.readAsDataURL(file);
              });
              const asset = await api<{ url: string }>("/api/assets", {
                method: "POST",
                body: JSON.stringify({ name: file.name, mimeType: file.type, data: dataUrl, kind: "audio" }),
              });
              await api("/api/music", {
                method: "POST",
                body: JSON.stringify({ entity: "track", title: file.name, url: asset.url, source: "local" }),
              });
              await reload();
            }}
          />
        </label>
      </section>
    </div>
  );
}

export function ResourcesView() {
  const { data, reload } = useKawaii();
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Resources & vault</h1>
      <p className="mb-3 text-sm text-pink-500">Upload images, copy their links, paste them as covers or stickers — your own tiny Obsidian.</p>
      <label className="pink-btn inline-block cursor-pointer">
        Upload file
        <input
          type="file"
          accept="image/*,audio/*"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const dataUrl = await new Promise<string>((resolve) => {
              const r = new FileReader();
              r.onload = () => resolve(String(r.result));
              r.readAsDataURL(file);
            });
            await api("/api/assets", {
              method: "POST",
              body: JSON.stringify({
                name: file.name,
                mimeType: file.type,
                data: dataUrl,
                kind: file.type.startsWith("audio") ? "audio" : "image",
              }),
            });
            await reload();
          }}
        />
      </label>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(data?.assets ?? []).map((a) => {
          const url = a.url || `/api/assets/${a.id}`;
          return (
            <article key={a.id} className="card">
              {a.kind === "image" ? <img src={url} alt={a.name} className="h-28 w-full rounded-xl object-cover" /> : <p className="text-3xl">🎵</p>}
              <p className="mt-2 truncate text-sm font-bold">{a.name}</p>
              <button
                className="ghost-btn mt-2"
                onClick={() => navigator.clipboard.writeText(`${window.location.origin}${url}`)}
              >
                Copy link
              </button>
            </article>
          );
        })}
      </div>
    </div>
  );
}

export function TrashView() {
  const { data, reload } = useKawaii();
  const trashed = (data?.notes ?? []).filter((n) => n.archived);
  return (
    <div>
      <h1 className="font-[var(--font-fredoka)] text-3xl text-fuchsia-700">Trash</h1>
      {trashed.length === 0 && <p className="empty-state">Trash is empty — sparkling clean.</p>}
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {trashed.map((n) => (
          <article key={n.id} className="card flex items-center gap-3">
            <img src={n.coverImage || DEFAULT_COVERS[0]} alt="" className="h-14 w-14 rounded-xl object-cover" />
            <div className="flex-1">
              <p className="font-bold">{n.title}</p>
              <div className="mt-1 flex gap-2">
                <button
                  className="ghost-btn"
                  onClick={async () => {
                    await api(`/api/notes/${n.id}`, { method: "PATCH", body: JSON.stringify({ archived: false }) });
                    await reload();
                  }}
                >
                  Restore
                </button>
                <button
                  className="ghost-btn"
                  onClick={async () => {
                    await api(`/api/notes/${n.id}`, { method: "DELETE" });
                    await reload();
                  }}
                >
                  Delete forever
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}



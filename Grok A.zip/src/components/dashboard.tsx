"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { hoursLabel } from "@/lib/timer";
import { api, useKawaii } from "./provider";

function hourOfDay() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

export function DashboardView() {
  const { data, reload, timer, startTimer, pauseTimer, setFocusMode, focusMode, quote, motivation } = useKawaii();
  const [adding, setAdding] = useState("");

  const subjects = data?.analytics.subjects ?? [];
  const notes = (data?.notes ?? []).filter((n) => !n.archived);
  const tasks = data?.tasks ?? [];
  const tags = data?.tags ?? [];
  const noteTags = data?.noteTags ?? [];
  const widgets = (data?.widgets ?? []).slice().sort((a, b) => a.layoutOrder - b.layoutOrder);
  const visible = new Set(widgets.filter((w) => w.visible).map((w) => w.widgetKey));
  const show = (key: string) => visible.size === 0 || visible.has(key);

  const tagCounts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const l of noteTags) map[l.tagId] = (map[l.tagId] ?? 0) + 1;
    return tags
      .map((t) => ({ ...t, count: map[t.id] ?? 0 }))
      .sort((a, b) => b.count - a.count);
  }, [tags, noteTags]);

  const todayTasks = tasks.filter((t) => {
    if (!t.dueDate) return true;
    const d = new Date(t.dueDate);
    const n = new Date();
    return d.toDateString() === n.toDateString() || (!t.completed && d.getTime() < n.getTime() + 86400000);
  });

  const deadlines = tasks
    .filter((t) => !t.completed && t.dueDate)
    .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
    .slice(0, 5);

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const first = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
  while (cells.length % 7) cells.push(null);

  const deadlineDays = new Set(
    tasks.filter((t) => t.dueDate).map((t) => new Date(t.dueDate!).getDate()),
  );

  const totalTarget = subjects.reduce((s, x) => s + x.targetMinutes, 0);
  const totalStudied = subjects.reduce((s, x) => s + x.minutes, 0);
  const pie = subjects.filter((s) => s.seconds > 0);
  const pieTotal = pie.reduce((s, x) => s + x.seconds, 0) || 1;
  let acc = 0;
  const conic = pie.length
    ? pie
        .map((s) => {
          const start = (acc / pieTotal) * 360;
          acc += s.seconds;
          const end = (acc / pieTotal) * 360;
          return `${s.color} ${start}deg ${end}deg`;
        })
        .join(", ")
    : "#fce7f3 0deg 360deg";

  const weekDeadlines = tasks.filter((t) => {
    if (t.completed || !t.dueDate) return false;
    const d = new Date(t.dueDate).getTime();
    return d >= Date.now() - 3600000 && d <= Date.now() + 7 * 86400000;
  }).length;

  const monthName = now.toLocaleString("en-US", { month: "long" }).toUpperCase();

  async function toggleTask(id: string, completed: boolean) {
    await api("/api/tasks", { method: "POST", body: JSON.stringify({ id, completed }) });
    await reload();
  }

  async function addTask() {
    if (!adding.trim()) return;
    await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({ title: adding, dueDate: new Date().toISOString() }),
    });
    setAdding("");
    await reload();
  }

  async function restoreLayout() {
    await api("/api/widgets", { method: "POST", body: JSON.stringify({ restore: true }) });
    await reload();
  }

  async function hideWidget(key: string) {
    const next = (data?.widgets ?? []).map((w) =>
      w.widgetKey === key ? { ...w, visible: false } : w,
    );
    await api("/api/widgets", { method: "POST", body: JSON.stringify({ widgets: next }) });
    await reload();
  }

  if (!data) {
    return <div className="empty-state">Warming up the study lamps… 🌙</div>;
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm font-bold text-pink-500">Study Hub · rearrange, hide, or restore your pastel panels</p>
        <div className="flex gap-2">
          <button className="ghost-btn" onClick={restoreLayout}>
            Restore layout
          </button>
          <button className="ghost-btn" onClick={() => setFocusMode(!focusMode)}>
            {focusMode ? "Exit focus" : "Focus mode"}
          </button>
        </div>
      </div>

      <div className="dash-grid">
        {show("greeting") && (
          <section className="card relative overflow-hidden bg-gradient-to-br from-pink-100 to-violet-100">
            <button className="absolute right-3 top-3 text-xs text-pink-400" onClick={() => hideWidget("greeting")}>
              hide
            </button>
            <p className="font-[var(--font-fredoka)] text-2xl text-fuchsia-700">
              {hourOfDay()}, {data.user.name}!
            </p>
            <p className="mt-1 text-sm text-pink-600">Let&apos;s make today productive! ✨</p>
            <img src="/art/hero-study.jpg" alt="Kawaii cat studying at a computer" className="mt-3 h-40 w-full rounded-2xl object-cover" />
          </section>
        )}

        {show("progress") && (
          <section className="card">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="card-title">Study Progress</h2>
              <button className="text-xs text-pink-400" onClick={() => hideWidget("progress")}>
                hide
              </button>
            </div>
            <div className="flex flex-col gap-3">
              {subjects.length === 0 && <p className="empty-state">Add a subject to track hours.</p>}
              {subjects.map((s) => (
                <div key={s.id}>
                  <div className="mb-1 flex items-center justify-between text-sm">
                    <span>
                      {s.icon} {s.name}
                    </span>
                    <span className="text-xs text-pink-400">
                      {s.pct}% · {hoursLabel(s.minutes, s.targetMinutes)}
                    </span>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${s.pct}%`, background: s.color }} />
                  </div>
                </div>
              ))}
            </div>
            <Link href="/analytics" className="mt-3 block text-right text-xs font-bold text-fuchsia-500">
              View All Progress →
            </Link>
          </section>
        )}

        {show("plan") && (
          <section className="card bg-amber-50">
            <h2 className="card-title mb-2">Today&apos;s Plan</h2>
            <div className="flex flex-col gap-2">
              {todayTasks.slice(0, 6).map((t) => (
                <label key={t.id} className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={t.completed} onChange={() => toggleTask(t.id, !t.completed)} />
                  <span className={t.completed ? "text-pink-300 line-through" : ""}>{t.title}</span>
                </label>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <input
                className="min-w-0 flex-1 rounded-xl border-2 border-pink-200 px-2 py-1 text-sm"
                placeholder="+ Add Task"
                value={adding}
                onChange={(e) => setAdding(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addTask()}
              />
              <button className="ghost-btn" onClick={addTask}>
                Add
              </button>
            </div>
          </section>
        )}

        {show("calendar") && (
          <section className="card">
            <div className="mb-2 flex items-center justify-between">
              <button className="ghost-btn">‹</button>
              <h2 className="card-title">
                {monthName} {year}
              </h2>
              <button className="ghost-btn">›</button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-bold text-pink-400">
              {["S", "M", "T", "W", "T", "F", "S"].map((d) => (
                <div key={d}>{d}</div>
              ))}
              {cells.map((d, i) => (
                <div
                  key={i}
                  className={`rounded-full py-1 ${d === now.getDate() ? "bg-pink-400 text-white" : ""} ${d && deadlineDays.has(d) && d !== now.getDate() ? "bg-pink-100" : ""}`}
                >
                  {d ?? ""}
                </div>
              ))}
            </div>
            <p className="mt-3 rounded-full bg-fuchsia-100 px-3 py-2 text-center text-xs font-bold text-fuchsia-700">
              You have {weekDeadlines} deadline{weekDeadlines === 1 ? "" : "s"} this week!
            </p>
          </section>
        )}
      </div>

      <div className="dash-grid">
        {show("recent") && (
          <section className="card">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="card-title">Recent Notes</h2>
              <Link href="/notes" className="text-xs font-bold text-fuchsia-500">
                View All
              </Link>
            </div>
            <div className="flex flex-col gap-2">
              {notes.slice(0, 5).map((n) => {
                const sub = data.subjects.find((s) => s.id === n.subjectId);
                const nt = noteTags.filter((l) => l.noteId === n.id).map((l) => tags.find((t) => t.id === l.tagId)?.name);
                return (
                  <Link key={n.id} href={`/notes/${n.id}`} className="flex items-center gap-2 rounded-xl bg-pink-50/70 px-2 py-2">
                    <img src={n.coverImage || "/covers/starry-clouds.jpg"} alt="" className="h-10 w-10 rounded-lg object-cover" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{n.title}</p>
                      <p className="truncate text-[11px] text-pink-400">
                        {nt.filter(Boolean).map((t) => `#${t}`).join(" ")} {sub ? `· ${sub.name}` : ""}
                      </p>
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        )}

        {show("deadlines") && (
          <section className="card">
            <h2 className="card-title mb-2">Upcoming Deadlines</h2>
            <div className="flex flex-col gap-2">
              {deadlines.length === 0 && <p className="empty-state">No deadlines — enjoy the calm ☁️</p>}
              {deadlines.map((t) => {
                const due = new Date(t.dueDate!);
                const days = Math.ceil((due.getTime() - Date.now()) / 86400000);
                return (
                  <div key={t.id} className="flex items-center gap-3 rounded-xl bg-violet-50 px-2 py-2">
                    <div className="w-12 text-center">
                      <p className="text-[10px] font-extrabold uppercase text-fuchsia-400">
                        {due.toLocaleString("en-US", { month: "short" })}
                      </p>
                      <p className="text-lg font-bold text-fuchsia-700">{due.getDate()}</p>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{t.title}</p>
                      <p className="text-[11px] text-pink-400">{days <= 0 ? "due" : `${days} days left`}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            <Link href="/calendar" className="mt-2 block text-right text-xs font-bold text-fuchsia-500">
              View Calendar →
            </Link>
          </section>
        )}

        {show("subjects") && (
          <section className="card">
            <h2 className="card-title mb-2">Subject Overview</h2>
            <div className="flex items-center gap-4">
              <div className="h-28 w-28 shrink-0 rounded-full" style={{ background: `conic-gradient(${conic})` }} />
              <div className="flex flex-col gap-1 text-xs">
                {subjects.map((s) => (
                  <div key={s.id} className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                    {s.name} {pieTotal > 0 ? `${Math.round((s.seconds / pieTotal) * 100)}%` : "0%"}
                  </div>
                ))}
              </div>
            </div>
            <p className="mt-3 text-center text-sm font-bold text-fuchsia-700">
              Total Study Hours {hoursLabel(totalStudied, totalTarget)}
            </p>
            {totalStudied === 0 && <p className="empty-state">Start the pomodoro to fill this pie ✨</p>}
          </section>
        )}

        {show("music") && <MusicCard />}
      </div>

      <div className="dash-grid">
        {show("quick") && (
          <section className="card">
            <h2 className="card-title mb-3">Quick Actions</h2>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
              {[
                ["📓", "New Note", "/notes"],
                ["✅", "New Task", "/tasks"],
                ["🗺️", "Mind Map", "/mind-maps"],
                ["🃏", "Flashcard", "/flashcards"],
                ["⬆️", "Upload", "/resources"],
                ["🗓️", "Calendar", "/calendar"],
              ].map(([icon, label, href]) => (
                <Link key={label} href={href} className="flex flex-col items-center gap-1 rounded-2xl bg-pink-50 py-3 text-xs font-bold text-fuchsia-700">
                  <span className="text-xl">{icon}</span>
                  {label}
                </Link>
              ))}
            </div>
          </section>
        )}
        {show("streak") && (
          <section className="card text-center">
            <h2 className="card-title">Study Streak</h2>
            <p className="mt-2 text-5xl">🔥</p>
            <p className="font-[var(--font-fredoka)] text-4xl text-fuchsia-600">{data.analytics.streak}</p>
            <p className="text-sm text-pink-500">Days in a row!</p>
          </section>
        )}
        {show("focus") && (
          <section className="card flex flex-col items-start justify-between bg-gradient-to-br from-violet-100 to-pink-100">
            <div>
              <h2 className="card-title">Focus Mode</h2>
              <p className="mt-1 text-sm text-pink-600">Eliminate distractions and get deep work done.</p>
            </div>
            <button className="pink-btn mt-4" onClick={() => setFocusMode(!focusMode)}>
              {focusMode ? "Leave Focus Mode" : "Start Focus Mode"}
            </button>
          </section>
        )}
        <section className="card flex items-center justify-center overflow-hidden p-0">
          <img src="/covers/night-cat.jpg" alt="Kawaii night cat" className="h-40 w-full object-cover" />
        </section>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        {show("motivation") && (
          <section className="card flex items-center gap-3">
            <span className="text-3xl">🎀</span>
            <div>
              <h2 className="card-title">Daily Motivations</h2>
              <p className="text-sm">{motivation}</p>
            </div>
          </section>
        )}
        {show("tags") && (
          <section className="card">
            <div className="mb-2 flex justify-between">
              <h2 className="card-title">Notes Tag Cloud</h2>
              <Link href="/notes" className="text-xs font-bold text-fuchsia-500">
                View All
              </Link>
            </div>
            <div className="flex flex-wrap gap-2">
              {tagCounts.map((t) => (
                <Link key={t.id} href={`/notes?tag=${t.id}`} className="kawaii-chip" style={{ background: t.color }}>
                  #{t.name} {t.count}
                </Link>
              ))}
            </div>
          </section>
        )}
        {show("quote") && (
          <section className="card">
            <h2 className="card-title">Quote of the Day</h2>
            <p className="mt-2 font-[var(--font-caveat)] text-2xl text-fuchsia-800">&ldquo;{quote}&rdquo;</p>
          </section>
        )}
      </div>

      <div className="hidden">
        {timer.running ? (
          <button onClick={pauseTimer}>pause</button>
        ) : (
          <button onClick={startTimer}>start</button>
        )}
      </div>
    </div>
  );
}

function MusicCard() {
  const { data, music, setMusicIndex, togglePlay } = useKawaii();
  const tracks = data?.tracks ?? [];
  const current = tracks[music.index];
  return (
    <section className="card music-dock">
      <h2 className="card-title mb-2">Music Player</h2>
      <div className="flex items-center gap-3">
        <img src="/art/avatar-student.jpg" alt="" className="h-12 w-12 rounded-xl object-cover" />
        <div className="min-w-0">
          <p className="truncate font-bold">{current?.title ?? "No track yet"}</p>
          <p className="truncate text-xs text-violet-400">{current?.artist}</p>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-center gap-3">
        <button className="icon-btn" onClick={() => setMusicIndex(Math.max(0, music.index - 1))}>
          ⏮
        </button>
        <button className="pink-btn !rounded-full" onClick={togglePlay}>
          {music.playing ? "❚❚" : "▶"}
        </button>
        <button className="icon-btn" onClick={() => setMusicIndex(Math.min(tracks.length - 1, music.index + 1))}>
          ⏭
        </button>
      </div>
      <div className="mt-3 flex flex-col gap-1 text-xs">
        {tracks.slice(0, 5).map((t, i) => (
          <button key={t.id} className={`flex justify-between rounded-lg px-2 py-1 text-left ${i === music.index ? "bg-white" : ""}`} onClick={() => setMusicIndex(i)}>
            <span className="truncate">
              {i + 1}. {t.title}
            </span>
          </button>
        ))}
      </div>
      <Link href="/music" className="mt-2 block text-right text-xs font-bold text-violet-500">
        View All →
      </Link>
    </section>
  );
}

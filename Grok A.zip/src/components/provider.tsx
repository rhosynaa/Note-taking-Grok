"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { durationForType, formatTime, todayKey, type SessionType } from "@/lib/timer";
import { MOTIVATIONS, QUOTES } from "@/lib/types";

export interface Subject {
  id: string;
  name: string;
  color: string;
  icon: string;
  targetMinutes: number;
}
export interface Project {
  id: string;
  name: string;
  description: string | null;
  subjectId: string | null;
  targetMinutes: number;
}
export interface Note {
  id: string;
  title: string;
  subjectId: string | null;
  projectId: string | null;
  templateId: string | null;
  kind: string;
  content: unknown[];
  coverImage: string | null;
  pinned: boolean;
  archived: boolean;
  canvasWidth: number;
  canvasHeight: number;
  background: string | null;
  createdAt: string;
  updatedAt: string;
}
export interface Task {
  id: string;
  title: string;
  completed: boolean;
  dueDate: string | null;
  subjectId: string | null;
  noteId: string | null;
  priority: string;
}
export interface Tag {
  id: string;
  name: string;
  color: string;
}
export interface NoteTag {
  id: string;
  noteId: string;
  tagId: string;
}
export interface Widget {
  id: string;
  widgetKey: string;
  layoutOrder: number;
  visible: boolean;
  pinned: boolean;
}
export interface Track {
  id: string;
  playlistId: string | null;
  title: string;
  artist: string | null;
  source: string;
  url: string;
  durationSeconds: number;
  sortOrder: number;
}
export interface Playlist {
  id: string;
  name: string;
}
export interface TimeEntry {
  id: string;
  subjectId: string | null;
  projectId: string | null;
  noteId: string | null;
  date: string;
  durationSeconds: number;
  note: string | null;
}
export interface Asset {
  id: string;
  name: string;
  mimeType: string;
  kind: string;
  url?: string;
  createdAt: string;
}
export interface AnalyticsPayload {
  daily: { totalSeconds: number; sessions: number; date: string };
  weekly: { totalSeconds: number; days: { date: string; totalSeconds: number }[] };
  monthly: { totalSeconds: number; days: { date: string; totalSeconds: number }[] };
  subjects: (Subject & { minutes: number; seconds: number; pct: number })[];
  streak: number;
  totalMinutes: number;
}

export interface Workspace {
  user: { id: string; name: string; email: string | null; avatar: string | null; preferences: Record<string, unknown> | null };
  subjects: Subject[];
  projects: Project[];
  notes: Note[];
  tasks: Task[];
  tags: Tag[];
  noteTags: NoteTag[];
  widgets: Widget[];
  playlists: Playlist[];
  tracks: Track[];
  timeEntries: TimeEntry[];
  assets: Asset[];
  analytics: AnalyticsPayload;
  systemTemplates: { id: string; name: string; category: string; description: string; cover: string; paper: string }[];
  customTemplates: { id: string; name: string; category: string; thumbnail: string | null; data: Record<string, unknown> }[];
  today: string;
}

interface Ctx {
  ready: boolean;
  data: Workspace | null;
  reload: () => Promise<void>;
  focusMode: boolean;
  setFocusMode: (v: boolean) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (v: boolean) => void;
  search: string;
  setSearch: (v: string) => void;
  searchResults: { notes: Note[]; tasks: Task[]; tags: Tag[] } | null;
  timer: {
    type: SessionType;
    remaining: number;
    running: boolean;
    sessionId: string | null;
    subjectId: string | null;
    label: string;
  };
  setTimerType: (t: SessionType) => void;
  setTimerSubject: (id: string | null) => void;
  startTimer: () => Promise<void>;
  pauseTimer: () => Promise<void>;
  resetTimer: () => Promise<void>;
  music: {
    index: number;
    playing: boolean;
    muted: boolean;
    volume: number;
  };
  setMusicIndex: (i: number) => void;
  togglePlay: () => void;
  setMuted: (v: boolean) => void;
  setVolume: (v: number) => void;
  quote: string;
  motivation: string;
}

const KawaiiCtx = createContext<Ctx | null>(null);

export function useKawaii() {
  const ctx = useContext(KawaiiCtx);
  if (!ctx) throw new Error("useKawaii must be inside AppProviders");
  return ctx;
}

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  return res.json();
}

function youtubeId(url: string) {
  const m = url.match(/(?:v=|youtu\.be\/|embed\/)([A-Za-z0-9_-]{6,})/);
  return m?.[1] ?? null;
}

export function trackEmbed(track?: Track | null) {
  if (!track) return null;
  if (track.source === "youtube" || track.url.includes("youtu")) {
    const id = youtubeId(track.url);
    return id ? `https://www.youtube.com/embed/${id}?autoplay=1` : null;
  }
  if (track.url.includes("spotify.com")) {
    return track.url.replace("open.spotify.com/", "open.spotify.com/embed/");
  }
  return null;
}

export function AppProviders({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Workspace | null>(null);
  const [ready, setReady] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<Ctx["searchResults"]>(null);
  const [timerType, setTimerType] = useState<SessionType>("pomodoro");
  const [remaining, setRemaining] = useState(durationForType("pomodoro"));
  const [running, setRunning] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [musicIndex, setMusicIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const tickRef = useRef<number | null>(null);

  const reload = useCallback(async () => {
    const ws = await api<Workspace>("/api/bootstrap");
    setData(ws);
    setReady(true);
  }, []);

  useEffect(() => {
    reload().catch(() => setReady(true));
  }, [reload]);

  useEffect(() => {
    if (!running) {
      if (tickRef.current) window.clearInterval(tickRef.current);
      return;
    }
    tickRef.current = window.setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          setRunning(false);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => {
      if (tickRef.current) window.clearInterval(tickRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (remaining === 0 && sessionId) {
      api("/api/timer", {
        method: "POST",
        body: JSON.stringify({ action: "complete", sessionId, remainingSeconds: 0 }),
      })
        .then(() => reload())
        .catch(() => undefined);
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        new Notification("Kawaii Study Space", { body: "Session complete! Time for a stretch ✨" });
      }
    }
  }, [remaining, sessionId, reload]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (!search.trim()) {
        setSearchResults(null);
        return;
      }
      api<Ctx["searchResults"]>(`/api/search?q=${encodeURIComponent(search)}`)
        .then(setSearchResults)
        .catch(() => undefined);
    }, 220);
    return () => clearTimeout(t);
  }, [search]);

  const startTimer = useCallback(async () => {
    if (sessionId && !running && remaining > 0) {
      await api("/api/timer", { method: "POST", body: JSON.stringify({ action: "resume", sessionId }) });
      setRunning(true);
      return;
    }
    const dur = durationForType(timerType);
    const row = await api<{ id: string }>(" /api/timer".trim(), {
      method: "POST",
      body: JSON.stringify({
        action: "start",
        type: timerType,
        subjectId,
        durationSeconds: dur,
      }),
    });
    setSessionId(row.id);
    setRemaining(dur);
    setRunning(true);
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => undefined);
    }
  }, [sessionId, running, remaining, timerType, subjectId]);

  const pauseTimer = useCallback(async () => {
    setRunning(false);
    if (sessionId) {
      await api("/api/timer", {
        method: "POST",
        body: JSON.stringify({ action: "pause", sessionId, remainingSeconds: remaining }),
      });
    }
  }, [sessionId, remaining]);

  const resetTimer = useCallback(async () => {
    setRunning(false);
    const dur = durationForType(timerType);
    setRemaining(dur);
    if (sessionId) {
      await api("/api/timer", {
        method: "POST",
        body: JSON.stringify({ action: "reset", sessionId, type: timerType, durationSeconds: dur }),
      });
    }
    setSessionId(null);
  }, [sessionId, timerType]);

  const day = data?.today ?? todayKey();
  const quote = QUOTES[Number(day.slice(-2)) % QUOTES.length];
  const motivation = MOTIVATIONS[Number(day.replaceAll("-", "")) % MOTIVATIONS.length];

  const value = useMemo<Ctx>(
    () => ({
      ready,
      data,
      reload,
      focusMode,
      setFocusMode,
      sidebarOpen,
      setSidebarOpen,
      search,
      setSearch,
      searchResults,
      timer: {
        type: timerType,
        remaining,
        running,
        sessionId,
        subjectId,
        label: formatTime(remaining),
      },
      setTimerType: (t) => {
        setTimerType(t);
        if (!running) setRemaining(durationForType(t));
      },
      setTimerSubject: setSubjectId,
      startTimer,
      pauseTimer,
      resetTimer,
      music: { index: musicIndex, playing, muted, volume },
      setMusicIndex: (i) => {
        setMusicIndex(i);
        setPlaying(true);
      },
      togglePlay: () => setPlaying((p) => !p),
      setMuted,
      setVolume,
      quote,
      motivation,
    }),
    [
      ready,
      data,
      reload,
      focusMode,
      sidebarOpen,
      search,
      searchResults,
      timerType,
      remaining,
      running,
      sessionId,
      subjectId,
      startTimer,
      pauseTimer,
      resetTimer,
      musicIndex,
      playing,
      muted,
      volume,
      quote,
      motivation,
    ],
  );

  return <KawaiiCtx.Provider value={value}>{children}</KawaiiCtx.Provider>;
}
